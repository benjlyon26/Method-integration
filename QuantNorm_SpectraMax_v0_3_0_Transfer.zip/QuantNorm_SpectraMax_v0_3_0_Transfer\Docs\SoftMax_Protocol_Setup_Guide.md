# SoftMax Pro protocol and MM4 SpectraMax setup: Quant_Norm_SpectraMax_v0_3_0

This is for the person setting up the SpectraMax and SoftMax Pro side of the in vivo RNA Quant/Norm method on the Lynx. Work through it top to bottom on the target system. Items marked **VERIFY** have not been confirmed on a real instrument yet, so confirm each one before the first wet run.

## 0. File types: which protocol file the method opens

| SoftMax Pro version | Protocol file | Data file |
|---|---|---|
| 7.x | `.sprx` | `.sdax` |
| 5.x / 6.x | `.spr` | `.sda` |

The MM4 `MDSpectraMax` driver's **Open File** command loads a protocol or data document by path. Its own help text refers to ".spr for Protocol, .sda for Data".
- **VERIFY:** on the target PC, check that Open File accepts the extension your installed SoftMax version saves (`.sprx` on SMP 7). If it doesn't, save the protocol in the format the driver accepts.
- There is no `.sp3` SoftMax format. If someone means a different file, find out which one before building against it.

Save the protocol as **`QuantNorm_RNA.sprx`** (or `.spr`) in a controlled folder, for example `C:\MethodManager4\Workspaces\GSK Demo\Protocols\`. Record the full path, because the method's Open File step needs it.

## 1. Protocol contents

Create **one experiment containing three plate sections**. The names must match exactly, because MM4's *Select Section* step selects them by name:

| Section name | When it is read | Purpose |
|---|---|---|
| `Blank` | After the 45 µL diluent fill, before any sample is added | Per-well blank, stored by the script and subtracted well by well |
| `Read_1` | After the 5 µL stamp and mix | A260_1, plus the run's A280 and A230 |
| `Read_2` | Immediately after Read_1 | A260_2 (the QUANT-004 duplicate) |

All three sections must have **identical** settings:

| Setting | Value | Why |
|---|---|---|
| Read mode / type | Absorbance (ABS), **Endpoint** | |
| Wavelengths | **230, 260, 280 nm** (3 wavelengths) | All three feed the purity ratios |
| Plate type | The validated **96-well half-area UV-transparent** plate. If it isn't in the plate list, create a custom plate type from the manufacturer's drawing. | A wrong plate definition shifts read positions off-centre |
| Read area | All 96 wells (A1–H12) | The script matches wells by label and ignores wells without samples |
| PathCheck | **Off** (default). See §3 for the alternative. | The script needs raw OD |
| Plate blank / template blanks | **None.** Don't assign Blank groups in the template. | The script does per-well blanking. A second blank in SoftMax would subtract it twice. |
| Data reduction | None / raw OD | The exported values must be raw OD |
| Shake before read | Off for `Blank`. For `Read_1`, a short low-intensity shake is optional (scientist decision Q11). | A shake can clear bubbles from mixing but can also splash |
| Temperature | Incubator off / ambient (scientist decision Q15) | |
| Auto-read / auto-export | Off | MM4 drives each read and export explicitly |

Save the protocol and lock or version it, so analysts can't change wavelengths or blanking by accident.

## 2. Export format: what the script can parse

Each section is exported to **its own file** by MM4's *Export Section As* step. The **file name comes from an MM4 variable** that RunGuard writes, so don't hard-code paths:

| Section | Export file variable (set by RunGuard) |
|---|---|
| `Blank` | `User.SpectraMaxBlankFile_01` → `Output\QuantNorm_SMX_<RunID>_P<k>_Blank.txt` |
| `Read_1` | `User.SpectraMaxRead1File_01` → `…_P<k>_Read_1.txt` |
| `Read_2` | `User.SpectraMaxRead2File_01` → `…_P<k>_Read_2.txt` |

Set the export to **text (.txt), column/list layout, one row per well**. **Plate (grid) layout is rejected**, with a message saying so.

The parser accepts a file when it finds a header row containing:
- a **well column**, named `Well`, `Wells`, `Well Position`, `Position` or `Plate Position` (case and spaces ignored), and
- **wavelength columns**: a heading containing exactly one number, 230, 260 or 280. `260`, `A260`, `OD260`, `260nm` and `Values 260` all qualify. Ratio and pathlength columns are excluded.
- *(optional)* a column whose name contains **"path"**, holding a per-well pathlength in cm (§3, option B).

Tab, comma or semicolon separators are all fine. The SoftMax `##BLOCKS` preamble and the `~End` trailer are skipped. Non-numeric cells such as `Range?` or `#Sat` are treated as **no result**, which flags the well. They are never read as zero.

**VERIFY before the first wet run:**
1. Read a test plate in each section and export it through MM4.
2. Open the file and confirm it has one row per well and a 260 column.
3. Run the offline harness (`Tests/ReaderNormVI_SpectraMax_Harness.cs`, build instructions in its header), or a single-plate dry run, so the script parses it.

If SoftMax's headings differ from the rules above, report the exact header line so the parser aliases can be extended. **Don't** reshape files by hand.

## 3. Pathlength: pick one

The script converts each reading to the neat-sample, 1 cm equivalent:

`A_eq = (A_raw − A_blank) × DF / L`

**DF** is the dilution factor (QuantSampleVolume + QuantDiluentVolume) / QuantSampleVolume, which is 10 by default.

**Option A (recommended): configured pathlength.**
- Keep PathCheck off.
- Calibrate the effective pathlength of the chosen plate at the fill volume (5 + 45 = 50 µL) once, then put it in the worklist header as `ReaderPathlengthCm`.
- Calibration method:
  1. Measure a stable reference (for example a nucleic-acid or dye standard) in a 1 cm cuvette to get OD₁cm.
  2. Fill ≥ 16 wells with 50 µL of the same reference, and another ≥ 16 with 50 µL diluent. Read both.
  3. Calculate L = mean(OD_ref − OD_diluent) / OD₁cm.
- Alternatively, run PathCheck once on 50 µL water in this plate and use the mean reported pathlength.
- Repeat the calibration whenever the plate type, fill volume or reader changes.
- If `ReaderPathlengthCm` is blank and the export has no pathlength column, **the run stops**. No pathlength is ever assumed.

**Option B: per-well PathCheck pathlength.** Use this only if SoftMax can export the per-well pathlength as its own column alongside the **raw** OD. The OD columns must not themselves be PathCheck-normalized, or the pathlength is applied twice. The script uses the per-well value whenever that column is present. **VERIFY** that the export really has raw OD plus pathlength before choosing this option.

## 4. MM4 device setup (on the target Lynx PC)

The GSK Demo workspace doesn't contain the SpectraMax device yet. It was deliberately not added, because the existing v0_2_5 method in this workspace still uses the SR710. Add it like this:

1. **Device configuration.** Use the `SpectraMaxTest` workspace as the template. Add the SpectraMax device to the workspace configuration in MM4: `SpectraMaxTest/Configuration/SpectraMax.config` and its entry in `SpectraMaxTest/Workspace.config`.
   - Set `<Connection>` to the PC running SoftMax Pro (127.0.0.1 if local).
   - Set `<Simulation>False</Simulation>` on the real system.
2. **Initialization.** Add the SpectraMax to `InitializeOrder.xml`, using the same entry as SpectraMaxTest (device id `51bca03b-…`).
3. **SoftMax Pro automation.** SoftMax Pro has to be installed with its automation interface available. The driver uses `SoftMaxPro.AutomationClient`. Start SoftMax Pro before initializing MM4, or confirm the driver's server launches it.
4. **SR710.** If this Lynx physically has no SR710, then on that system remove the `SR710` barcode reader and `BarCodeZAxis` from the hardware configuration (`Lynx.config`, `InitializeOrder.xml`) so initialization doesn't fault on missing hardware. v0_3_0 contains no SR710 commands.
5. **Drawer teach.** Teach `Loc_28` as the SpectraMax drawer plate position (open drawer). v0_3_0 moves plates straight between the deck and `Loc_28`; the Lunatic turntable hop through `Loc_29` has been removed. Confirm that A1 is in the corner the reader expects, so the gripper doesn't rotate the plate.
6. **Quant labware.** The quant plate handles (`Lunatic_01..04`, names unchanged in this revision) must point at the **half-area UV plate** labware definition. Give it correct well depth and bottom, plus aspirate/dispense heights for 50 µL, so the stamp and mix land in the liquid.

## 5. Fill in the `SPECTRAMAX:` steps in the method

`Quant_Norm_SpectraMax_v0_3_0.met` contains comment steps beginning `SPECTRAMAX:` where the reader commands go. Add each command directly below its comment (or replace the comment):

| Where | Commands |
|---|---|
| Before each **Put Plate → Loc_28** | `Drawer Control(SpectraMax)`: open, wait to finish |
| After each **Put Plate → Loc_28** | `Drawer Control(SpectraMax)`: close, wait to finish |
| Blank loop, after `PREPARE_BLANK` | `Open File(SpectraMax)`: `QuantNorm_RNA` protocol → `Select Section`: `Blank` → `Start Read` (wait) → `Export Section As`: file = `User.SpectraMaxBlankFile_01` |
| Sample loop, after `PREPARE_READER` | `Select Section`: `Read_1` → `Start Read` → `Select Section`: `Read_2` → `Start Read` → `Export Section As`: `Read_1` → `User.SpectraMaxRead1File_01`, `Read_2` → `User.SpectraMaxRead2File_01` |
| Before each **Get Plate ← Loc_28** | `Drawer Control`: open |
| After each **Get Plate ← Loc_28** | `Drawer Control`: close |

Notes:
- **Open File once per plate, in the blank loop**, so every plate starts from a clean document. The sample loop then reads into the same document's `Read_1`/`Read_2` sections.
  - **VERIFY:** the document must still be open when the sample loop runs, because other plates' blank reads happen in between. If each plate's blank read replaces the document, either re-open the protocol in the sample loop too, or keep **one document per plate** by saving it after the blank read (`.sdax`, under the run's Output folder) and re-opening it in the sample loop. This depends on driver behaviour and must be checked on the instrument.
- Set *Wait to finish* on every reader command. ReaderNormVI refuses an export file older than the matching PREPARE step, so a read that hasn't finished shows up as a named failure, not stale data.
- Keep the existing **ReaderNormVI Run Script** step and its abort check right after the export in both loops. Remember that the blank loop calls it in the BLANK phase and the sample loop in the SAMPLE phase; RunGuard sets the phase.

## 6. Worklist header keys (new, all optional)

| Key | Default | Notes |
|---|---|---|
| `QuantSampleVolume(uL)` | 5 | ≥ 2 µL (VVP96 floor) |
| `QuantDiluentVolume(uL)` | 45 | sample + diluent ≤ 150 µL |
| `QuantPlateType` | "96-well half-area UV plate (part number TBD)" | Goes into the run record |
| `ReaderPathlengthCm` | *(none)* | Required unless the export has a pathlength column (§3) |
| `ReaderLowSignalOD` | 0.01 | Blank-corrected raw A260 below this → `low_signal` flag (does not block normalization) |
| `ReaderModel` | SpectraMax | |

## 7. First-run checklist

- [ ] Protocol saved, versioned, with sections `Blank` / `Read_1` / `Read_2` and identical 230/260/280 endpoint settings
- [ ] No SoftMax plate blank or template blanks; PathCheck as decided (§3)
- [ ] Export layout is column/list, verified against the parser
- [ ] `ReaderPathlengthCm` calibrated and in the worklist header (option A)
- [ ] SpectraMax device added, simulation off, initializes; SR710 removed if absent
- [ ] `Loc_28` taught to the drawer; A1 orientation confirmed
- [ ] Quant plate labware set to the half-area UV plate; 50 µL heights checked
- [ ] All `SPECTRAMAX:` comment steps have their commands
- [ ] Dry run with water: blank read stores 96 blanks; sample read gives A_eq ≈ 0 and every well `low_signal` (expected with water)
- [ ] Wet run with a reference RNA of known concentration: result within the agreed accuracy (PQ-003)
