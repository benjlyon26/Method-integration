using System;
using System.Collections.Generic;
using System.IO;

namespace MM4DeviceInstaller
{
	public sealed class WorkspaceChoice
	{
		public string Name { get; set; }
		public string DirectoryPath { get; set; }

		public override string ToString()
		{
			return Name;
		}
	}

	public static class Locations
	{
		public const string DefaultDataRoot = @"C:\MethodManager4";

		public static string FindProgramFolder()
		{
			string[] candidates = new string[]
			{
				@"C:\Program Files (x86)\Dynamic Devices\MethodManager4",
				@"C:\Program Files\Dynamic Devices\MethodManager4"
			};
			foreach (string candidate in candidates)
			{
				if (File.Exists(Path.Combine(candidate, "MethodManager.DX.exe")))
				{
					return candidate;
				}
			}
			return candidates[0];
		}

		public static bool ProgramFolderLooksValid(string folder)
		{
			return !string.IsNullOrWhiteSpace(folder)
				&& File.Exists(Path.Combine(folder, "MethodManager.DX.exe"));
		}

		public static string DevicesLibrary(string programFolder)
		{
			return Path.Combine(programFolder, "Libraries", "Devices");
		}

		public static string NormalizeProgramFolder(string selected)
		{
			if (string.IsNullOrWhiteSpace(selected))
			{
				return "";
			}
			string full = Path.GetFullPath(selected.Trim());
			if (File.Exists(Path.Combine(full, "MethodManager.DX.exe")))
			{
				return full;
			}
			DirectoryInfo parent = Directory.GetParent(full);
			if (parent != null && File.Exists(Path.Combine(parent.FullName, "MethodManager.DX.exe")))
			{
				return parent.FullName;
			}
			if (parent != null && parent.Parent != null && File.Exists(Path.Combine(parent.Parent.FullName, "MethodManager.DX.exe")))
			{
				return parent.Parent.FullName;
			}
			return full;
		}

		public static List<WorkspaceChoice> ListWorkspaces(string selected)
		{
			List<WorkspaceChoice> list = new List<WorkspaceChoice>();
			if (string.IsNullOrWhiteSpace(selected) || !Directory.Exists(selected))
			{
				return list;
			}
			string full = Path.GetFullPath(selected.Trim());
			if (File.Exists(Path.Combine(full, "Workspace.config")))
			{
				list.Add(new WorkspaceChoice
				{
					Name = Path.GetFileName(full),
					DirectoryPath = full
				});
				return list;
			}
			string container = full;
			string nested = Path.Combine(full, "Workspaces");
			if (Directory.Exists(nested))
			{
				container = nested;
			}
			string[] dirs = Directory.GetDirectories(container);
			Array.Sort(dirs, StringComparer.OrdinalIgnoreCase);
			foreach (string dir in dirs)
			{
				if (!File.Exists(Path.Combine(dir, "Workspace.config")))
				{
					continue;
				}
				list.Add(new WorkspaceChoice
				{
					Name = Path.GetFileName(dir),
					DirectoryPath = dir
				});
			}
			return list;
		}
	}
}
