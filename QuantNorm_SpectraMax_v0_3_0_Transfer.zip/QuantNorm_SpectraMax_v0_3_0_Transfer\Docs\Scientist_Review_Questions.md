# In vivo RNA Quant/Norm on the SpectraMax: decisions for scientific review

**Method:** Quant_Norm_SpectraMax_v0_3_0. This is the Lilly in vivo RNA quantification and normalization workflow (MRS v0.1), adapted from the Lunatic to a SpectraMax plate reader with a 96-well plate. The system also has no deck barcode reader.

**Why we need your input.** The original spec was written around the Lunatic, which reads 2 µL of neat sample, and around an automated deck barcode scan. Neither applies to this system. Automation has built the method with the **provisional defaults** marked ★ below so it can be tested. **The final call on each item is yours.** Every ★ value can be changed in the worklist header or with a small method change, and none needs re-engineering.

For each question, tick an option or write your own answer, and add any notes. Where an answer differs from the spec, it is recorded as a deviation for Lilly.

---

## A. Barcodes and sample identity

### Q1. How should plate barcodes be captured without a deck scanner?
The Lynx can't read barcodes, so the method has to rely on the operator.
- ☐ ★ **Operator types each source plate barcode** when prompted. Barcodes are still checked against the worklist, and a mismatch stops the run with the option to re-enter or abort. Quant and output plates aren't barcoded; the method takes them from the same deck row and records a generated tracking ID in the completed worklist.
- ☐ **Handheld USB barcode scanner.** The same prompt, but the operator scans the plate label instead of typing. This removes typos and needs no method change. *(Recommended to consider: low cost and the same workflow.)*
- ☐ **Type every plate**, including quant and output plates, each checked against the worklist.
- ☐ **Type each barcode twice**, and accept it only if both entries match.
- Notes / decision: ______________________

### Q2. Are generated tracking IDs acceptable for the quant and output plates in the completed worklist (Appendix B fields 9 and 11)?
The spec expects scanned barcodes in these fields. Without a scanner, the method writes a generated ID tied to the run and deck position.
- ☐ ★ Yes, generated IDs are acceptable
- ☐ No. Output plates must carry real barcodes (see Q1 options), because they go downstream to qPCR or sequencing.
- Notes / decision: ______________________

---

## B. Quantification plate, dilution and read volumes

### Q3. Quantification scheme: sample volume, diluent volume and dilution
A standard 96-well plate can't read 2 µL neat the way the Lunatic does. Sample is diluted into a pre-filled well and then read. The dilution sets the **lowest concentration we can measure** and how much sample each well uses.

The figures below are approximate. They assume a ~0.3 cm effective pathlength and a 0.01 OD lowest reliable reading; real numbers come from calibration (Q8).

| Option | Sample + diluent | Dilution | ≈ Lowest measurable (neat) | Sample used from the source well |
|---|---|---|---|---|
| ★ A | 5 µL + 45 µL, half-area UV plate | 1:10 | ~13 ng/µL | 5 µL |
| B | 2 µL + 48 µL, half-area UV plate | 1:25 | ~33 ng/µL | 2 µL |
| C | 2 µL + 98 µL, full-area UV plate | 1:50 | ~65 ng/µL (**above the 50 ng/µL target**) | 2 µL |
| D | 10 µL + 40 µL, half-area UV plate | 1:5 | ~7 ng/µL | 10 µL |

- Which option, or what other volumes? ______________________
- Can every source well spare this volume on top of the normalization transfer? The spec minimum is 25 µL per well. ☐ Yes ☐ No: ______

### Q4. Which quantification plate (part number)?
It has to be UV-transparent down to 230 nm, low-binding and RNase-free. This replaces the Lunatic plate 701-2019 (CAPACITY-007), so RNA team approval is required.
- Candidates: Corning 96-well half-area UV-transparent plate; Greiner UV-Star half-area plate; other: ______
- Decision (part number): ______________________

### Q5. What liquid should the quant-plate diluent be?
This liquid is both the dilution buffer and the blank, and it affects the purity ratios.
- ☐ ★ **Nuclease-free water**, the same as the normalization diluent.
- ☐ **TE or 10 mM Tris, pH ~8.** A260/A280 depends on pH, and an unbuffered, slightly acidic solution such as water can lower the ratio. A buffer gives more reproducible ratios. Check that the buffer doesn't raise the 230 nm background.
- ☐ Other: ______
- Notes / decision: ______________________

### Q6. How should the sample be mixed into the quant well?
- ☐ ★ **3 pipette mixes of 20 µL** in the well after dispensing.
- ☐ Pipette mix plus a short shake in the reader before the read.
- ☐ Different mix volume or number of cycles: ______
- Notes / decision: ______________________

---

## C. Reading and blanking

### Q7. How should the reader be blanked?
There are no free wells on the quant plate for blanks.
- ☐ ★ **Per-well pre-read.** Read each diluent-filled plate before any sample is added, then subtract each well's own blank. This cancels well-to-well plate background, which matters at 230 nm. Cost: one extra read per plate (~1–2 min).
- ☐ **One fixed blank value per wavelength**, measured during validation. Faster, but plate-to-plate background differences go uncorrected.
- ☐ **Reserve blank wells**, for example column 12. This loses sample capacity, so plates can't be full.
- Notes / decision: ______________________

### Q8. How should pathlength be handled?
A plate well isn't a 1 cm cuvette, so readings are corrected to 1 cm before the 40 µg/mL-per-A260 factor is applied.
- ☐ ★ **Calibrated constant.** Determine the plate's effective pathlength at the chosen fill volume once, during validation, and use it for every run. It is re-calibrated if the plate or volume changes.
- ☐ **PathCheck per well.** The reader measures the pathlength of each well on every read. This needs confirmation that the SoftMax export can deliver it alongside the raw OD.
- Notes / decision: ______________________

### Q9. What should the duplicate read (QUANT-004) be?
- ☐ ★ **The same well read twice**: two identical reads back to back. This checks reader repeatability. It does **not** catch a pipetting error in the stamp, because both reads see the same well.
- ☐ **Two separate wells per sample**, stamped twice. This catches stamp and pipetting errors, but needs twice the quant plates and twice the sample volume.
- Notes / decision: ______________________

### Q10. How strict should duplicate agreement be?
The spec says "within 10%", but not 10% of what.
- ☐ ★ 10% of the **mean** of the two reads
- ☐ 10% of the **lower** read (stricter)
- ☐ A different tolerance: ______
- ☐ An absolute tolerance at low signal, for example ±0.005 OD below 0.05 OD, where 10% is smaller than reader noise.
- Notes / decision: ______________________

### Q11. Should the reader shake the plate before reading?
- ☐ ★ No shake
- ☐ Short, low-intensity shake before Read_1 only, to clear bubbles left by mixing
- Notes / decision: ______________________

---

## D. Flags and limits

### Q12. Where should the low-signal limit be?
Wells with a blank-corrected A260 below this are flagged `low_signal`. They are flagged, not rejected.
- ☐ ★ 0.01 OD (raw, before dilution and pathlength correction)
- ☐ Other: ______
- Should low-signal wells **still be normalized**? Currently they are transferred neat, as the spec requires for below-target samples. ☐ Yes ☐ No, skip them

### Q13. Purity flag thresholds (QUANT-TBD-003 / -004)
Below threshold, a well is flagged but still normalized.
- A260/A280 flag below: ☐ 1.7 (spec reference) ☐ other: ______ ☐ no flag
- A260/A230 flag below: ☐ 1.7 (spec reference) ☐ other: ______ ☐ no flag

### Q14. What should happen to wells that can't be normalized (TBD-011)?
For example, wells whose duplicates disagree, that have no reading, or whose volume is out of range.
- ☐ ★ **Leave untouched.** The output well gets neither sample nor diluent, so it can still be handled by hand. The well is flagged and reported.
- ☐ Dispense at the volume limit and annotate it
- ☐ Pause and ask the operator
- Notes / decision: ______________________

---

## E. Handling and sample integrity

### Q15. Should the deck or reader be temperature-controlled while the RNA is on deck (TBD-027)?
- ☐ ★ Ambient (reader incubator off)
- ☐ Chilled deck positions: ______
- Expected time on deck per plate: ______

### Q16. Should tips be reused between the stamp and the normalization transfer?
Today the same tips stamp sample into the quant well, mix it there, and are then reused to move that same sample from the source to the output plate. Because the tip has been in the diluted quant well, it can carry a little diluted sample or water back into the source well.
- ☐ Reuse tips, as now (fewer tip boxes)
- ☐ **Fresh tips for the normalization transfer** (+1 tip box per plate; recommended by automation)
- Notes / decision: ______________________

### Q17. Is a re-read after normalization required (TBD-029)?
For example, reading the output plate to confirm the final concentrations.
- ☐ ★ No
- ☐ Yes, on a subset or on all wells: ______

---

## F. Sign-off

| Role | Name | Date | Signature |
|---|---|---|---|
| RNA team / scientific owner | | | |
| QC | | | |
| Automation (Dynamic Devices) | | | |
