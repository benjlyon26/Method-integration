﻿using System;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Collections.Generic;
using System.Globalization;
using MethodManager.Core;
using MMScriptObjects;

// ============================================================================
// QuantNorm_OutputReport — Track B (LM900) In-Vivo RNA Quant/Norm, script 4 of the spine
// ============================================================================
// VERSION BAND 0.30.x (D-S20-01) so a version can never name the wrong script in a file picker.
//
// v0.30.0  2026-07-31  FIRST BUILD. Two files, per Jim: an HTML report to read, and the completed
//                      worklist to hand to Benchling.
//                      FOLDED IN SAME DAY (D-S19-10 — a fix or addition folds into a version that has
//                      never run and that nothing points at; v0.30.0 is not wired into the method):
//                        * A SECOND TAB carrying the completed worklist, rendered from the CSV TEXT
//                          THAT WAS ACTUALLY WRITTEN rather than rebuilt from the same data — a
//                          reconstruction can agree with the writer and both still be wrong.
//                        * A 96-WELL PLATE GRAPHIC per source plate (Jim): generic plate, wells as
//                          circles, rows A-H and columns 1-12 labelled, and the two NORMING VOLUMES
//                          printed inside each well — sample on top, diluent below.
//                          ⚠ CALCULATED VALUES ONLY. No leading air gap, no over-dispense stroke.
//                          Those are instrument mechanics; this picture is what goes into the well.
// v0.30.2  2026-07-31  VO LISTS SPLIT ON '&', NOT '-'. One character; 131 of 133 wells.
//                      A VI list is dash-separated and a VO list is '&'-separated (D-S20-11, and the
//                      method's own ListBuilders say so). This script used the DASH splitter for both.
//                      WHY IT SURVIVED THE FIRST RUN AND NOT THE SECOND: the dash split only shatters
//                      a stream that CONTAINS a dash, and the two streams differ —
//                        Sample_Dispense_VO  has no negative numbers -> dash split left it whole
//                        Sample_Aspirate_VO  carries a per-record '-2.9' -> dash split produced 134
//                                            fragments out of a 2-element list
//                      v0.30.1 moved the comparison ONTO the aspirate stream, i.e. onto the one
//                      stream the parser was destroying, so 131 wells reported "no result".
//                      Both faults were mine and the run was correct both times.
//                      GUARDED: the fixture now carries a negative number in the aspirate VO, so a
//                      dash split cannot pass the suite again.
//
// v0.30.1  2026-07-31  THE COMPARISON FIX, AND A VERSION THAT SHOULD HAVE EXISTED SOONER.
//                      ⚠ PROCESS FAILURE, RECORDED RATHER THAN TIDIED AWAY. v0.30.0 RAN on MM4 at
//                      11:57 and is wired at method step [157]. Under D-S18-25 that makes it RELEASED
//                      and frozen. The comparison fix below was nevertheless folded INTO v0.30.0 in
//                      place, on the stale reasoning that it "had never run" — which had been true an
//                      hour earlier and was not true any more. That is the same label-lies-about-
//                      content defect this project fixed at S19 and ruled on again at S20.
//                      CONSEQUENCE, STATED PLAINLY: the exact bytes that produced
//                      QuantNorm_output-report_20260731_115710.html are GONE. Registry hash
//                      65eea57fe… is the only surviving record of them. They are NOT reconstructed
//                      here — a reconstruction that is not byte-identical is worse than no file
//                      (D-S20-13). v0.30.1 is this content under an honest label.
//
//                      CORRECTED after the first real run (2026-07-31 11:57), which flagged all 133
//                      rows as CHECK. THE RUN WAS CORRECT; THIS COMPARISON WAS WRONG.
//                      ⚠ THE DISPENSE VO REPORTS THE COMMANDED VOLUME, INCLUDING THE OVER-DISPENSE
//                      STROKE — 45.0 where 25 was calculated, 95.0 where 75 was. It is NOT the liquid
//                      delivered. v0.30.0's first cut compared that number against the calculated
//                      volume and so disagreed on every single well.
//                      THE FIX: each VO is compared against ITS OWN command's expectation.
//                        * the ASPIRATE VO carries the volume actually drawn and is NOT inflated by
//                          the stroke, so THAT is what the calculated volume is checked against;
//                        * the DISPENSE VO is the stroke. It is expected to EXCEED the calculated
//                          volume, so it is reported as a run-level fact per plate rather than
//                          compared per well — and a stroke SMALLER than the volume is a real fault
//                          and is flagged.
//                      ⚠ NOT ASSUMED: that the aspirate VO is clean. If it is missing the row says
//                      "no aspirate result" rather than silently falling back to the dispense.
//
// WHAT JIM ASKED FOR, and it is the whole design brief for the HTML:
//   "i want the output html of the output report script to be extremely simple to understand, VERY
//    intuitive while retaining the necessary level of detail to understand exactly what was expected
//    to happen and what actually happened."
//
// SO THE REPORT IS BUILT ON ONE IDEA: EXPECTED vs ACTUAL, side by side, at every level.
//   EXPECTED comes from the worklist and the normalization calculation — the VI we sent.
//   ACTUAL comes from the VO the instrument sent back.
//   Everything else on the page is context for those two columns.
// A reader who looks at nothing but the verdict line and the per-plate table should already know
// whether the run did what was asked. The per-well detail is there for the reader who then asks
// "which well?" — it is not the first thing on the page.
//
// THE FIVE REQUIREMENTS THIS CLOSES (all five were unmet for one reason — nothing wrote a file):
//   DATA-001    a completed worklist conforming to Appendix B v0.1
//   GEN-004     run parameters, volumes, readings, barcodes logged to that file on completion
//   WORKLIST-004 write back everything populated during the run
//   VERIFY-003  resolution actions logged to the run record
//   DATA-004    audit trail of operator interventions
//   (VERIFY-004 is NOT closed — see the named gaps below.)
//
// WHAT IS DELIBERATELY NOT GUESSED — three of them, all surfaced ON the report rather than hidden:
//
//   1. TBD-023, THE HEADER-BLOCK CARRIER. B.2.1 says the run-metadata block is "a header preamble of
//      'Field: Value' pairs above the per-row CSV header, or a sidecar JSON file referenced by
//      filename convention", B.5 adds "or as both", and the choice is "selected by Dynamic Devices and
//      Benchling administrators". IT IS UNANSWERED (confirmed with Jim 2026-07-31). So this script
//      does not pick one: HEADER_CARRIER is a switch, and it DEFAULTS TO BOTH. That is the reversible
//      choice — an unwanted sidecar is deleted in a second, a missing one is a rebuild — and the
//      report states which was written and that the question is open.
//
//   2. SCAN TIMESTAMPS. VERIFY-004 wants "all scanned barcodes, scan timestamps, and reconciliation
//      outcomes" in the run record. Barcodes and outcomes are available; SCAN TIMESTAMPS ARE CAPTURED
//      NOWHERE — not in any MM4 variable, not by any script. Jim's direction 2026-07-31: leave it as a
//      NAMED GAP. So the report prints the gap as a gap, with the requirement ID, rather than
//      quietly omitting it or inventing a time from when this script happened to run.
//
//   3. THE SIXTH VO SUB-FIELD. The variable form of a VO carries six middle fields where the CSV form
//      carries seven; which of %error/HPC was dropped is unsettled (architecture doc 4.4). This script
//      reads sub-field 1 (volume) and sub-field 3 (status), which ARE identified, and prints the rest
//      RAW AND UNLABELLED. Labelling a field we have not identified would put a guess in front of an
//      operator wearing the authority of a report.
//
// A NOTE ON WHERE THE COMPLETED WORKLIST COMES FROM. The S17 design proposed that ingestion create a
// working copy and each script write into it. That is not built. This script instead assembles the
// completed worklist AT THE END, from the original worklist re-read from disk (Stage 1) plus the MM4
// bridge (Stages 2a/2b) plus its own Stage 3. It closes DATA-001 today without touching two other
// released scripts.
// ⚠ THE TRADE-OFF, STATED: a run that dies before this script leaves NO completed worklist at all,
// where a progressively-written record would have kept Stages 1 and 2a. That is the exposure the S17
// design named, and it is accepted here deliberately, not overlooked.
//
// THE INPUT FILE IS NEVER MODIFIED. DATA-001 says write a completed worklist — a new artifact.
// Nothing in the spec authorises writing back into the file Benchling produced.
// ============================================================================

// v0.30.5: propagate current-run developer skips to the verdict and metadata;
// clarify host-side event timestamps and retained dispense-stroke limits.
// Reject explicit failed/malformed responses on an empty channel plan.
// v0.30.6: customer-neutral presentation release; execution logic is unchanged.
public class MMScriptExecutor : IMMScriptExecutor
{
    // v0.30.3  2026-10-07  Coordinated repair release; see CHANGELOG.md and README.md.
    // v0.30.4: match RunGuard CSV-aware VO trailer decoding.
    // v0.30.7: SpectraMax variant - run-metadata header adds ReaderModel, QuantPlateType, quant
    //          volumes + dilution factor, pathlength, low-signal limit, blank method and barcode-entry
    //          mode. Per-row schema (29 fields) unchanged.
    private const string SCRIPT_VERSION = "v0.30.7";

    // TBD-023 is open, so this is a switch and not a decision. "BOTH" is the reversible default.
    private const string HEADER_CARRIER = "BOTH";   // "PREAMBLE" | "SIDECAR" | "BOTH"

    // ---- what the run was ----
    const string V_RUNID    = "User.RunID_01";
    const string V_WLFILE   = "User.WorklistFile_01";
    const string V_COUNT    = "User.TransferCount_01";
    const string V_PLATECNT = "User.ScanPlateCount_01";
    const string V_TESTMODE = "User.RunIsTestMode_01";

    // ---- run-metadata header block (DATA-002) ----
    const string V_SCALE    = "User.InputScale_01";
    const string V_EXTCOEF  = "User.ExtinctionCoefficient_01";
    const string V_TARGET   = "User.TargetConcentration_01";
    const string V_OUTVOL   = "User.RequestedOutputVolume_01";
    const string V_ACCEPT   = "User.A260AcceptanceLogic_01";

    // ---- per-row bridge (one element per worklist row, leading comma) ----
    const string L_SRCBC    = "User.SourcePlateBarcode_List_01";
    const string L_SRCWELL  = "User.SourceWell_List_01";
    const string L_QWELL    = "User.QuantWell_List_01";
    const string L_OWELL    = "User.OutputWell_List_01";
    const string L_QBC      = "User.QuantBarcode_List_01";
    const string L_OBC      = "User.OutputBarcode_List_01";
    const string L_A260_1   = "User.A260_1_List_01";
    const string L_A260_2   = "User.A260_2_List_01";
    const string L_ACCA260  = "User.AcceptedA260_List_01";
    const string L_A280     = "User.A280_List_01";
    const string L_A230     = "User.A230_List_01";
    const string L_CALCCONC = "User.CalculatedConcentration_List_01";
    const string L_XFERVOL  = "User.TransferVolume_List_01";
    const string L_DILVOL   = "User.DiluentVolume_List_01";
    const string L_PURITY   = "User.PurityFlag_List_01";
    const string L_XFERSTAT = "User.TransferStatus_List_01";
    const string R_SRCPLATE = "User.Row_SourcePlate_List_01";
    const string R_QPLATE   = "User.Row_QuantPlate_List_01";
    const string R_OPLATE   = "User.Row_OutputPlate_List_01";

    // ---- plate-major ----
    const string P_SRCPLATE = "User.SourcePlate_List_01";
    const string P_QPLATE   = "User.QuantPlate_List_01";
    const string P_OPLATE   = "User.OutputPlate_List_01";

    // ---- the VO streams: what the instrument said it did. '&'-separated, one element per plate. ----
    const string VO_QUANT_ASP  = "User.QuantAsp_VO_List_01";
    const string VO_QUANT_DISP = "User.QuantDisp_VO_List_01";
    const string VO_DIL_ASP    = "User.Diluent_Aspirate_VO_List_01";
    const string VO_DIL_DISP   = "User.Diluent_Dispense_VO_List_01";
    const string VO_SMP_ASP    = "User.Sample_Aspirate_VO_List_01";
    const string VO_SMP_DISP   = "User.Sample_Dispense_VO_List_01";

    // ---- the VI streams: what we asked for. '-'-separated, one element per plate. ----
    const string VI_SMP_DISP   = "User.Sample_Dispense_VI_List_01";
    const string VI_DIL_DISP   = "User.Diluent_Dispense_VI_List_01";

    // ---- barcode audit ----
    const string A_SRC_SCAN = "User.Barcode_Scanned_List_01";
    const string A_SRC_RB   = "User.Barcode_Read_By_List_01";
    const string A_Q_SCAN   = "User.QuantBarcode_Scanned_List_01";
    const string A_Q_RB     = "User.QuantBarcode_Read_By_List_01";
    const string A_O_SCAN   = "User.OutputBarcode_Scanned_List_01";
    const string A_O_RB     = "User.OutputBarcode_Read_By_List_01";
    const string A_RESOLVE  = "User.BarcodeResolution_01";
    const string A_ATTEMPT  = "User.BarcodeAttempt_01";

    // ---- control ----
    const string V_MESSAGE  = "User.ScriptMessage_01";
    const string V_ABORT    = "User.AbortMethod_01";
    const string V_RECFILE  = "User.RunRecordFile_01";   // published so a later step can find it

    // Appendix B v0.1, in order. The completed worklist is written to THIS list, not to whatever
    // column order the input file happened to use — B.2 fixes the schema.
    static readonly string[] SCHEMA = new string[] {
        "ID","AnimalID","TissueType","StudyID","ExtractionKit","SampleCollectionTimestamp",
        "SourcePlateBarcode","SourceWell","QuantificationPlateBarcode","QuantificationWell",
        "OutputPlateBarcode","OutputWell","A260_1","A260_2","Accepted_A260","A280","A230",
        "A260_A280_Ratio","A260_A230_Ratio","CalculatedConcentration","TargetConcentration",
        "RequestedOutputVolume(uL)","TransferVolume(uL)","DiluentVolume(uL)","PurityFlag",
        "TransferStatus","TimestampCreated","TimestampLynxGenerated","TimestampCompleted" };

    private string runId = "", wlFile = "", outDir = "", recordPath = "", sidecarPath = "";
    private int rowCount = 0, plateCount = 0;
    private List<string> notes = new List<string>();      // named gaps + anything unresolved
    private List<Row> rows = new List<Row>();
    private List<PlateBlock> plates = new List<PlateBlock>();
    private string runEnd = "";
    private List<string> runErrors = new List<string>();
    private string csvText = "";   // the completed worklist exactly as written, for tab 2

    private class Row
    {
        public int No;
        public string SrcBc = "", SrcWell = "", QWell = "", OWell = "", QBc = "", OBc = "";
        public string SrcPlate = "", QPlate = "", OPlate = "";
        public string A1 = "", A2 = "", Acc = "", A280 = "", A230 = "", Conc = "";
        public string XferExpected = "", DilExpected = "";     // EXPECTED — what the calc asked for
        // ACTUAL, and there are TWO different actuals — they answer different questions.
        public string XferDrawn = "", DilDrawn = "";           // aspirate VO — the liquid drawn
        public string XferStroke = "", DilStroke = "";         // dispense VO — the commanded stroke
        public string Purity = "", Status = "";
        public bool Matched = false, Untouched = false;
        public string Disposition = "", Evidence = "", CalculatedAt = "", CompletedAt = "";
    }

    // One per plate set: the VO trailer is the provenance, and it identifies itself.
    private class PlateBlock
    {
        public int Index;
        public string SourcePlate = "", QuantPlate = "", OutputPlate = "";
        public string SampleDispTrailer = "", DiluentDispTrailer = "";
        public int WellsExpected = 0, WellsActual = 0, WellsAgree = 0, WellsDisagree = 0;
        public string SampleStroke = "", DiluentStroke = "";   // derived, not hardcoded
        public bool StrokeUniform = true;
        public string Timestamp = "";
    }

    public void Execute(IMMApp app)
    {
        try { Run(app); }
        catch (Exception ex)
        {
            Set(app, V_ABORT, "True");
            Set(app, V_MESSAGE, "The output report could not be written:\n\n" + ex.Message
                + "\n\nThe run itself has finished; this is a reporting failure. Tell your application engineer.");
            try { app.OutputMsg("[QuantNorm outputreport " + SCRIPT_VERSION + "] EXCEPTION: " + ex, true); }
            catch (Exception) { }
        }
    }

    private void Run(IMMApp app)
    {
        rows.Clear(); plates.Clear(); notes.Clear(); runErrors.Clear();
        Set(app, "User.OutputReportCheck_01", "False");
        if (Get(app, V_ABORT) == "True") runErrors.Add("An earlier operation aborted the run.");
        runId  = Get(app, V_RUNID);
        wlFile = Get(app, V_WLFILE);
        Qn.Require(runId.Length > 0, "Run ID is missing; the output cannot be attributed to a run.");
        if (Get(app, "User.RunGuardDevSkipRun_01") == runId)
        {
            int skipCount;
            if (!int.TryParse(Get(app, "User.RunGuardDevSkipCount_01"), out skipCount) || skipCount < 0)
                runErrors.Add("The current run has invalid developer-override metadata.");
            else if (skipCount > 0)
                runErrors.Add("Developer override: " + skipCount + " response check(s) were explicitly skipped, not passed. Record: "
                    + Get(app, "User.RunGuardDevSkipRecord_01"));
        }
        string snapshot = Get(app, "User.InputSnapshotFile_01");
        Qn.Require(File.Exists(snapshot) && Qn.HashFile(snapshot) == Get(app, "User.SourceWorklistHash_01"),
            "The immutable input snapshot is missing or changed.");
        if (!File.Exists(wlFile) || Qn.HashFile(wlFile) != Get(app, "User.SourceWorklistHash_01"))
            notes.Add("The original input changed after ingestion. Stage-1 metadata below are from the frozen input snapshot.");
        wlFile = snapshot;

        // Report folder from the workspace, NOT from another script's variable. ReportPath_01 starts
        // life as a folder and is overwritten with a FILE path, which sent an earlier report to %TEMP%.
        outDir = app.WorkspaceOutputPath;
        try { if (!Directory.Exists(outDir)) Directory.CreateDirectory(outDir); }
        catch (Exception ex) { throw new IOException("The workspace output folder is not writable.", ex); }

        int.TryParse(Get(app, V_COUNT), out rowCount);
        int.TryParse(Get(app, V_PLATECNT), out plateCount);

        BuildRows(app);
        BuildPlates(app);
        NameTheGaps(app);

        recordPath = WriteCompletedWorklist(app);
        string html = WriteHtml(app);

        Set(app, V_RECFILE, recordPath);
        bool verified = Get(app, V_ABORT) != "True" && rows.Any(r => !r.Untouched) && rows.All(r => r.Matched || r.Untouched) && runErrors.Count == 0;
        Set(app, "User.OutputReportCheck_01", verified ? "True" : "False");
        if (!verified) Set(app, V_ABORT, "True");
        Set(app, V_MESSAGE, Verdict() + "  Completed worklist: " + recordPath);
        try { app.OutputMsg("[QuantNorm outputreport " + SCRIPT_VERSION + "] " + Verdict()
            + "  report: " + html + "  worklist: " + recordPath, false); }
        catch (Exception) { }
        OpenReport(html);
    }

    // ---------------------------------------------------------------------------------------
    //  EXPECTED vs ACTUAL — the whole point. Expected is the VI we sent; actual is the VO we got.
    // ---------------------------------------------------------------------------------------
    private void BuildRows(IMMApp app)
    {
        Qn.Require(rowCount > 0 && rowCount <= 384 && plateCount > 0 && plateCount <= 4, "Invalid run counts in the report bridge.");
        string[] required = new string[] { L_SRCBC, L_SRCWELL, L_QWELL, L_OWELL, L_QBC, L_OBC,
            R_SRCPLATE, R_QPLATE, R_OPLATE, L_XFERVOL, L_DILVOL, "User.RowDisposition_List_01" };
        foreach (string name in required) Qn.Require(L(app, name).Count == rowCount, "Incomplete row list: " + name);
        var planStatus = L(app, "User.NormalizationPlateStatus_List_01");
        var planRuns = L(app, "User.NormalizationPlateRun_List_01");
        var sp = L(app, P_SRCPLATE); var qp = L(app, P_QPLATE); var op = L(app, P_OPLATE);
        Qn.Require(sp.Count == plateCount && qp.Count == plateCount && op.Count == plateCount && op.Distinct().Count() == plateCount,
            "Incomplete or ambiguous per-plate report mapping.");
        string[] voNames = new string[] { VO_SMP_ASP, VO_SMP_DISP, VO_DIL_ASP, VO_DIL_DISP, VO_QUANT_ASP, VO_QUANT_DISP };
        string[] viNames = new string[] { "User.Sample_Aspirate_VI_List_01", VI_SMP_DISP,
            "User.Diluent_Aspirate_VI_List_01", VI_DIL_DISP, "User.Quant_Aspirate_VI_List_01", "User.Quant_Dispense_VI_List_01" };
        var responseSets = new List<List<QnEvidence.Response>>();
        var expectedSets = new List<List<string[]>>();
        for (int operation = 0; operation < voNames.Length; operation++)
        {
            var responses = new List<QnEvidence.Response>(); var expected = new List<string[]>();
            var actualList = Amp(Get(app, voNames[operation])); var desiredList = Dash(Get(app, viNames[operation]));
            if (actualList.Count != plateCount) runErrors.Add("Wrong plate count in " + voNames[operation]);
            for (int slot = 0; slot < plateCount; slot++)
            {
                string physical = operation == 0 || operation == 4 ? sp[slot] : operation == 2 ? "Diluent" : operation == 5 ? qp[slot] : op[slot];
                responses.Add(QnEvidence.Read(At(actualList, slot), physical, operation % 2 == 0 ? "Aspirate" : "Dispense"));
                try
                {
                    expected.Add(QnEvidence.VI(At(desiredList, slot)));
                    try { QnEvidence.CheckAll(At(actualList, slot), At(desiredList, slot), physical, operation % 2 == 0 ? "Aspirate" : "Dispense"); }
                    catch (Exception ex) { runErrors.Add(voNames[operation] + " plate " + (slot + 1) + ": " + ex.Message); }
                }
                catch (Exception) { expected.Add(new string[97]); runErrors.Add("Missing/invalid VI plan in " + viNames[operation] + " plate " + (slot + 1)); }
            }
            responseSets.Add(responses); expectedSets.Add(expected);
        }
        for (int slot = 0; slot < plateCount; slot++)
            if (At(planStatus, slot) != "READY" || At(planRuns, slot) != runId)
                runErrors.Add("Plate " + (slot + 1) + " has no current successful normalization calculation.");
        for (int i = 0; i < rowCount; i++)
        {
            var r = new Row { No = i + 1, SrcBc = At(L(app, L_SRCBC), i), SrcWell = At(L(app, L_SRCWELL), i),
                QWell = At(L(app, L_QWELL), i), OWell = At(L(app, L_OWELL), i),
                QBc = At(L(app, L_QBC), i), OBc = At(L(app, L_OBC), i),
                SrcPlate = At(L(app, R_SRCPLATE), i), QPlate = At(L(app, R_QPLATE), i), OPlate = At(L(app, R_OPLATE), i),
                A1 = At(L(app, L_A260_1), i), A2 = At(L(app, L_A260_2), i), Acc = At(L(app, L_ACCA260), i),
                A280 = At(L(app, L_A280), i), A230 = At(L(app, L_A230), i), Conc = At(L(app, L_CALCCONC), i),
                XferExpected = At(L(app, L_XFERVOL), i), DilExpected = At(L(app, L_DILVOL), i),
                Purity = At(L(app, L_PURITY), i), Status = At(L(app, L_XFERSTAT), i),
                Disposition = At(L(app, "User.RowDisposition_List_01"), i),
                CalculatedAt = At(L(app, "User.RowCalculationTimestamp_List_01"), i) };
            int slot = op.IndexOf(r.OPlate), channel = Qn.Channel(r.OWell);
            Qn.Require(slot >= 0 && channel > 0 && r.SrcPlate == sp[slot] && r.QPlate == qp[slot], "Row/plate mapping is inconsistent in the output report.");
            r.Untouched = r.Disposition == "SKIPPED" && r.CalculatedAt.Length > 0 && r.XferExpected.Length == 0 && r.DilExpected.Length == 0;
            var errors = new List<string>();
            if (!r.Untouched && (r.Disposition != "CALCULATED" && r.Disposition != "CALCULATED_BELOW_TARGET"))
                errors.Add("Missing explicit calculation disposition");
            r.XferDrawn = QnEvidence.Volume(responseSets[0][slot], r.OWell);
            r.XferStroke = QnEvidence.Volume(responseSets[1][slot], r.OWell);
            r.DilDrawn = QnEvidence.Volume(responseSets[2][slot], r.OWell);
            r.DilStroke = QnEvidence.Volume(responseSets[3][slot], r.OWell);
            for (int operation = 0; operation < voNames.Length; operation++)
            {
                string error = QnEvidence.Check(responseSets[operation][slot], r.OWell, expectedSets[operation][slot][channel]);
                if (error.Length > 0) errors.Add(voNames[operation] + ": " + error);
            }
            if (!r.Untouched)
            {
                string sampleField = expectedSets[0][slot][channel] ?? "";
                string diluentField = expectedSets[2][slot][channel] ?? "";
                if (!Agrees(r.XferExpected, sampleField.Split(';')[0])) errors.Add("Recorded sample plan differs from aspiration VI");
                if (!Agrees(r.DilExpected, diluentField.Length == 0 ? "0" : diluentField.Split(';')[0])) errors.Add("Recorded diluent plan differs from aspiration VI");
            }
            else if (errors.Count > 0) r.Untouched = false; // skipped is not permission to ignore unexpected motion/errors
            r.Evidence = string.Join("; ", errors.ToArray());
            r.Matched = !r.Untouched && errors.Count == 0;
            r.CompletedAt = r.Matched ? responseSets[1][slot].Timestamp : "";
            if (r.Disposition == "CALCULATED_BELOW_TARGET") notes.Add("Row " + r.No + " was transferred undiluted; target concentration was NOT achieved.");
            rows.Add(r);
        }
        foreach (string error in runErrors.Distinct()) notes.Add("RUN CHECK: " + error);
    }

    private void BuildPlates(IMMApp app)
    {
        var sp = L(app, P_SRCPLATE); var qp = L(app, P_QPLATE); var op = L(app, P_OPLATE);
        var smpDisp = Amp(Get(app, VO_SMP_DISP));
        var dilDisp = Amp(Get(app, VO_DIL_DISP));
        int n = plateCount > 0 ? plateCount : sp.Count;
        for (int k = 0; k < n; k++)
        {
            var pb = new PlateBlock { Index = k + 1,
                SourcePlate = At(sp, k), QuantPlate = At(qp, k), OutputPlate = At(op, k),
                SampleDispTrailer = Trailer(At(smpDisp, k)),
                DiluentDispTrailer = Trailer(At(dilDisp, k)) };
            pb.Timestamp = LastField(pb.SampleDispTrailer);
            var sStroke = new List<double>(); var dStroke = new List<double>();
            foreach (Row r in rows)
            {
                if (r.OPlate != pb.OutputPlate) continue;
                if (!r.Untouched) pb.WellsExpected++;
                if (r.XferDrawn.Length > 0) pb.WellsActual++;
                if (!r.Untouched) { if (r.Matched) pb.WellsAgree++; else pb.WellsDisagree++; }
                double c, st;
                if (TryNum(r.XferExpected, out c) && TryNum(r.XferStroke, out st)) sStroke.Add(st - c);
                if (TryNum(r.DilExpected, out c)  && TryNum(r.DilStroke, out st))  dStroke.Add(st - c);
            }
            // The over-dispense is DERIVED from the run, never hardcoded here — this script must not
            // carry a second copy of a number that lives in the reader/norm script.
            pb.SampleStroke  = Uniform(sStroke, ref pb.StrokeUniform);
            pb.DiluentStroke = Uniform(dStroke, ref pb.StrokeUniform);
            plates.Add(pb);
        }
        // The run's finish time comes from the LAST plate's VO trailer — the instrument's own
        // timestamp, not this script's clock. Ingestion records the separate run-start timestamp.
        if (plates.Count > 0) runEnd = plates[plates.Count - 1].Timestamp;
    }

    // ---------------------------------------------------------------------------------------
    //  THE NAMED GAPS. Jim, 2026-07-31: leave scan timestamps as a named gap. So they are NAMED —
    //  printed on the report with the requirement they fail, not omitted and not invented.
    // ---------------------------------------------------------------------------------------
    private void NameTheGaps(IMMApp app)
    {
        notes.Add("Barcode capture-completion events and reconciliation attempts are recorded in " + Get(app, "User.BarcodeAuditFile_01")
            + ". Event times are host-side recording times, not timestamps generated by the scanner.");
        notes.Add("VERIFY-004 - Scanner-native timestamps are not available in this build. "
            + "The barcode audit records host-side capture-completion and reconciliation events. "
            + "Those recording times are not the scanner's own acquisition timestamps.");

        notes.Add("TBD-023 — THE RUN-METADATA HEADER FORMAT IS NOT SETTLED. Appendix B.2.1 allows a CSV "
            + "preamble or a JSON sidecar, B.5 allows both, and the choice belongs to DD and the receiving-system "
            + "administrators. It is unanswered, so this run wrote: " + HEADER_CARRIER
            + ". Changing it is a one-line change, not a rebuild.");

        string ver = Get(app, "User.LynxMethodVersion_01");
        if (ver.Length == 0)
            notes.Add("DATA-002 — LynxMethodVersion is not produced by anything in this build, so the "
                + "header block carries it EMPTY rather than a value invented here.");

        notes.Add("RunStartTimestamp is the ingestion start. Per-row calculation timestamps are from the calculation step; completion timestamps come from the corresponding dispense response when available.");

        int noDraw = 0;
        foreach (Row r in rows) if (!r.Untouched && r.XferDrawn.Length == 0) noDraw++;
        if (noDraw > 0)
            notes.Add("NO ASPIRATE RESULT for " + noDraw + " well(s). The aspirate VO is what says how "
                + "much liquid was actually drawn, so without it those wells cannot be checked against "
                + "the calculated volume. They are marked CHECK rather than compared against the dispense "
                + "stroke, which is a different number and would agree for the wrong reason.");

        foreach (PlateBlock pb in plates)
            if (!pb.StrokeUniform)
                notes.Add("The additional dispense stroke varies across wells on plate " + pb.Index
                    + ". Each response is checked against its own commanded VI. The retained command "
                    + "limit can cap the nominal +20 uL allowance; this variation is not by itself a delivery failure.");

        notes.Add("VO sub-fields — the method-variable form of a VO carries six middle fields where the "
            + "CSV form carries seven, and which of %error/HPC was dropped is not established. This "
            + "report reads only the two fields that ARE identified — the reported operation volume and the "
            + "status — and shows the rest raw and unlabelled.");
    }

    // =======================================================================================
    //  FILE 2 — the completed worklist. Appendix B v0.1, 29 fields, one row per sample.
    // =======================================================================================
    private string WriteCompletedWorklist(IMMApp app)
    {
        var stage1 = ReadStage1(wlFile);          // the columns Benchling authored, verbatim
        string stamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        var sb = new StringBuilder();

        if (HEADER_CARRIER == "PREAMBLE" || HEADER_CARRIER == "BOTH")
            foreach (string[] kv in HeaderBlock(app, stamp))
                sb.Append(kv[0]).Append(": ").Append(kv[1]).Append("\r\n");

        sb.Append(string.Join(",", SCHEMA)).Append("\r\n");

        foreach (Row r in rows)
        {
            var f = new List<string>();
            // Stage 1 — copied from the input file so nothing Benchling authored is re-typed here.
            // FQ-011 wants ExtractionKit preserved; a verbatim copy is what satisfies it.
            var s1 = Stage1For(stage1, r);
            f.Add(Pick(s1, "ID", r.No.ToString()));
            f.Add(Pick(s1, "AnimalID", "")); f.Add(Pick(s1, "TissueType", ""));
            f.Add(Pick(s1, "StudyID", "")); f.Add(Pick(s1, "ExtractionKit", ""));
            f.Add(Pick(s1, "SampleCollectionTimestamp", ""));
            f.Add(r.SrcBc); f.Add(r.SrcWell);
            f.Add(r.QBc);                                   // field 9  — Stage 2a
            f.Add(r.QWell);
            f.Add(r.OBc);                                   // field 11 — Stage 2a
            f.Add(r.OWell);
            f.Add(r.A1); f.Add(r.A2); f.Add(r.Acc); f.Add(r.A280); f.Add(r.A230);
            f.Add(Ratio(r.Acc, r.A280)); f.Add(Ratio(r.Acc, r.A230));
            f.Add(r.Conc);
            f.Add(Get(app, V_TARGET)); f.Add(Get(app, V_OUTVOL));
            // ⚠ THE CALCULATED VOLUMES, NOT THE COMMANDED ONES. The dispense VI carries a +20 uL
            // over-dispense stroke to empty the tip; the liquid that lands in the well is the
            // calculated volume. Writing the stroke here would overstate every row by 20 uL.
            f.Add(r.XferExpected); f.Add(r.DilExpected);
            f.Add(r.Purity);
            f.Add(TransferStatus(r));                       // field 26 — Stage 3
            f.Add(Pick(s1, "TimestampCreated", ""));
            f.Add(r.CalculatedAt);                          // field 28 — TimestampLynxGenerated
            f.Add(r.CompletedAt);                           // field 29 — TimestampCompleted
            sb.Append(string.Join(",", f.Select(Csv).ToArray())).Append("\r\n");
        }

        string path = Path.Combine(outDir, "QuantNorm_completed-worklist_" + runId + ".csv");
        csvText = sb.ToString();
        File.WriteAllText(path, csvText, new UTF8Encoding(false));

        if (HEADER_CARRIER == "SIDECAR" || HEADER_CARRIER == "BOTH")
        {
            var j = new StringBuilder("{\n");
            var hb = HeaderBlock(app, stamp);
            for (int i = 0; i < hb.Count; i++)
                j.Append("  \"").Append(hb[i][0]).Append("\": \"").Append(Json(hb[i][1]))
                 .Append(i < hb.Count - 1 ? "\",\n" : "\"\n");
            j.Append("}\n");
            sidecarPath = Path.ChangeExtension(path, ".json");
            File.WriteAllText(sidecarPath, j.ToString(), new UTF8Encoding(false));
        }
        return path;
    }

    // DATA-002. Anything not produced by this build is written EMPTY rather than invented.
    private List<string[]> HeaderBlock(IMMApp app, string stamp)
    {
        var h = new List<string[]>();
        h.Add(new string[]{ "Site", Get(app, "User.Site_01") });
        h.Add(new string[]{ "InputScale", Get(app, V_SCALE) });
        h.Add(new string[]{ "SourcePlateFormat", "96-well" });
        h.Add(new string[]{ "ExtinctionCoefficientUsed", Get(app, V_EXTCOEF) });
        h.Add(new string[]{ "TargetConcentration", Get(app, V_TARGET) });
        h.Add(new string[]{ "RequestedOutputVolume", Get(app, V_OUTVOL) });
        h.Add(new string[]{ "DiluentIdentity", Get(app, "User.DiluentIdentity_01") });
        h.Add(new string[]{ "A260AcceptanceLogic", Get(app, V_ACCEPT) });
        h.Add(new string[]{ "OperatorID", Get(app, "User.OperatorID_01") });
        h.Add(new string[]{ "LynxMethodVersion", Get(app, "User.LynxMethodVersion_01") });
        h.Add(new string[]{ "WorklistVersion", Get(app, "User.WorklistVersion_01") });
        h.Add(new string[]{ "RunStartTimestamp", Get(app, "User.RunStartTimestamp_01") });      // captured by ingestion — see gaps
        h.Add(new string[]{ "RunCompletionTimestamp", runEnd });
        h.Add(new string[]{ "ReportGeneratedTimestamp", stamp });
        h.Add(new string[]{ "ReaderDataSources", Get(app, "User.ReaderDataSource_List_01") });
        h.Add(new string[]{ "ReaderModel", Get(app, "User.ReaderModel_01") });
        h.Add(new string[]{ "QuantPlateType", Get(app, "User.QuantPlateType_01") });
        h.Add(new string[]{ "QuantSampleVolume(uL)", Get(app, "User.QuantSampleVolume_01") });
        h.Add(new string[]{ "QuantDiluentVolume(uL)", Get(app, "User.QuantDiluentVolume_01") });
        h.Add(new string[]{ "QuantDilutionFactor", Get(app, "User.QuantDilutionFactor_01") });
        h.Add(new string[]{ "ReaderPathlengthCm", Get(app, "User.ReaderPathlengthCm_01").Length > 0 ? Get(app, "User.ReaderPathlengthCm_01") : "PathCheck (per well)" });
        h.Add(new string[]{ "ReaderLowSignalOD", Get(app, "User.ReaderLowSignalOD_01") });
        h.Add(new string[]{ "BlankMethod", Get(app, "User.BlankMethod_01") });
        h.Add(new string[]{ "BarcodeEntry", "Manual (source); Generated tracking ID (quantification, output)" });
        h.Add(new string[]{ "BarcodeAuditFile", Get(app, "User.BarcodeAuditFile_01") });
        h.Add(new string[]{ "SourceWorklistSHA256", Get(app, "User.SourceWorklistHash_01") });
        bool thisRunHasSkipRecord = Get(app, "User.RunGuardDevSkipRun_01") == runId;
        h.Add(new string[]{ "DeveloperResponseChecksSkipped", thisRunHasSkipRecord ? Get(app, "User.RunGuardDevSkipCount_01") : "0" });
        h.Add(new string[]{ "DeveloperSkipRecord", thisRunHasSkipRecord ? Get(app, "User.RunGuardDevSkipRecord_01") : "" });
        h.Add(new string[]{ "RunID", runId });
        h.Add(new string[]{ "SourceWorklist", Path.GetFileName(Get(app, V_WLFILE)) });
        return h;
    }

    // Appendix B field 26: "Success | NA | failure code". Driven off the VO status, which is the only
    // thing that knows whether liquid moved.
    private string TransferStatus(Row r)
    {
        if (r.Untouched) return "NA";
        return r.Matched && runErrors.Count == 0 ? "Success" : "CHECK";
    }

    // =======================================================================================
    //  FILE 1 — the HTML. Simple by construction: verdict, then per plate, then per well.
    // =======================================================================================
    private string WriteHtml(IMMApp app)
    {
        int expected = 0, agree = 0, disagree = 0, missing = 0, untouched = 0;
        foreach (Row r in rows)
        {
            if (r.Untouched) { untouched++; continue; }
            expected++;
            if (r.XferDrawn.Length == 0) missing++;
            else if (r.Matched) agree++; else disagree++;
        }
        string cls = expected > 0 && disagree == 0 && missing == 0 && runErrors.Count == 0 ? "ok" : (agree == 0 ? "bad" : "warn");
        if (cls == "ok" && (untouched > 0 || rows.Any(r => r.Disposition == "CALCULATED_BELOW_TARGET"))) cls = "warn";

        var h = new StringBuilder();
        h.Append("<!doctype html><html><head><meta charset='utf-8'><title>QuantNorm run ")
         .Append(E(runId)).Append("</title><style>")
         .Append("body{font:16px/1.55 -apple-system,Segoe UI,Roboto,Arial,sans-serif;margin:0;background:#f6f7f9;color:#15191f}")
         .Append(".w{max-width:1100px;margin:0 auto;padding:26px}")
         .Append("h1{font-size:24px;margin:0 0 4px}h2{font-size:18px;margin:34px 0 10px;padding-bottom:6px;border-bottom:2px solid #dde2e9}")
         .Append(".sub{color:#5d6875;font-size:13px;margin-bottom:22px}")
         .Append(".verdict{border-radius:10px;padding:20px 24px;margin:0 0 22px;font-size:20px;font-weight:700}")
         .Append(".verdict.ok{background:#e6f4ec;border:2px solid #7cbf9b;color:#1f6f43}")
         .Append(".verdict.warn{background:#fff6e0;border:2px solid #e8b53f;color:#8a5a00}")
         .Append(".verdict.bad{background:#fdecec;border:2px solid #e08a8d;color:#9a2226}")
         .Append(".verdict .n{font-size:14px;font-weight:600;display:block;margin-top:6px;color:inherit;opacity:.85}")
         .Append(".cards{display:flex;gap:14px;flex-wrap:wrap;margin:0 0 6px}")
         .Append(".card{background:#fff;border:1px solid #dde2e9;border-radius:10px;padding:14px 18px;min-width:150px}")
         .Append(".card .k{font-size:12px;color:#5d6875;text-transform:uppercase;letter-spacing:.6px}")
         .Append(".card .v{font-size:26px;font-weight:700;margin-top:2px}")
         .Append("table{border-collapse:collapse;width:100%;background:#fff;font-size:14px}")
         .Append("th,td{border:1px solid #dde2e9;padding:7px 9px;text-align:left}")
         .Append("th{background:#f0f2f5;font-size:12px;text-transform:uppercase;letter-spacing:.5px;color:#5d6875}")
         .Append("td.num{text-align:right;font-variant-numeric:tabular-nums}")
         .Append("tr.diff td{background:#fdecec}tr.miss td{background:#fff6e0}tr.na td{color:#98a2b0}")
         .Append(".gap{background:#fff;border-left:5px solid #e8b53f;padding:12px 16px;margin:10px 0;font-size:14px}")
         .Append(".mono{font-family:ui-monospace,Consolas,monospace;font-size:12px;word-break:break-all}")
         .Append(".tabs{display:flex;gap:6px;border-bottom:2px solid #dde2e9;margin:0 0 22px}")
         .Append(".tabs label{padding:10px 18px;cursor:pointer;font-weight:600;font-size:14px;color:#5d6875;border:1px solid transparent;border-bottom:none;border-radius:8px 8px 0 0}")
         .Append("input.tabin{position:absolute;left:-9999px}")
         .Append("input.tabin:checked + label{background:#fff;border-color:#dde2e9;color:#15191f}")
         .Append(".pane{display:none}")
         .Append("#t1:checked ~ .panes #p1,#t2:checked ~ .panes #p2{display:block}")
         .Append(".plate{background:#fff;border:1px solid #dde2e9;border-radius:10px;padding:16px 18px;margin:0 0 22px;overflow-x:auto}")
         .Append(".plate h3{margin:0 0 4px;font-size:16px}")
         .Append(".plate .cap{color:#5d6875;font-size:13px;margin-bottom:12px}")
         .Append(".legend{display:flex;gap:18px;font-size:13px;color:#5d6875;margin:8px 0 0;flex-wrap:wrap}")
         .Append(".legend i{display:inline-block;width:12px;height:12px;border-radius:50%;border:2px solid #7cbf9b;margin-right:5px;vertical-align:-2px}")
         .Append(".legend i.d{border-color:#c62828}.legend i.u{border-color:#c9d0d8;background:#f2f4f7}")
         .Append("table.kv th{text-transform:none;font-size:13.5px;color:#15191f;font-weight:600}")
         .Append("@media print{body{background:#fff}.w{max-width:none}.tabs{display:none}.pane{display:block!important}}")
         .Append("</style></head><body><div class='w'>");

        h.Append("<h1>Quantification &amp; Normalization — run ").Append(E(runId)).Append("</h1>");
        // Radio-driven tabs — no JavaScript, so the page works from a file:// path and prints with
        // BOTH panes visible rather than losing the worklist to a hidden div.
        h.Append("<input class='tabin' type='radio' name='tab' id='t1' checked>")
         .Append("<input class='tabin' type='radio' name='tab' id='t2'>")
         .Append("<div class='tabs'><label for='t1'>Run report</label>")
         .Append("<label for='t2'>Completed worklist</label></div>")
         .Append("<div class='panes'><div class='pane' id='p1'>");
        h.Append("<div class='sub'>Worklist <b>").Append(E(Path.GetFileName(wlFile)))
         .Append("</b> &middot; ").Append(plates.Count).Append(" plate(s) &middot; ")
         .Append(rows.Count).Append(" sample row(s) &middot; ")
         .Append(E(RunMode(app))).Append("</div>");

        if (Get(app, "User.ReaderDataSource_List_01").IndexOf("SYNTHETIC", StringComparison.Ordinal) >= 0)
            h.Append("<div class='gap'><strong>SYNTHETIC READER DATA:</strong> the concentration inputs include test fixtures, not measured experimental results.</div>");

        // ---- THE VERDICT. One sentence, in the words an operator uses. ----
        h.Append("<div class='verdict ").Append(cls).Append("'>");
        h.Append(E(Verdict()));
        h.Append("<span class='n'>").Append(agree).Append(" of ").Append(expected)
         .Append(" wells agree &middot; ").Append(disagree).Append(" differ &middot; ")
         .Append(missing).Append(" have no result &middot; ").Append(untouched)
         .Append(" deliberately untouched</span></div>");

        h.Append("<div class='cards'>");
        Card(h, "Wells asked for", expected.ToString());
        Card(h, "Wells with aspiration results", (agree + disagree).ToString());
        Card(h, "Match", agree.ToString());
        Card(h, "Differ", disagree.ToString());
        Card(h, "Untouched", untouched.ToString());
        h.Append("</div>");
        h.Append("<div class='sub'><b>Untouched</b> means the calculation could not give that well a "
            + "volume — it was flagged and deliberately left dry, sample and diluent both. It is not a failure.</div>");

        // ---- PER PLATE: expected vs actual, the level most questions are answered at ----
        h.Append("<h2>By plate — what was asked for, and what came back</h2>");
        h.Append("<table><tr><th>Plate</th><th>Source</th><th>Output</th><th class='num'>Wells asked</th>")
         .Append("<th class='num'>Came back</th><th class='num'>Match</th><th class='num'>Differ</th>")
         .Append("<th>Dispense stroke</th><th>Finished (from the instrument)</th></tr>");
        foreach (PlateBlock p in plates)
        {
            h.Append("<tr><td>").Append(p.Index).Append("</td><td>").Append(E(p.SourcePlate))
             .Append("</td><td>").Append(E(p.OutputPlate))
             .Append("</td><td class='num'>").Append(p.WellsExpected)
             .Append("</td><td class='num'>").Append(p.WellsActual)
             .Append("</td><td class='num'>").Append(p.WellsAgree)
             .Append("</td><td class='num'>").Append(p.WellsDisagree)
             .Append("</td><td>").Append(p.SampleStroke.Length == 0 ? "&mdash;"
                 : "+" + E(p.SampleStroke) + " µL sample / +" + E(p.DiluentStroke) + " µL diluent")
             .Append("</td><td>").Append(E(p.Timestamp)).Append("</td></tr>");
        }
        h.Append("</table>");

        // ---- THE PLATE PICTURE. One per source plate, which is also one per plate SET, because
        //      the mapping is 1:1 (A1 -> A1 -> A1). This is the view that answers "what went where"
        //      without reading a single table row.
        h.Append("<h2>The plates — planned liquid volumes and response status</h2>");
        h.Append("<div class='sub'>Calculated norming volumes in µL: <b>sample on top, diluent below</b>. "
            + "These are planned liquid volumes; consult the response verdict before treating a well as completed. Leading air gaps and the over-dispense "
            + "stroke are instrument mechanics and are deliberately not shown here.</div>");
        foreach (PlateBlock p in plates) h.Append(PlateSvg(p));

        // ---- PER WELL: the detail, for the reader who then asks "which one?" ----
        h.Append("<h2>By well — expected against actual</h2>");
        h.Append("<div class='sub'><b>Asked for</b> is the volume the normalization calculated. "
            + "<b>Drawn</b> is what the instrument reported it aspirated. Those two should be the same "
            + "number. Status also requires successful command/channel statuses and matching dispense strokes.<br>"
            + "The <b>dispense</b> is deliberately commanded larger than the volume — an over-dispense "
            + "that empties the tip into the output plate — so it is shown once per plate above rather "
            + "than repeated on every row. It is a stroke, not extra liquid: you cannot dispense what "
            + "is not in the tip.</div>");
        h.Append("<table><tr><th>Row</th><th>Source well</th><th>Output plate</th><th>Output well</th>")
         .Append("<th class='num'>Sample asked for</th><th class='num'>Sample drawn</th>")
         .Append("<th class='num'>Diluent asked for</th><th class='num'>Diluent drawn</th>")
         .Append("<th>Status</th><th>Purity / evidence</th></tr>");
        foreach (Row r in rows)
        {
            string rc = r.Untouched ? "na" : (r.XferDrawn.Length == 0 ? "miss" : (r.Matched ? "" : "diff"));
            h.Append("<tr class='").Append(rc).Append("'><td>").Append(r.No)
             .Append("</td><td>").Append(E(r.SrcWell)).Append("</td><td>").Append(E(r.OPlate))
             .Append("</td><td>").Append(E(r.OWell))
             .Append("</td><td class='num'>").Append(E(Dash2(r.XferExpected)))
             .Append("</td><td class='num'>").Append(E(Dash2(r.XferDrawn)))
             .Append("</td><td class='num'>").Append(E(Dash2(r.DilExpected)))
             .Append("</td><td class='num'>").Append(E(Dash2(r.DilDrawn)))
             .Append("</td><td>").Append(E(TransferStatus(r)))
             .Append("</td><td>").Append(E(r.Purity + (r.Evidence.Length > 0 ? " | " + r.Evidence : ""))).Append("</td></tr>");
        }
        h.Append("</table>");

        // ---- AUDIT TRAIL (VERIFY-003 / DATA-004) ----
        h.Append("<h2>Barcodes and operator actions</h2>");
        h.Append("<table><tr><th>Group</th><th>Scanned</th><th>How it was read</th></tr>");
        AuditRow(h, app, "Source",         A_SRC_SCAN, A_SRC_RB);
        AuditRow(h, app, "Quantification", A_Q_SCAN,   A_Q_RB);
        AuditRow(h, app, "Output",         A_O_SCAN,   A_O_RB);
        h.Append("</table>");
        string res = Get(app, A_RESOLVE), att = Get(app, A_ATTEMPT);
        h.Append("<div class='sub'>Operator resolution: <b>")
         .Append(res.Length > 0 ? E(res) : "none — no barcode fault was raised")
         .Append("</b>").Append(att.Length > 0 ? " &middot; attempts: " + E(att) : "").Append("</div>");

        // ---- THE NAMED GAPS. On the page, not in a footnote. ----
        h.Append("<h2>What this report does NOT tell you</h2>");
        h.Append("<div class='sub'>Listed so nothing here is mistaken for complete.</div>");
        foreach (string nt in notes) h.Append("<div class='gap'>").Append(E(nt)).Append("</div>");

        // ---- FILES ----
        h.Append("<h2>Files written</h2><table>");
        h.Append("<tr><th>Completed worklist (Appendix B)</th><td class='mono'>").Append(E(recordPath)).Append("</td></tr>");
        if (sidecarPath.Length > 0)
            h.Append("<tr><th>Run-metadata sidecar</th><td class='mono'>").Append(E(sidecarPath)).Append("</td></tr>");
        h.Append("<tr><th>This report</th><td class='mono'>").Append(E(Path.Combine(outDir,
            "QuantNorm_output-report_" + runId + ".html"))).Append("</td></tr>");
        h.Append("</table>");
        h.Append("</div><div class='pane' id='p2'>");
        h.Append(WorklistTab());
        h.Append("</div></div>");

        h.Append("<div class='sub' style='margin-top:26px'>QuantNorm_OutputReport ").Append(SCRIPT_VERSION)
         .Append(" &middot; files are written to local storage only — transfer to the configured shared location is out of "
               + "scope for this method (DATA-006).</div>");
        h.Append("</div></body></html>");

        string path = Path.Combine(outDir, "QuantNorm_output-report_" + runId + ".html");
        File.WriteAllText(path, h.ToString(), new UTF8Encoding(false));
        return path;
    }

    // =======================================================================================
    //  THE 96-WELL PLATE GRAPHIC (Jim, 2026-07-31)
    //  A generic plate: 8 rows A-H, 12 columns 1-12, wells as circles big enough to read two
    //  numbers inside. Inline SVG, no JavaScript, so it survives file:// and prints.
    //  ⚠ CALCULATED VOLUMES ONLY — no air gap, no over-dispense. Jim was explicit, and it is right:
    //  those numbers describe how the tip behaves, not what ends up in the well.
    // =======================================================================================
    private const int WELL_PITCH = 78, WELL_R = 33, PAD_L = 42, PAD_T = 34;

    private string PlateSvg(PlateBlock p)
    {
        var byWell = new Dictionary<string, Row>();
        foreach (Row r in rows)
            if (r.OPlate == p.OutputPlate) byWell[Norm(r.OWell)] = r;

        int w = PAD_L + 12 * WELL_PITCH + 12, hgt = PAD_T + 8 * WELL_PITCH + 12;
        var s = new StringBuilder();
        s.Append("<div class='plate'><h3>Plate ").Append(p.Index).Append(" &mdash; ")
         .Append(E(p.SourcePlate)).Append(" &rarr; ").Append(E(p.OutputPlate)).Append("</h3>");
        s.Append("<div class='cap'>").Append(p.WellsExpected).Append(" well(s) given a volume");
        if (p.WellsDisagree > 0) s.Append(" &middot; ").Append(p.WellsDisagree).Append(" differ from what came back");
        s.Append("</div>");
        s.Append("<svg width='").Append(w).Append("' height='").Append(hgt)
         .Append("' viewBox='0 0 ").Append(w).Append(" ").Append(hgt)
         .Append("' xmlns='http://www.w3.org/2000/svg' font-family='-apple-system,Segoe UI,Roboto,Arial,sans-serif'>");
        // plate body
        s.Append("<rect x='").Append(PAD_L - 20).Append("' y='").Append(PAD_T - 20)
         .Append("' width='").Append(12 * WELL_PITCH + 28).Append("' height='").Append(8 * WELL_PITCH + 28)
         .Append("' rx='14' fill='#fbfcfd' stroke='#c9d0d8' stroke-width='2'/>");
        // column labels 1-12
        for (int c = 0; c < 12; c++)
            s.Append("<text x='").Append(PAD_L + c * WELL_PITCH + WELL_PITCH / 2).Append("' y='")
             .Append(PAD_T - 26).Append("' text-anchor='middle' font-size='15' font-weight='700' fill='#5d6875'>")
             .Append(c + 1).Append("</text>");
        // row labels A-H
        for (int r = 0; r < 8; r++)
            s.Append("<text x='").Append(PAD_L - 30).Append("' y='")
             .Append(PAD_T + r * WELL_PITCH + WELL_PITCH / 2 + 6)
             .Append("' text-anchor='middle' font-size='15' font-weight='700' fill='#5d6875'>")
             .Append((char)(65 + r)).Append("</text>");
        // wells
        for (int r = 0; r < 8; r++)
        {
            for (int c = 0; c < 12; c++)
            {
                string well = ((char)(65 + r)).ToString() + (c + 1).ToString("00");
                int cx = PAD_L + c * WELL_PITCH + WELL_PITCH / 2;
                int cy = PAD_T + r * WELL_PITCH + WELL_PITCH / 2;
                Row row = byWell.ContainsKey(well) ? byWell[well] : null;
                bool has = row != null && !row.Untouched && row.XferExpected.Length > 0;
                string ring = !has ? "#c9d0d8" : (row.Matched ? "#7cbf9b" : "#c62828");
                string fill = !has ? "#f2f4f7" : "#ffffff";
                s.Append("<circle cx='").Append(cx).Append("' cy='").Append(cy).Append("' r='").Append(WELL_R)
                 .Append("' fill='").Append(fill).Append("' stroke='").Append(ring).Append("' stroke-width='")
                 .Append(has && !row.Matched ? 3 : 2).Append("'/>");
                if (has)
                {
                    s.Append("<text x='").Append(cx).Append("' y='").Append(cy - 3)
                     .Append("' text-anchor='middle' font-size='15' font-weight='700' fill='#15191f'>")
                     .Append(E(row.XferExpected)).Append("</text>");
                    s.Append("<line x1='").Append(cx - 20).Append("' y1='").Append(cy + 3)
                     .Append("' x2='").Append(cx + 20).Append("' y2='").Append(cy + 3)
                     .Append("' stroke='#e3e7ec' stroke-width='1'/>");
                    s.Append("<text x='").Append(cx).Append("' y='").Append(cy + 19)
                     .Append("' text-anchor='middle' font-size='14' fill='#5d6875'>")
                     .Append(E(row.DilExpected.Length > 0 ? row.DilExpected : "0")).Append("</text>");
                }
            }
        }
        s.Append("</svg>");
        s.Append("<div class='legend'><span><i></i>as calculated, and the instrument agreed</span>")
         .Append("<span><i class='d'></i>the instrument reported a different volume</span>")
         .Append("<span><i class='u'></i>no volume &mdash; not in the worklist, or left dry on purpose</span></div>");
        s.Append("</div>");
        return s.ToString();
    }

    // TAB 2 — the completed worklist, rendered from the CSV TEXT THAT WAS WRITTEN. Rebuilding it from
    // the same in-memory data would let the tab and the file agree while both were wrong; reading the
    // written text means what is on screen is what Benchling will get.
    private string WorklistTab()
    {
        var s = new StringBuilder();
        s.Append("<h2>Completed worklist &mdash; the file handed on</h2>");
        s.Append("<div class='sub'>Appendix B v0.1 schema, 29 fields, one row per sample. This is the "
            + "content of the CSV exactly as written &mdash; not a second rendering of the same data.</div>");
        s.Append("<div class='mono' style='margin-bottom:14px'>").Append(E(recordPath)).Append("</div>");
        if (csvText.Length == 0) { s.Append("<p>No worklist was written.</p>"); return s.ToString(); }

        var lines = Qn.Records(csvText).ToArray();
        int hdr = -1;
        for (int i = 0; i < lines.Length; i++)
            if (lines[i].StartsWith("ID,")) { hdr = i; break; }

        if (hdr > 0)
        {
            s.Append("<h2 style='font-size:15px;margin-top:8px'>Run-metadata header block</h2>");
            s.Append("<table class='kv'>");
            for (int i = 0; i < hdr; i++)
            {
                if (lines[i].Trim().Length == 0) continue;
                int colon = lines[i].IndexOf(':');
                if (colon < 0) continue;
                string k = lines[i].Substring(0, colon).Trim();
                string v = lines[i].Substring(colon + 1).Trim();
                s.Append("<tr><th style='width:280px'>").Append(E(k)).Append("</th><td>")
                 .Append(v.Length == 0 ? "<i>empty &mdash; not produced by this build</i>" : E(v))
                 .Append("</td></tr>");
            }
            s.Append("</table>");
        }
        if (hdr < 0) return s.ToString();

        s.Append("<h2 style='font-size:15px'>Rows</h2><div style='overflow-x:auto'><table><tr>");
        foreach (string c in Qn.Fields(lines[hdr], ',')) s.Append("<th>").Append(E(c)).Append("</th>");
        s.Append("</tr>");
        for (int i = hdr + 1; i < lines.Length; i++)
        {
            if (lines[i].Trim().Length == 0) continue;
            s.Append("<tr>");
            foreach (string c in SplitCsvLine(lines[i]))
                s.Append("<td>").Append(c.Length == 0 ? "&mdash;" : E(c)).Append("</td>");
            s.Append("</tr>");
        }
        s.Append("</table></div>");
        return s.ToString();
    }

    // Quote-aware, because Stage-1 columns can legitimately contain commas.
    private static List<string> SplitCsvLine(string line)
    {
        var o = new List<string>(); var cur = new StringBuilder(); bool q = false;
        foreach (char ch in line)
        {
            if (ch == '"') { q = !q; continue; }
            if (ch == ',' && !q) { o.Add(cur.ToString()); cur.Length = 0; continue; }
            cur.Append(ch);
        }
        o.Add(cur.ToString());
        return o;
    }

    private void AuditRow(StringBuilder h, IMMApp app, string label, string scanVar, string rbVar)
    {
        var sc = L(app, scanVar); var rb = L(app, rbVar);
        h.Append("<tr><td>").Append(label).Append("</td><td>")
         .Append(sc.Count == 0 ? "<i>not scanned</i>" : E(string.Join(", ", sc.ToArray())))
         .Append("</td><td>")
         .Append(rb.Count == 0 ? "&mdash;" : E(string.Join(", ", rb.ToArray())))
         .Append("</td></tr>");
    }

    private static void Card(StringBuilder h, string k, string v)
    { h.Append("<div class='card'><div class='k'>").Append(k).Append("</div><div class='v'>").Append(v).Append("</div></div>"); }

    private string Verdict()
    {
        int attempted = rows.Count(r => !r.Untouched), skipped = rows.Count(r => r.Untouched);
        int bad = rows.Count(r => !r.Untouched && !r.Matched);
        if (attempted == 0 || bad > 0 || runErrors.Count > 0)
            return "Run requires review: " + bad + " of " + attempted + " attempted wells failed response checks; "
                + skipped + " sample wells explicitly skipped; " + runErrors.Count + " run-level review item(s).";
        return "Instrument response checks passed for " + attempted + " wells; " + skipped + " explicitly skipped. This is not independent delivery verification.";
    }

    // =======================================================================================
    //  VO parsing. Format is VERIFIED, not guessed — architecture doc section 4.1:
    //    VO;OK;12;8 , A01;20.0;<f>;OK;<f>;<f>;<f>;A01 , ... , <9 trailer fields>
    //  Sub-field 0 = well, 1 = delivered volume, 3 = status. The rest are NOT identified and this
    //  code does not pretend otherwise — it reads 1 and 3 and leaves the others alone.
    // =======================================================================================
    private Dictionary<string, string> VoByPlateAndWell(IMMApp app, string listVar)
    {
        var map = new Dictionary<string, string>();
        var perPlate = Amp(Get(app, listVar));      // VO lists are '&'-separated, NOT dash
        var plateHandles = L(app, P_OPLATE);
        for (int k = 0; k < perPlate.Count; k++)
        {
            string handle = At(plateHandles, k);
            string vo = perPlate[k];
            if (vo.Length == 0) continue;
            string[] f = vo.Split(',');
            for (int i = 1; i < f.Length; i++)
            {
                string[] s = f[i].Split(';');
                if (s.Length < 4) continue;                 // trailer fields, not well records
                string well = s[0].Trim();
                if (well.Length < 2 || !char.IsLetter(well[0])) continue;
                string key = handle + "|" + Norm(well);
                if (!map.ContainsKey(key)) map[key] = s[1].Trim();
            }
        }
        return map;
    }

    // The trailer is the last 9 comma fields — command, tool, plate, blank, location, 0,0,0, timestamp.
    private static string Trailer(string vo)
    {
        if (vo == null || vo.Length == 0) return "";
        try
        {
            string[] f = Qn.Fields(vo, ',');
            if (f.Length < 10 || f[f.Length - 9].IndexOf(';') >= 0) return "";
            // Re-encode for display so an embedded comma stays within its field.
            return string.Join(",", f.Skip(f.Length - 9).Select(Csv).ToArray());
        }
        catch (InvalidOperationException)
        {
            // QnEvidence records the parse failure in the response verdict.
            return "";
        }
    }
    private static string LastField(string trailer)
    {
        if (trailer == null || trailer.Length == 0) return "";
        try
        {
            string[] f = Qn.Fields(trailer, ',');
            return f[f.Length - 1].Trim();
        }
        catch (InvalidOperationException) { return ""; }
    }

    // =======================================================================================
    //  Stage 1 — the columns Benchling authored, re-read from the input file, never re-typed.
    // =======================================================================================
    private List<Dictionary<string, string>> ReadStage1(string path)
    {
        var outp = new List<Dictionary<string, string>>();
        if (path == null || path.Length == 0 || !File.Exists(path)) return outp;
        List<string> hdr = null;
        foreach (string raw in Qn.ReadRecords(path))
        {
            string line = raw.TrimEnd();
            if (line.Length == 0 || line.TrimStart().StartsWith("#")) continue;
            string[] cells = Qn.Fields(line, ',');
            if (hdr == null)
            {
                bool looksLikeHeader = cells.Length > 3 &&
                    cells.Any(c => Key(c) == "sourceplatebarcode" || Key(c) == "sourcewell");
                if (looksLikeHeader) { hdr = cells.Select(c => Key(c)).ToList(); }
                continue;
            }
            var d = new Dictionary<string, string>();
            for (int i = 0; i < hdr.Count && i < cells.Length; i++) d[hdr[i]] = cells[i].Trim();
            outp.Add(d);
        }
        return outp;
    }
    // Paired by plate barcode + source well, NOT by row order — the row order of the completed file
    // need not match the input, and pairing by position would be silently wrong if it ever differed.
    private Dictionary<string, string> Stage1For(List<Dictionary<string, string>> s1, Row r)
    {
        foreach (var d in s1)
        {
            if (Val(d, "sourceplatebarcode") == r.SrcBc && Norm(Val(d, "sourcewell")) == Norm(r.SrcWell))
                return d;
        }
        return new Dictionary<string, string>();
    }
    private static string Pick(Dictionary<string, string> d, string col, string dflt)
    { string v = Val(d, Key(col)); return v.Length > 0 ? v : dflt; }
    private static string Val(Dictionary<string, string> d, string k)
    { return (d != null && d.ContainsKey(k)) ? d[k] : ""; }

    // =======================================================================================
    // Returns the single distinct value if the list is uniform, else marks it non-uniform and says so.
    // A stroke that varies well to well is not an over-dispense — it is something unexplained.
    private static string Uniform(List<double> v, ref bool uniform)
    {
        if (v.Count == 0) return "";
        double first = v[0];
        foreach (double x in v) if (Math.Abs(x - first) > 0.011) { uniform = false; return "varies"; }
        return Num2(first);
    }
    private static string Num2(double v) { return Math.Round(v, 2).ToString("0.##", CultureInfo.InvariantCulture); }

    private static string Ratio(string num, string den)
    {
        double a, b;
        if (!TryNum(num, out a) || !TryNum(den, out b) || b == 0) return "";
        return Math.Round(a / b, 2).ToString("0.##", CultureInfo.InvariantCulture);
    }
    private static bool TryNum(string s, out double v)
    { return Qn.TryNumber(s, out v); }

    // Agreement is to 0.01 uL. Exact string equality would call 25 and 25.00 a disagreement.
    private static bool Agrees(string expected, string actual)
    {
        double a, b;
        if (expected.Length == 0 && actual.Length == 0) return true;
        if (!TryNum(expected, out a) || !TryNum(actual, out b)) return false;
        return Math.Abs(a - b) <= 0.011;
    }
    private static string Dash2(string s) { return s.Length == 0 ? "—" : s; }
    private static string Norm(string well)
    {
        string w = (well ?? "").Trim().ToUpperInvariant();
        if (w.Length < 2) return w;
        int n; if (!int.TryParse(w.Substring(1), out n)) return w;
        return w.Substring(0, 1) + n.ToString("00");        // A1 and A01 are the same well
    }
    private static bool SameDay(string a, string b)
    {
        DateTime x, y;
        if (!DateTime.TryParse(a, out x) || !DateTime.TryParse(b, out y)) return true;  // can't tell: don't cry wolf
        return x.Date == y.Date;
    }
    private static string Lookup(Dictionary<string, string> m, string k)
    { return (m != null && m.ContainsKey(k)) ? m[k] : ""; }

    // VI strings are joined with '-'; VO strings are joined with '&'. They are different characters
    // for a reason — a VO can contain a negative number, and a VI cannot contain a comma. Using the
    // wrong one does not fail loudly, it silently shreds the payload.
    private static List<string> Dash(string raw) { return Split(raw, '-'); }
    private static List<string> Amp(string raw)  { return Split(raw, '&'); }
    private List<string> L(IMMApp app, string name) { return Split(Get(app, name), ','); }
    // Drops ONLY the leading phantom (D-S20-05). An empty element anywhere else is meaningful — it is
    // a row or a position that produced no value — and dropping those has been a real bug before.
    private static List<string> Split(string raw, char delim)
    {
        var o = new List<string>();
        if (raw == null || raw.Length == 0) return o;
        string[] p = raw.Split(delim);
        int start = (p.Length > 0 && p[0].Length == 0) ? 1 : 0;
        for (int i = start; i < p.Length; i++) o.Add(p[i]);
        return o;
    }
    private static string At(List<string> l, int i) { return (l != null && i >= 0 && i < l.Count) ? l[i].Trim() : ""; }

    private string RunMode(IMMApp app)
    {
        string mode;
        try { mode = app.IsExecuteMode ? "Hardware Execute mode" : "Test mode (simulation)"; }
        catch (Exception) { mode = "run mode could not be read"; }
        string declared = Get(app, V_TESTMODE);
        return mode + (declared.Length > 0 ? " · instrument connection declared: " + declared : "");
    }

    private static string Csv(string v)
    {
        v = v ?? "";
        return (v.IndexOf(',') >= 0 || v.IndexOf('"') >= 0 || v.IndexOf('\r') >= 0 || v.IndexOf('\n') >= 0)
            ? "\"" + v.Replace("\"", "\"\"") + "\"" : v;
    }
    private static string Json(string v)
    {
        var b = new StringBuilder();
        foreach (char c in v ?? "")
        {
            if (c == '\\') b.Append("\\\\");
            else if (c == '"') b.Append("\\\"");
            else if (c < 32) b.Append("\\u").Append(((int)c).ToString("x4"));
            else b.Append(c);
        }
        return b.ToString();
    }
    private static string Key(string s)
    { return (s ?? "").Trim().ToLowerInvariant().Replace(" ", "").Replace("_", "").Replace("(ul)", "").Replace("(µl)", ""); }
    private static string E(string s)
    {
        return (s ?? "").Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");
    }
    private static string Get(IMMApp app, string name)
    { try { return (app.GetVariableValue(name) ?? "").ToString(); } catch (Exception) { return ""; } }
    private static void Set(IMMApp app, string name, string value)
    { Qn.Write(app, name, value); }

    // Overridable so the offline harness can run the failure paths without launching a browser.
    public virtual void OpenReport(string path)
    { try { Process.Start(new ProcessStartInfo(path) { UseShellExecute = true }); } catch (Exception) { } }

    // Instrument-response validation shared by the runtime guard and final report.
    // Status and command stroke are checked; this is not independent gravimetric delivery verification.
    private static class QnEvidence
    {
        public sealed class Record
        {
            public string Volume = "", Status = "", Timestamp = "";
        }
        public sealed class Response
        {
            public string Error = "", Plate = "", Command = "", Timestamp = "";
            public Dictionary<string, Record> Wells = new Dictionary<string, Record>();
        }
        public static Response Read(string raw, string expectedPlate, string expectedCommand)
        {
            var result = new Response();
            if (string.IsNullOrEmpty(raw)) { result.Error = "No instrument response"; return result; }
            // v0.40.2 / v0.30.4: VO outer fields are CSV. Decode their quoting
            // before comparing the trailer plate with the method's actual plate name.
            // Keep escaped quotes and embedded commas as field content; do not remove
            // every quote character or weaken the plate identity comparison.
            string[] fields;
            try { fields = Qn.Fields(raw, ','); }
            catch (InvalidOperationException ex)
            {
                result.Error = "Malformed quoted VO fields: " + ex.Message;
                return result;
            }
            int recordEnd = fields.Length;
            string[] header = fields[0].Split(';');
            if (header.Length < 4 || header[0] != "VO" || header[1] != "OK" || header[2] != "12" || header[3] != "8")
                result.Error = "Invalid or non-OK VO header: " + fields[0];
            if (fields.Length >= 10 && fields[fields.Length - 9].IndexOf(';') < 0)
            {
                // Trailer metadata are not well records, even when their quoted
                // content contains semicolons. Their positions follow CSV parsing.
                recordEnd = fields.Length - 9;
                result.Command = fields[fields.Length - 9].Trim();
                result.Plate = fields[fields.Length - 7].Trim();
                result.Timestamp = fields[fields.Length - 1].Trim();
                if (result.Plate.Length > 0 && expectedPlate.Length > 0 && result.Plate != expectedPlate)
                    result.Error = "VO trailer plate mismatch: " + result.Plate + " vs " + expectedPlate;
                if (result.Command.Length > 0 && result.Command.IndexOf(expectedCommand, StringComparison.OrdinalIgnoreCase) < 0)
                    result.Error = "VO trailer command mismatch: " + result.Command;
            }
            for (int i = 1; i < recordEnd; i++)
            {
                string[] record = fields[i].Split(';');
                if (record.Length < 4) continue;
                string well = Qn.Well(record[0]);
                if (well.Length == 0) { result.Error = "Invalid VO well label: " + record[0]; continue; }
                if (result.Wells.ContainsKey(well)) { result.Error = "Duplicate VO well: " + well; continue; }
                result.Wells[well] = new Record { Volume = record[1].Trim(), Status = record[3].Trim(), Timestamp = result.Timestamp };
            }
            return result;
        }
        public static string[] VI(string raw)
        {
            string[] fields = (raw ?? "").Split(',');
            Qn.Require(fields.Length == 97 && fields[0] == "VI;12;8", "Expected a 96-channel VI payload.");
            for (int i = 1; i < fields.Length; i++)
            {
                if (fields[i].Length == 0) continue;
                string[] parts = fields[i].Split(';'); double value;
                Qn.Require(parts.Length <= 3, "Invalid VI field at channel " + i);
                for (int k = 0; k < parts.Length; k++)
                    Qn.Require(Qn.TryNumber(parts[k], out value) && value >= 0, "Invalid or negative VI value at channel " + i);
            }
            return fields;
        }
        public static string Check(Response response, string well, string expectedField)
        {
            double expected = 0;
            bool active = expectedField != null && expectedField.Length > 0;
            if (active)
            {
                if (!Qn.TryNumber(expectedField.Split(';')[0], out expected) || expected < 0) return "Invalid expected volume";
                active = expected > 0;
            }
            Record actual;
            bool found = response.Wells.TryGetValue(Qn.Well(well), out actual);
            if (!active)
            {
                // No command was requested for this channel. Absence is valid; positive reported motion is not.
                double inactiveVolume;
                if (found && (!Qn.TryNumber(actual.Volume, out inactiveVolume) || Math.Abs(inactiveVolume) > 0.011))
                    return "Unrequested channel has a nonzero/invalid reported volume";
                return "";
            }
            if (response.Error.Length > 0) return response.Error;
            if (!found) return "Missing active-channel result";
            if (!actual.Status.Equals("OK", StringComparison.OrdinalIgnoreCase)) return "Channel status " + actual.Status;
            double volume;
            if (!Qn.TryNumber(actual.Volume, out volume) || volume < 0) return "Invalid reported volume";
            if (Math.Abs(volume - expected) > 0.011) return "Reported " + actual.Volume + ", expected " + Qn.Number(expected);
            return "";
        }
        public static void CheckAll(string raw, string vi, string plate, string command)
        {
            string[] expected = VI(vi);
            Response response = Read(raw, plate, command);
            bool active = false;
            for (int channel = 1; channel <= 96; channel++)
            {
                if (!string.IsNullOrEmpty(expected[channel])) active = true;
                string well = ((char)('A' + (channel - 1) / 12)).ToString() + ((channel - 1) % 12 + 1).ToString("00");
                string error = Check(response, well, expected[channel]);
                Qn.Require(error.Length == 0, command + " " + plate + " " + well + ": " + error);
            }
            // A missing response is valid for an intentionally empty command. An explicit
            // malformed or failed response is not a successful no-op.
            if (active || !string.IsNullOrWhiteSpace(raw))
                Qn.Require(response.Error.Length == 0, response.Error);
        }
        public static string Volume(Response response, string well)
        {
            Record record;
            return response.Wells.TryGetValue(Qn.Well(well), out record) ? record.Volume : "";
        }
    }


    // Shared, self-contained helpers. Kept in each script: no extra runtime DLL is required.
    private static class Qn
    {
        public static string Get(IMMApp app, string name)
        { try { return app.GetVariableValue(name) ?? ""; } catch (Exception) { return ""; } }
        public static void Write(IMMApp app, string name, string value)
        {
            app.SetVariable(name, value ?? "");
            if (!string.Equals(app.GetVariableValue(name) ?? "", value ?? "", StringComparison.Ordinal))
                throw new InvalidOperationException("MM4 variable did not retain its assigned value: " + name);
        }
        public static void Require(bool condition, string message)
        { if (!condition) throw new InvalidOperationException(message); }
        public static bool Finite(double value)
        { return !double.IsNaN(value) && !double.IsInfinity(value); }
        public static bool TryNumber(string text, out double value)
        {
            return double.TryParse((text ?? "").Trim(), System.Globalization.NumberStyles.Float,
                System.Globalization.CultureInfo.InvariantCulture, out value) && Finite(value);
        }
        public static string Number(double value)
        { return value.ToString("0.################", System.Globalization.CultureInfo.InvariantCulture); }
        public static string Well(string text)
        {
            string s = (text ?? "").Trim().ToUpperInvariant();
            int c;
            if (s.Length < 2 || s.Length > 3 || s[0] < 'A' || s[0] > 'H') return "";
            for (int i = 1; i < s.Length; i++) if (s[i] < '0' || s[i] > '9') return "";
            if (!int.TryParse(s.Substring(1), out c) || c < 1 || c > 12) return "";
            return s.Substring(0, 1) + c.ToString("00");
        }
        public static int Channel(string well)
        {
            string w = Well(well);
            return w.Length == 0 ? -1 : (w[0] - 'A') * 12 + int.Parse(w.Substring(1));
        }
        public static List<string> List(string raw, char separator)
        {
            var result = new List<string>();
            if (string.IsNullOrEmpty(raw)) return result;
            string[] parts = raw.Split(separator);
            int start = parts[0].Length == 0 ? 1 : 0;
            for (int i = start; i < parts.Length; i++) result.Add(parts[i]);
            return result;
        }
        public static string At(List<string> values, int index)
        { return index >= 0 && index < values.Count ? values[index] : ""; }
        public static void PlateValue(IMMApp app, string variable, int index, int count, string value, char separator)
        {
            Require(index >= 1 && index <= count && count <= 4, "Invalid plate index for " + variable);
            var prior = List(Get(app, variable), separator);
            Require(prior.Count <= count, "Too many plate entries in " + variable + ". Start from ingestion.");
            while (prior.Count < count) prior.Add("");
            prior[index - 1] = value ?? "";
            Write(app, variable, separator.ToString() + string.Join(separator.ToString(), prior.ToArray()));
        }
        public static void SafeToken(string value, string description)
        {
            Require(!string.IsNullOrEmpty(value) && value.IndexOfAny(new char[] { ',', '|', '&', '\r', '\n', '\t' }) < 0,
                description + " is empty or contains a reserved MM4 list delimiter.");
        }
        public static string HashBytes(byte[] data)
        {
            using (var sha = System.Security.Cryptography.SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(data)).Replace("-", "").ToLowerInvariant();
        }
        public static string HashFile(string path) { return HashBytes(File.ReadAllBytes(path)); }
        public static void CheckWorklist(IMMApp app)
        {
            string p = Get(app, "User.WorklistFile_01"), h = Get(app, "User.SourceWorklistHash_01");
            Require(h.Length > 0 && File.Exists(p) && HashFile(p) == h,
                "The worklist is missing or changed after ingestion. Start a new run; current results must not be paired with changed input.");
        }
        public static List<string> ReadRecords(string path) { return Records(File.ReadAllText(path)); }
        public static List<string> Records(string text)
        {
            var result = new List<string>();
            var b = new StringBuilder();
            bool quoted = false;
            string s = (text ?? "").TrimStart('\uFEFF');
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (c == '"')
                {
                    b.Append(c);
                    if (quoted && i + 1 < s.Length && s[i + 1] == '"') { b.Append(s[++i]); continue; }
                    // Comments and header preambles are plain text, not CSV records.
                    if (!b.ToString().TrimStart().StartsWith("#")) quoted = !quoted;
                }
                else if ((c == '\r' || c == '\n') && !quoted)
                {
                    result.Add(b.ToString()); b.Length = 0;
                    if (c == '\r' && i + 1 < s.Length && s[i + 1] == '\n') i++;
                }
                else b.Append(c);
            }
            Require(!quoted, "Unterminated quoted field in the input file.");
            if (b.Length > 0) result.Add(b.ToString());
            return result;
        }
        public static string[] Fields(string record, char separator)
        {
            var result = new List<string>(); var cell = new StringBuilder();
            bool quoted = false, closed = false;
            string s = record ?? "";
            // Preambles/comments are not CSV: callers retain them verbatim.
            if (s.TrimStart().StartsWith("#") || (s.IndexOf(separator) < 0 && s.IndexOf(':') > 0)) return new string[] { s };
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (quoted)
                {
                    if (c == '"')
                    {
                        if (i + 1 < s.Length && s[i + 1] == '"') { cell.Append('"'); i++; }
                        else { quoted = false; closed = true; }
                    }
                    else cell.Append(c);
                }
                else if (c == separator) { result.Add(cell.ToString()); cell.Length = 0; closed = false; }
                else if (c == '"')
                {
                    Require(!closed && cell.ToString().Trim().Length == 0, "Unexpected quote in a delimited field.");
                    cell.Length = 0; quoted = true;
                }
                else if (closed) Require(char.IsWhiteSpace(c), "Unexpected text following a quoted field.");
                else cell.Append(c);
            }
            Require(!quoted, "Unterminated quoted field."); result.Add(cell.ToString());
            return result.ToArray();
        }
    }

}
