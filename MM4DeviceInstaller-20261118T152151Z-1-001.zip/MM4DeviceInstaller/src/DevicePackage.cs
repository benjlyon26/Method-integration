using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;

namespace MM4DeviceInstaller
{
	public sealed class DevicePackage
	{
		public string Folder { get; set; }
		public string DisplayName { get; set; }
		public string Description { get; set; }
		public string DllFile { get; set; }
		public string DeviceName { get; set; }
		public string DeviceId { get; set; }
		public string ClassId { get; set; }
		public string ClassName { get; set; }
		public string DeviceType { get; set; }
		public string ComponentName { get; set; }
		public string ComponentId { get; set; }
		public string ConfigFile { get; set; }
		public bool Initialize { get; set; }
		public List<string> LibraryFiles { get; private set; }

		public string DllPath
		{
			get { return Path.Combine(Folder, DllFile); }
		}

		public string ConfigPath
		{
			get { return Path.Combine(Folder, ConfigFile); }
		}

		public static string FindDevicesFolder()
		{
			DirectoryInfo dir = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);
			for (int i = 0; i < 5 && dir != null; i++)
			{
				string candidate = Path.Combine(dir.FullName, "Devices");
				if (Directory.Exists(candidate))
				{
					return candidate;
				}
				dir = dir.Parent;
			}
			return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Devices");
		}

		public static List<DevicePackage> LoadAll(string devicesFolder, List<string> errors)
		{
			List<DevicePackage> list = new List<DevicePackage>();
			if (!Directory.Exists(devicesFolder))
			{
				errors.Add("The Devices folder was not found: " + devicesFolder);
				return list;
			}
			string[] folders = Directory.GetDirectories(devicesFolder);
			Array.Sort(folders, StringComparer.OrdinalIgnoreCase);
			foreach (string folder in folders)
			{
				string manifest = Path.Combine(folder, "device.xml");
				if (!File.Exists(manifest))
				{
					continue;
				}
				try
				{
					list.Add(Load(folder, manifest));
				}
				catch (Exception ex)
				{
					errors.Add(Path.GetFileName(folder) + ": " + ex.Message);
				}
			}
			return list;
		}

		public static DevicePackage Load(string folder, string manifestPath)
		{
			XmlDocument doc = new XmlDocument();
			doc.Load(manifestPath);
			XmlElement root = doc.DocumentElement;
			if (root == null || root.Name != "MM4Device")
			{
				throw new InvalidDataException("device.xml must have an MM4Device root.");
			}
			DevicePackage package = new DevicePackage();
			package.Folder = folder;
			package.DisplayName = Required(root, "DisplayName");
			package.Description = Optional(root, "Description");
			package.DllFile = Required(root, "DllFile");
			package.DeviceName = Required(root, "DeviceName");
			package.DeviceId = Required(root, "DeviceId");
			package.ClassId = Required(root, "ClassId");
			package.ClassName = Required(root, "ClassName");
			package.DeviceType = Required(root, "DeviceType");
			package.ComponentName = Required(root, "ComponentName");
			package.ComponentId = Required(root, "ComponentId");
			package.ConfigFile = Required(root, "ConfigFile");
			package.Initialize = !string.Equals(Optional(root, "Initialize"), "false", StringComparison.OrdinalIgnoreCase);
			if (package.DllFile.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
			{
				throw new InvalidDataException("DllFile must be a file name, not a path.");
			}
			if (package.ConfigFile.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
			{
				throw new InvalidDataException("ConfigFile must be a file name, not a path.");
			}
			package.LibraryFiles = new List<string>();
			package.LibraryFiles.Add(package.DllFile);
			foreach (XmlNode extra in root.SelectNodes("SupportDll"))
			{
				string name = extra.InnerText == null ? "" : extra.InnerText.Trim();
				if (name.Length == 0)
				{
					continue;
				}
				if (name.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
				{
					throw new InvalidDataException("SupportDll must be a file name, not a path.");
				}
				bool already = false;
				foreach (string existing in package.LibraryFiles)
				{
					if (string.Equals(existing, name, StringComparison.OrdinalIgnoreCase))
					{
						already = true;
						break;
					}
				}
				if (!already)
				{
					package.LibraryFiles.Add(name);
				}
			}
			return package;
		}

		public string ValidateFiles()
		{
			if (LibraryFiles == null || LibraryFiles.Count == 0)
			{
				return "Missing " + DllFile + " in " + Folder;
			}
			foreach (string fileName in LibraryFiles)
			{
				if (!File.Exists(Path.Combine(Folder, fileName)))
				{
					return "Missing " + fileName + " in " + Folder;
				}
			}
			if (!File.Exists(ConfigPath))
			{
				return "Missing " + ConfigFile + " in " + Folder;
			}
			return null;
		}

		private static string Required(XmlElement root, string name)
		{
			string value = Optional(root, name);
			if (string.IsNullOrWhiteSpace(value))
			{
				throw new InvalidDataException("device.xml is missing " + name + ".");
			}
			return value.Trim();
		}

		private static string Optional(XmlElement root, string name)
		{
			XmlNode node = root.SelectSingleNode(name);
			return node == null ? "" : (node.InnerText ?? "");
		}
	}
}
