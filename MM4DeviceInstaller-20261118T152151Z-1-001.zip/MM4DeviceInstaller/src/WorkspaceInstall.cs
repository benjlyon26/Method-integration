using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;

namespace MM4DeviceInstaller
{
	public sealed class WorkspaceUpdate
	{
		public bool DeviceAdded { get; set; }
		public bool DeviceAlreadyPresent { get; set; }
		public bool InitAdded { get; set; }
		public bool InitAlreadyPresent { get; set; }
		public bool ConfigCopied { get; set; }
		public bool ConfigReplaced { get; set; }
		public bool ConfigKept { get; set; }
		public string Error { get; set; }
	}

	public static class XmlFiles
	{
		public static Encoding Detect(string path)
		{
			byte[] bytes = File.ReadAllBytes(path);
			if (bytes.Length >= 2 && bytes[0] == 0xFF && bytes[1] == 0xFE)
			{
				return Encoding.Unicode;
			}
			if (bytes.Length >= 2 && bytes[0] == 0xFE && bytes[1] == 0xFF)
			{
				return Encoding.BigEndianUnicode;
			}
			if (DeclaresUtf16(bytes))
			{
				return Encoding.Unicode;
			}
			return new UTF8Encoding(false);
		}

		public static bool MissingUtf16Mark(string path)
		{
			byte[] bytes = File.ReadAllBytes(path);
			if (bytes.Length >= 2 && ((bytes[0] == 0xFF && bytes[1] == 0xFE) || (bytes[0] == 0xFE && bytes[1] == 0xFF)))
			{
				return false;
			}
			return DeclaresUtf16(bytes);
		}

		public static void Load(XmlDocument doc, string path)
		{
			byte[] bytes = File.ReadAllBytes(path);
			string xml;
			if (bytes.Length >= 2 && bytes[0] == 0xFF && bytes[1] == 0xFE)
			{
				xml = Encoding.Unicode.GetString(bytes);
			}
			else if (bytes.Length >= 2 && bytes[0] == 0xFE && bytes[1] == 0xFF)
			{
				xml = Encoding.BigEndianUnicode.GetString(bytes);
			}
			else
			{
				xml = Encoding.UTF8.GetString(bytes);
				if (DeclaresUtf16(bytes))
				{
					xml = Utf16Declaration.Replace(xml, "encoding=$1utf-8$1");
				}
			}
			if (xml.Length > 0 && xml[0] == '\uFEFF')
			{
				xml = xml.Substring(1);
			}
			doc.LoadXml(xml);
		}

		private static bool DeclaresUtf16(byte[] bytes)
		{
			int length = Math.Min(bytes.Length, 240);
			string head = Encoding.UTF8.GetString(bytes, 0, length);
			return head.IndexOf("utf-16", StringComparison.OrdinalIgnoreCase) >= 0;
		}

		private static readonly Regex Utf16Declaration = new Regex(
			"encoding\\s*=\\s*([\"'])utf-16\\1",
			RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

		public static void Save(XmlDocument doc, string path, Encoding encoding)
		{
			string declared = encoding is UnicodeEncoding ? "utf-16" : "utf-8";
			XmlDeclaration declaration = doc.FirstChild as XmlDeclaration;
			if (declaration == null)
			{
				declaration = doc.CreateXmlDeclaration("1.0", declared, null);
				doc.InsertBefore(declaration, doc.DocumentElement);
			}
			else
			{
				declaration.Encoding = declared;
			}
			XmlWriterSettings settings = new XmlWriterSettings();
			settings.Indent = true;
			settings.IndentChars = "  ";
			settings.NewLineChars = "\r\n";
			settings.Encoding = encoding;
			settings.OmitXmlDeclaration = false;
			using (FileStream stream = new FileStream(path, FileMode.Create, FileAccess.Write))
			using (XmlWriter writer = XmlWriter.Create(stream, settings))
			{
				doc.Save(writer);
			}
		}
	}

	public static class WorkspaceInstall
	{
		public static WorkspaceUpdate Apply(string workspaceDirectory, DevicePackage package)
		{
			WorkspaceUpdate update = new WorkspaceUpdate();
			try
			{
				UpdateWorkspaceConfig(workspaceDirectory, package, update);
				UpdateInitializeOrder(workspaceDirectory, package, update);
				CopyComponentConfig(workspaceDirectory, package, update);
			}
			catch (Exception ex)
			{
				update.Error = ex.Message;
			}
			return update;
		}

		private static void UpdateWorkspaceConfig(string workspaceDirectory, DevicePackage package, WorkspaceUpdate update)
		{
			string path = Path.Combine(workspaceDirectory, "Workspace.config");
			if (!File.Exists(path))
			{
				throw new FileNotFoundException("Workspace.config was not found in " + workspaceDirectory);
			}
			Encoding encoding = XmlFiles.Detect(path);
			XmlDocument doc = new XmlDocument();
			XmlFiles.Load(doc, path);
			XmlElement devices = doc.SelectSingleNode("/Workspace/Devices") as XmlElement;
			if (devices == null)
			{
				throw new InvalidDataException("Workspace.config has no Devices list.");
			}
			foreach (XmlElement existing in devices.SelectNodes("Device"))
			{
				if (Same(Text(existing, "DeviceType"), package.DeviceType) || Same(Text(existing, "Name"), package.DeviceName))
				{
					update.DeviceAlreadyPresent = true;
					return;
				}
			}
			BackupBeforeChange(path);
			XmlElement device = doc.CreateElement("Device");
			Add(doc, device, "Name", package.DeviceName);
			Add(doc, device, "Id", package.DeviceId);
			Add(doc, device, "ClassId", package.ClassId);
			Add(doc, device, "ClassName", package.ClassName);
			Add(doc, device, "DeviceType", package.DeviceType);
			devices.AppendChild(device);
			XmlFiles.Save(doc, path, encoding);
			update.DeviceAdded = true;
		}

		private static void UpdateInitializeOrder(string workspaceDirectory, DevicePackage package, WorkspaceUpdate update)
		{
			string path = Path.Combine(workspaceDirectory, "InitializeOrder.xml");
			XmlDocument doc = new XmlDocument();
			Encoding encoding = Encoding.Unicode;
			bool repairUtf16 = false;
			if (File.Exists(path))
			{
				repairUtf16 = XmlFiles.MissingUtf16Mark(path);
				encoding = XmlFiles.Detect(path);
				XmlFiles.Load(doc, path);
			}
			else
			{
				XmlDeclaration declaration = doc.CreateXmlDeclaration("1.0", "utf-16", null);
				doc.AppendChild(declaration);
				XmlElement created = doc.CreateElement("ArrayOfMMInitHardwareItem");
				created.SetAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
				created.SetAttribute("xmlns:xsd", "http://www.w3.org/2001/XMLSchema");
				doc.AppendChild(created);
			}
			XmlElement root = doc.SelectSingleNode("/ArrayOfMMInitHardwareItem") as XmlElement;
			if (root == null)
			{
				throw new InvalidDataException("InitializeOrder.xml has an unexpected root.");
			}
			foreach (XmlElement existing in root.SelectNodes("MMInitHardwareItem"))
			{
				if (Same(Text(existing, "DeviceName"), package.DeviceName) && Same(Text(existing, "ComponentName"), package.ComponentName))
				{
					update.InitAlreadyPresent = true;
					if (!File.Exists(path) || repairUtf16)
					{
						if (File.Exists(path))
						{
							File.Copy(path, path + ".installer.bak", true);
						}
						XmlFiles.Save(doc, path, Encoding.Unicode);
					}
					return;
				}
			}
			if (File.Exists(path))
			{
				File.Copy(path, path + ".installer.bak", true);
			}
			XmlElement item = doc.CreateElement("MMInitHardwareItem");
			Add(doc, item, "DeviceName", package.DeviceName);
			Add(doc, item, "DeviceId", package.DeviceId);
			Add(doc, item, "ComponentName", package.ComponentName);
			Add(doc, item, "ComponentId", package.ComponentId);
			Add(doc, item, "Initialize", package.Initialize ? "true" : "false");
			root.AppendChild(item);
			XmlFiles.Save(doc, path, encoding);
			update.InitAdded = true;
		}

		private static void CopyComponentConfig(string workspaceDirectory, DevicePackage package, WorkspaceUpdate update)
		{
			string configuration = Path.Combine(workspaceDirectory, "Configuration");
			Directory.CreateDirectory(configuration);
			string destination = Path.Combine(configuration, package.DeviceName + ".config");
			if (File.Exists(destination))
			{
				if (!IsObsoleteBioShakeConfig(package, destination))
				{
					update.ConfigKept = true;
					return;
				}
				BackupBeforeChange(destination);
				File.Copy(package.ConfigPath, destination, true);
				update.ConfigReplaced = true;
				return;
			}
			File.Copy(package.ConfigPath, destination, false);
			update.ConfigCopied = true;
		}

		private static bool IsObsoleteBioShakeConfig(DevicePackage package, string destination)
		{
			if (!string.Equals(package.DeviceName, "BioShake", StringComparison.OrdinalIgnoreCase))
			{
				return false;
			}
			string text = File.ReadAllText(destination);
			return text.IndexOf("ShakerCount", StringComparison.Ordinal) < 0;
		}

		private static void BackupBeforeChange(string path)
		{
			string folder = Path.GetDirectoryName(path);
			string name = Path.GetFileName(path);
			string stamp = DateTime.Now.ToString("yyyy-MM-dd_HHmmss");
			string backup = Path.Combine(folder, name + "." + stamp + ".bak");
			int extra = 1;
			while (File.Exists(backup))
			{
				backup = Path.Combine(folder, name + "." + stamp + "-" + extra.ToString() + ".bak");
				extra++;
			}
			File.Copy(path, backup, false);
		}

		private static void Add(XmlDocument doc, XmlElement parent, string name, string value)
		{
			XmlElement child = doc.CreateElement(name);
			child.InnerText = value ?? "";
			parent.AppendChild(child);
		}

		private static string Text(XmlElement parent, string name)
		{
			XmlNode node = parent.SelectSingleNode(name);
			return node == null ? "" : (node.InnerText ?? "").Trim();
		}

		private static bool Same(string left, string right)
		{
			return string.Equals((left ?? "").Trim(), (right ?? "").Trim(), StringComparison.OrdinalIgnoreCase);
		}
	}
}
