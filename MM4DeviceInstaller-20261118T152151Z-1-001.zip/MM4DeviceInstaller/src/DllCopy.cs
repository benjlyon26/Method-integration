using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace MM4DeviceInstaller
{
	public sealed class DllCopyJob
	{
		public string Source { get; set; }
		public string Destination { get; set; }
		public string Error { get; set; }
		public string DeviceName { get; set; }
		public string WorkspaceName { get; set; }
		public string WorkspaceDirectory { get; set; }
	}

	public static class DllCopy
	{
		public static bool SameContent(string source, string destination)
		{
			try
			{
				if (string.IsNullOrEmpty(source) || string.IsNullOrEmpty(destination))
				{
					return false;
				}
				if (!File.Exists(source) || !File.Exists(destination))
				{
					return false;
				}
				FileInfo sourceInfo = new FileInfo(source);
				FileInfo destinationInfo = new FileInfo(destination);
				if (sourceInfo.Length != destinationInfo.Length)
				{
					return false;
				}
				using (SHA256 sha = SHA256.Create())
				using (FileStream sourceStream = OpenReadShared(source))
				using (FileStream destinationStream = OpenReadShared(destination))
				{
					byte[] sourceHash = sha.ComputeHash(sourceStream);
					byte[] destinationHash = sha.ComputeHash(destinationStream);
					if (sourceHash.Length != destinationHash.Length)
					{
						return false;
					}
					for (int i = 0; i < sourceHash.Length; i++)
					{
						if (sourceHash[i] != destinationHash[i])
						{
							return false;
						}
					}
					return true;
				}
			}
			catch (Exception)
			{
				return false;
			}
		}

		public static bool HasZoneIdentifier(string path)
		{
			if (string.IsNullOrEmpty(path) || !File.Exists(path))
			{
				return false;
			}
			IntPtr handle = CreateFileW(path + ":Zone.Identifier", GenericRead, FileShareReadWriteDelete, IntPtr.Zero, OpenExisting, 0, IntPtr.Zero);
			if (handle == InvalidHandle)
			{
				return Marshal.GetLastWin32Error() == ErrorAccessDenied;
			}
			CloseHandle(handle);
			return true;
		}

		public static bool TryClearZoneIdentifier(string path, out string error)
		{
			error = null;
			if (!HasZoneIdentifier(path))
			{
				return true;
			}
			if (!DeleteFileW(path + ":Zone.Identifier"))
			{
				error = "The internet mark could not be removed (Windows error " + Marshal.GetLastWin32Error().ToString() + ").";
				return false;
			}
			if (HasZoneIdentifier(path))
			{
				error = "The internet mark is still on " + path + ".";
				return false;
			}
			return true;
		}

		internal static void WriteZoneIdentifier(string path, string contents)
		{
			IntPtr handle = CreateFileW(path + ":Zone.Identifier", GenericWrite, FileShareRead, IntPtr.Zero, CreateAlways, 0, IntPtr.Zero);
			if (handle == InvalidHandle)
			{
				throw new IOException("Could not write the internet mark (Windows error " + Marshal.GetLastWin32Error().ToString() + ").");
			}
			try
			{
				byte[] bytes = Encoding.ASCII.GetBytes(contents ?? "");
				uint written;
				if (!WriteFile(handle, bytes, (uint)bytes.Length, out written, IntPtr.Zero) || written != bytes.Length)
				{
					throw new IOException("Could not write the internet mark (Windows error " + Marshal.GetLastWin32Error().ToString() + ").");
				}
			}
			finally
			{
				CloseHandle(handle);
			}
		}

		private const uint GenericRead = 0x80000000;

		private const uint GenericWrite = 0x40000000;

		private const uint FileShareRead = 0x1;

		private const uint FileShareReadWriteDelete = 0x1 | 0x2 | 0x4;

		private const uint OpenExisting = 3;

		private const uint CreateAlways = 2;

		private const int ErrorAccessDenied = 5;

		private static readonly IntPtr InvalidHandle = new IntPtr(-1);

		[DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
		private static extern IntPtr CreateFileW(string lpFileName, uint dwDesiredAccess, uint dwShareMode, IntPtr lpSecurityAttributes, uint dwCreationDisposition, uint dwFlagsAndAttributes, IntPtr hTemplateFile);

		[DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
		private static extern bool DeleteFileW(string lpFileName);

		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern bool WriteFile(IntPtr hFile, byte[] lpBuffer, uint nNumberOfBytesToWrite, out uint lpNumberOfBytesWritten, IntPtr lpOverlapped);

		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern bool CloseHandle(IntPtr hObject);

		public static bool TryCopy(string source, string destination, out string error)
		{
			error = null;
			try
			{
				string folder = Path.GetDirectoryName(destination);
				if (!string.IsNullOrEmpty(folder))
				{
					Directory.CreateDirectory(folder);
				}
				// File.Copy keeps the download mark. Method Manager will not load that DLL.
				File.Copy(source, destination, true);
			}
			catch (Exception ex)
			{
				error = ex.Message;
				return false;
			}
			if (!TryClearZoneIdentifier(destination, out error))
			{
				if (string.IsNullOrEmpty(error))
				{
					error = "The copied DLL is still marked as downloaded from the internet.";
				}
				return false;
			}
			return true;
		}

		private static FileStream OpenReadShared(string path)
		{
			return new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
		}

		public static bool IsAccessDenied(string error)
		{
			if (string.IsNullOrEmpty(error))
			{
				return false;
			}
			return error.IndexOf("denied", StringComparison.OrdinalIgnoreCase) >= 0
				|| error.IndexOf("administrator", StringComparison.OrdinalIgnoreCase) >= 0
				|| error.IndexOf("privilege", StringComparison.OrdinalIgnoreCase) >= 0
				|| error.IndexOf("unauthorized", StringComparison.OrdinalIgnoreCase) >= 0;
		}

		public static bool TryElevatedCopy(IList<DllCopyJob> jobs, out string error)
		{
			error = null;
			if (jobs == null || jobs.Count == 0)
			{
				return true;
			}
			string jobPath = Path.Combine(Path.GetTempPath(), "mm4-device-install-" + Guid.NewGuid().ToString("N") + ".txt");
			string resultPath = jobPath + ".result";
			try
			{
				StringBuilder body = new StringBuilder();
				foreach (DllCopyJob job in jobs)
				{
					body.Append(job.Source);
					body.Append('\t');
					body.Append(job.Destination);
					body.Append("\r\n");
				}
				File.WriteAllText(jobPath, body.ToString(), new UTF8Encoding(false));
				ProcessStartInfo start = new ProcessStartInfo();
				start.FileName = Application.ExecutablePath;
				start.Arguments = "--copy-dlls \"" + jobPath + "\"";
				start.UseShellExecute = true;
				start.Verb = "runas";
				start.WorkingDirectory = Path.GetDirectoryName(Application.ExecutablePath);
				Process process = Process.Start(start);
				if (process == null)
				{
					error = "Windows did not start the administrator copy.";
					return false;
				}
				process.WaitForExit();
				if (!File.Exists(resultPath))
				{
					error = "The administrator copy did not report a result.";
					return false;
				}
				bool allOk = true;
				string[] lines = File.ReadAllLines(resultPath);
				foreach (string line in lines)
				{
					string[] parts = line.Split('\t');
					if (parts.Length < 2)
					{
						continue;
					}
					foreach (DllCopyJob job in jobs)
					{
						if (!string.Equals(job.Destination, parts[1], StringComparison.OrdinalIgnoreCase))
						{
							continue;
						}
						if (string.Equals(parts[0], "OK", StringComparison.OrdinalIgnoreCase))
						{
							job.Error = null;
						}
						else
						{
							allOk = false;
							job.Error = parts.Length >= 3 ? parts[2] : "Copy failed.";
						}
					}
				}
				return allOk;
			}
			catch (Exception ex)
			{
				error = ex.Message;
				return false;
			}
			finally
			{
				DeleteQuiet(jobPath);
				DeleteQuiet(resultPath);
			}
		}

		public static int RunElevatedJob(string jobPath)
		{
			bool ok = true;
			List<string> results = new List<string>();
			string[] lines = File.ReadAllLines(jobPath);
			foreach (string line in lines)
			{
				if (string.IsNullOrWhiteSpace(line))
				{
					continue;
				}
				string[] parts = line.Split('\t');
				if (parts.Length < 2)
				{
					continue;
				}
				string error;
				if (TryCopy(parts[0], parts[1], out error))
				{
					results.Add("OK\t" + parts[1]);
				}
				else
				{
					ok = false;
					results.Add("ERR\t" + parts[1] + "\t" + error);
				}
			}
			File.WriteAllLines(jobPath + ".result", results.ToArray(), new UTF8Encoding(false));
			return ok ? 0 : 1;
		}

		public static string CopyIntoWorkspace(string workspaceDirectory, string sourceDll)
		{
			string folder = Path.Combine(workspaceDirectory, "DeviceDlls");
			Directory.CreateDirectory(folder);
			string destination = Path.Combine(folder, Path.GetFileName(sourceDll));
			File.Copy(sourceDll, destination, true);
			string markError;
			if (!TryClearZoneIdentifier(destination, out markError))
			{
				throw new IOException(string.IsNullOrEmpty(markError)
					? "The workspace copy is still marked as downloaded from the internet."
					: markError);
			}
			return destination;
		}

		private static void DeleteQuiet(string path)
		{
			try
			{
				if (File.Exists(path))
				{
					File.Delete(path);
				}
			}
			catch
			{
			}
		}
	}
}
