using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace MM4DeviceInstaller
{
	internal static class SelfTest
	{
		public static int Run(string logPath)
		{
			int failed = 0;
			List<string> lines = new List<string>();
			_lines = lines;
			string root = Path.Combine(Path.GetTempPath(), "mm4-installer-test-" + Guid.NewGuid().ToString("N"));
			try
			{
				Directory.CreateDirectory(root);
				string devices = DevicePackage.FindDevicesFolder();
				List<string> errors = new List<string>();
				List<DevicePackage> packages = DevicePackage.LoadAll(devices, errors);
				Check(errors.Count == 0, "load errors: " + string.Join("; ", errors.ToArray()), ref failed);
				DevicePackage elevator = Find(packages, "LabwareElevator");
				DevicePackage shaker = Find(packages, "BioShake");
				Check(elevator != null, "Labware Elevator package missing", ref failed);
				Check(shaker != null, "BioShake package missing", ref failed);
				DevicePackage turnTable = Find(packages, "Exypnos Turn Table");
				Check(turnTable != null, "Exypnos Turn Table package missing", ref failed);
				if (turnTable != null)
				{
					Check(turnTable.ValidateFiles() == null, turnTable.ValidateFiles(), ref failed);
					Check(turnTable.DllFile == "ExypnosTurnTable.dll", "turn table dll", ref failed);
					Check(turnTable.ClassName == "Exypnos Turn Table Device", "turn table class", ref failed);
				}
				if (elevator == null || shaker == null)
				{
					return 1;
				}
				Check(elevator.ValidateFiles() == null, elevator.ValidateFiles(), ref failed);
				Check(shaker.ValidateFiles() == null, shaker.ValidateFiles(), ref failed);
				DevicePackage lunatic = Find(packages, "Lunatic");
				DevicePackage stunner = Find(packages, "Stunner");
				Check(lunatic != null, "Lunatic package missing", ref failed);
				Check(stunner != null, "Stunner package missing", ref failed);
				if (lunatic != null)
				{
					Check(lunatic.ValidateFiles() == null, lunatic.ValidateFiles(), ref failed);
					Check(lunatic.DllFile == "Lunatic.dll", "Lunatic dll", ref failed);
					Check(HasLibraryFile(lunatic, "DropQuant_Remote.dll"), "Lunatic support dll", ref failed);
				}
				if (stunner != null)
				{
					Check(stunner.ValidateFiles() == null, stunner.ValidateFiles(), ref failed);
					Check(stunner.DllFile == "UnchainedLabsStunner.dll", "Stunner dll", ref failed);
					Check(HasLibraryFile(stunner, "Stunner.dll"), "Stunner support dll", ref failed);
				}

				string workspace = Path.Combine(root, "Workspaces", "UNIT");
				Directory.CreateDirectory(workspace);
				WriteWorkspace(Path.Combine(workspace, "Workspace.config"));
				WriteInit(Path.Combine(workspace, "InitializeOrder.xml"));

				string program = Path.Combine(root, "Program");
				Directory.CreateDirectory(program);
				File.WriteAllText(Path.Combine(program, "MethodManager.DX.exe"), "");

				WorkspaceUpdate first = WorkspaceInstall.Apply(workspace, elevator);
				Check(first.Error == null, first.Error, ref failed);
				Check(first.DeviceAdded, "device was not added", ref failed);
				Check(first.InitAdded, "init item was not added", ref failed);
				Check(first.ConfigCopied, "config was not copied", ref failed);
				Check(CountDevices(workspace, "LabwareElevator") == 1, "device count", ref failed);
				Check(CountInit(workspace, "LabwareElevator") == 1, "init count", ref failed);
				Check(File.Exists(Path.Combine(workspace, "Configuration", "LabwareElevator.config")), "config missing", ref failed);
				string[] backups = Directory.GetFiles(workspace, "Workspace.config.*.bak");
				Check(backups.Length == 1, "workspace backup count " + backups.Length.ToString(), ref failed);
				if (backups.Length == 1)
				{
					string backupName = Path.GetFileName(backups[0]);
					Check(backupName.StartsWith("Workspace.config.20") && backupName.EndsWith(".bak"), "backup name " + backupName, ref failed);
					Check(!File.ReadAllText(backups[0]).Contains("LabwareElevator"), "backup already contained the new device", ref failed);
				}
				byte[] initBytes = File.ReadAllBytes(Path.Combine(workspace, "InitializeOrder.xml"));
				Check(initBytes.Length > 2 && initBytes[0] == 0xFF && initBytes[1] == 0xFE, "init file is not utf-16", ref failed);

				File.AppendAllText(Path.Combine(workspace, "Configuration", "LabwareElevator.config"), "<!-- keep -->");
				WorkspaceUpdate second = WorkspaceInstall.Apply(workspace, elevator);
				Check(second.DeviceAlreadyPresent, "second install added a duplicate device", ref failed);
				Check(second.InitAlreadyPresent, "second install added a duplicate init item", ref failed);
				Check(second.ConfigKept, "existing config was replaced", ref failed);
				Check(Directory.GetFiles(workspace, "Workspace.config.*.bak").Length == 1, "unchanged install wrote another workspace backup", ref failed);
				Check(CountDevices(workspace, "LabwareElevator") == 1, "duplicate device", ref failed);
				Check(File.ReadAllText(Path.Combine(workspace, "Configuration", "LabwareElevator.config")).Contains("keep"), "config marker lost", ref failed);

				string copiedDll = Path.Combine(Locations.DevicesLibrary(program), elevator.DllFile);
				string copyError;
				bool copied = DllCopy.TryCopy(elevator.DllPath, copiedDll, out copyError);
				Check(copied, copyError, ref failed);
				Check(File.Exists(copiedDll), "dll missing from program folder", ref failed);
				Check(DllCopy.SameContent(elevator.DllPath, copiedDll), "copied dll content differs", ref failed);
				string differentDll = Path.Combine(root, "different.dll");
				File.WriteAllBytes(differentDll, new byte[] { 1, 2, 3 });
				Check(!DllCopy.SameContent(elevator.DllPath, differentDll), "different dll was treated as current", ref failed);
				CheckInternetMark(root, ref failed);

				string saved = DllCopy.CopyIntoWorkspace(workspace, elevator.DllPath);
				Check(File.Exists(saved), "workspace dll missing", ref failed);
				List<PendingDll> pending = new List<PendingDll>();
				pending.Add(new PendingDll
				{
					DeviceName = elevator.DisplayName,
					WorkspaceName = "UNIT",
					SavedAt = saved,
					IntendedFolder = Locations.DevicesLibrary(program),
					Reason = "Access to the path is denied."
				});
				string message = ItMessage.Build(pending, program);
				Check(message.Contains("The DLL is located at:"), "IT message missing location label", ref failed);
				Check(message.Contains(saved), "IT message missing source", ref failed);
				Check(message.Contains(Path.Combine(Locations.DevicesLibrary(program), elevator.DllFile)), "IT message missing destination", ref failed);

				string fresh = Path.Combine(root, "Workspaces", "FRESH");
				Directory.CreateDirectory(fresh);
				WriteWorkspace(Path.Combine(fresh, "Workspace.config"));
				WorkspaceUpdate created = WorkspaceInstall.Apply(fresh, shaker);
				Check(created.Error == null, created.Error, ref failed);
				Check(created.InitAdded, "new init file was not created", ref failed);
				Check(File.Exists(Path.Combine(fresh, "InitializeOrder.xml")), "init file missing", ref failed);
				byte[] freshBytes = File.ReadAllBytes(Path.Combine(fresh, "InitializeOrder.xml"));
				Check(freshBytes.Length > 2 && freshBytes[0] == 0xFF && freshBytes[1] == 0xFE, "new init file is not utf-16", ref failed);
				Check(CountInit(fresh, "BioShake") == 1, "new init count", ref failed);
				Check(created.ConfigCopied, "new BioShake config was not copied", ref failed);
				string shakerConfig = Path.Combine(fresh, "Configuration", "BioShake.config");
				File.WriteAllText(shakerConfig, "<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n<DynamicDevices.Components>\r\n<Component>\r\n<Name>BioShake_1</Name>\r\n<Connection>2,9600,8,N,1</Connection>\r\n<ConnectionType>Custom</ConnectionType>\r\n</Component>\r\n</DynamicDevices.Components>\r\n");
				WorkspaceUpdate replaced = WorkspaceInstall.Apply(fresh, shaker);
				Check(replaced.Error == null, replaced.Error, ref failed);
				Check(replaced.ConfigReplaced, "old BioShake config was kept", ref failed);
				string replacedText = File.ReadAllText(shakerConfig);
				Check(replacedText.IndexOf("ShakerCount", StringComparison.Ordinal) >= 0, "replaced config has no ShakerCount", ref failed);
				Check(Directory.GetFiles(Path.Combine(fresh, "Configuration"), "BioShake.config.*.bak").Length == 1, "old BioShake config was not backed up", ref failed);
				File.AppendAllText(shakerConfig, "<!-- keep -->");
				WorkspaceUpdate kept = WorkspaceInstall.Apply(fresh, shaker);
				Check(kept.ConfigKept, "current BioShake config was replaced", ref failed);
				Check(File.ReadAllText(shakerConfig).Contains("keep"), "current BioShake config marker lost", ref failed);
				string installedProgram = @"C:\Program Files (x86)\Dynamic Devices\MethodManager4";
				if (File.Exists(Path.Combine(installedProgram, "MethodManager.Core.dll")))
				{
					if (lunatic != null)
					{
						string lunaticReason = DeviceCompatibility.Problem(lunatic, installedProgram);
						if (lunaticReason != null)
						{
							Check(lunaticReason.IndexOf("MethodManager.Core", StringComparison.Ordinal) >= 0, "Lunatic compatibility: " + lunaticReason, ref failed);
							Check(lunaticReason.IndexOf("left unchanged", StringComparison.Ordinal) < 0, "Lunatic warning still blocks: " + lunaticReason, ref failed);
						}
					}
					if (stunner != null)
					{
						string stunnerReason = DeviceCompatibility.Problem(stunner, installedProgram);
						if (stunnerReason != null)
						{
							Check(stunnerReason.IndexOf("MethodManager.Core", StringComparison.Ordinal) >= 0, "Stunner compatibility: " + stunnerReason, ref failed);
							Check(stunnerReason.IndexOf("left unchanged", StringComparison.Ordinal) < 0, "Stunner warning still blocks: " + stunnerReason, ref failed);
						}
					}
					string elevatorReason = DeviceCompatibility.Problem(elevator, installedProgram);
					Check(elevatorReason == null, "Labware Elevator compatibility: " + elevatorReason, ref failed);
					if (turnTable != null)
					{
						string turnReason = DeviceCompatibility.Problem(turnTable, installedProgram);
						Check(turnReason == null, "Exypnos Turn Table compatibility: " + turnReason, ref failed);
					}
				}
				if (lunatic != null && stunner != null)
				{
					WorkspaceUpdate addedLunatic = WorkspaceInstall.Apply(workspace, lunatic);
					WorkspaceUpdate addedStunner = WorkspaceInstall.Apply(workspace, stunner);
					Check(addedLunatic.Error == null, addedLunatic.Error, ref failed);
					Check(addedStunner.Error == null, addedStunner.Error, ref failed);
					Check(addedLunatic.DeviceAdded && addedLunatic.ConfigCopied, "Lunatic was not added", ref failed);
					Check(addedStunner.DeviceAdded && addedStunner.ConfigCopied, "Stunner was not added", ref failed);
					string lunaticConfig = File.ReadAllText(Path.Combine(workspace, "Configuration", "Lunatic.config"));
					string stunnerConfig = File.ReadAllText(Path.Combine(workspace, "Configuration", "Stunner.config"));
					Check(lunaticConfig.Contains("192.168.0.100,6300") && lunaticConfig.Contains("Lunatic.Reader"), "Lunatic config", ref failed);
					Check(stunnerConfig.Contains("192.168.0.100,6300") && stunnerConfig.Contains("..\\Devices\\UnchainedLabsStunner"), "Stunner config", ref failed);
					string workspaceText = File.ReadAllText(Path.Combine(workspace, "Workspace.config"));
					Check(workspaceText.Contains("40BCAEE7-9301-4BE0-BEA2-EC39EA4DBB8E"), "Lunatic device id", ref failed);
					Check(workspaceText.Contains("40BCAEE7-9301-4BE0-BEA2-EC39EA4DAA8E"), "Stunner device id", ref failed);
				}

				List<WorkspaceChoice> choices = Locations.ListWorkspaces(Path.Combine(root));
				Check(choices.Count == 2 && HasWorkspace(choices, "UNIT") && HasWorkspace(choices, "FRESH"), "workspace list", ref failed);

				string broken = Path.Combine(root, "Broken");
				Directory.CreateDirectory(broken);
				WriteWorkspace(Path.Combine(broken, "Workspace.config"));
				WriteBrokenInit(Path.Combine(broken, "InitializeOrder.xml"), "Lynx", "Lynx_1");
				WorkspaceUpdate repaired = WorkspaceInstall.Apply(broken, elevator);
				Check(repaired.Error == null, "broken init: " + repaired.Error, ref failed);
				Check(repaired.InitAdded && repaired.ConfigCopied, "broken init did not finish the install", ref failed);
				Check(File.Exists(Path.Combine(broken, "Configuration", "LabwareElevator.config")), "broken init skipped the config", ref failed);
				string brokenInit = Path.Combine(broken, "InitializeOrder.xml");
				byte[] repairedBytes = File.ReadAllBytes(brokenInit);
				Check(repairedBytes.Length > 2 && repairedBytes[0] == 0xFF && repairedBytes[1] == 0xFE, "broken init was not saved as utf-16", ref failed);
				Check(CountInit(broken, "Lynx") == 1, "existing init item lost", ref failed);
				Check(CountInit(broken, "LabwareElevator") == 1, "device missing from repaired init", ref failed);
				byte[] brokenBak = File.ReadAllBytes(brokenInit + ".installer.bak");
				Check(brokenBak.Length < 2 || brokenBak[0] != 0xFF || brokenBak[1] != 0xFE, "backup did not keep the original file", ref failed);

				string present = Path.Combine(root, "BrokenPresent");
				Directory.CreateDirectory(present);
				WriteWorkspace(Path.Combine(present, "Workspace.config"));
				WriteBrokenInit(Path.Combine(present, "InitializeOrder.xml"), "LabwareElevator", "LabwareElevator_1");
				WorkspaceUpdate already = WorkspaceInstall.Apply(present, elevator);
				Check(already.Error == null, "present broken init: " + already.Error, ref failed);
				Check(already.InitAlreadyPresent && already.ConfigCopied, "present broken init did not copy the config", ref failed);
				byte[] presentBytes = File.ReadAllBytes(Path.Combine(present, "InitializeOrder.xml"));
				Check(presentBytes.Length > 2 && presentBytes[0] == 0xFF && presentBytes[1] == 0xFE, "present broken init was not saved as utf-16", ref failed);
				Check(CountInit(present, "LabwareElevator") == 1, "present init item duplicated", ref failed);

				List<string> destinations = new List<string>();
				List<string> sources = new List<string>();
				List<PendingDll> folders = new List<PendingDll>();
				folders.Add(new PendingDll
				{
					SourceFolder = Path.GetDirectoryName(elevator.DllPath),
					IntendedFolder = ""
				});
				folders.Add(new PendingDll
				{
					SourceFolder = Path.GetDirectoryName(elevator.DllPath),
					IntendedFolder = ExplorerFolders.UsualDevicesFolder
				});
				ExplorerFolders.Collect(folders, destinations, sources);
				Check(destinations.Count == 1 && string.Equals(destinations[0], ExplorerFolders.UsualDevicesFolder, StringComparison.OrdinalIgnoreCase), "explorer destination", ref failed);
				Check(sources.Count == 1 && sources[0].EndsWith("Labware Elevator", StringComparison.OrdinalIgnoreCase), "explorer source", ref failed);
				CheckAttentionPaint(ref failed);
			}
			catch (Exception ex)
			{
				lines.Add("FAIL exception " + ex);
				failed++;
			}
			finally
			{
				try
				{
					if (Directory.Exists(root))
					{
						Directory.Delete(root, true);
					}
				}
				catch
				{
				}
			}
			lines.Add(failed == 0 ? "SELF-TEST PASSED" : "SELF-TEST FAILED " + failed);
			File.WriteAllLines(logPath, lines.ToArray());
			return failed == 0 ? 0 : 1;
		}

		private static void CheckInternetMark(string root, ref int failed)
		{
			string folder = Path.Combine(root, "zone");
			Directory.CreateDirectory(folder);
			byte[] body = new byte[] { 9, 8, 7, 6 };
			string marked = Path.Combine(folder, "marked.dll");
			File.WriteAllBytes(marked, body);
			DllCopy.WriteZoneIdentifier(marked, "[ZoneTransfer]\r\nZoneId=3\r\n");
			Check(DllCopy.HasZoneIdentifier(marked), "test mark was not written", ref failed);
			string clearError;
			Check(DllCopy.TryClearZoneIdentifier(marked, out clearError), clearError, ref failed);
			Check(!DllCopy.HasZoneIdentifier(marked), "internet mark remained after clear", ref failed);
			byte[] after = File.ReadAllBytes(marked);
			Check(after.Length == body.Length && after[0] == 9 && after[3] == 6, "clear changed the dll bytes", ref failed);

			string source = Path.Combine(folder, "source.dll");
			File.WriteAllBytes(source, body);
			DllCopy.WriteZoneIdentifier(source, "[ZoneTransfer]\r\nZoneId=3\r\n");
			string destination = Path.Combine(folder, "copied.dll");
			string copyError;
			Check(DllCopy.TryCopy(source, destination, out copyError), copyError, ref failed);
			Check(DllCopy.SameContent(source, destination), "copied bytes differ", ref failed);
			Check(!DllCopy.HasZoneIdentifier(destination), "copied dll kept the internet mark", ref failed);

			string workspace = Path.Combine(folder, "ws");
			Directory.CreateDirectory(workspace);
			string saved = DllCopy.CopyIntoWorkspace(workspace, source);
			Check(File.Exists(saved), "workspace copy missing", ref failed);
			Check(DllCopy.SameContent(source, saved), "workspace copy bytes differ", ref failed);
			Check(!DllCopy.HasZoneIdentifier(saved), "workspace copy kept the internet mark", ref failed);
		}

		private static bool HasLibraryFile(DevicePackage package, string fileName)
		{
			if (package.LibraryFiles == null)
			{
				return false;
			}
			foreach (string name in package.LibraryFiles)
			{
				if (string.Equals(name, fileName, StringComparison.OrdinalIgnoreCase))
				{
					return true;
				}
			}
			return false;
		}

		private static DevicePackage Find(List<DevicePackage> packages, string deviceName)
		{
			foreach (DevicePackage package in packages)
			{
				if (string.Equals(package.DeviceName, deviceName, StringComparison.OrdinalIgnoreCase))
				{
					return package;
				}
			}
			return null;
		}

		private static List<string> _lines;

		private static bool HasWorkspace(List<WorkspaceChoice> choices, string name)
		{
			foreach (WorkspaceChoice choice in choices)
			{
				if (string.Equals(choice.Name, name, StringComparison.OrdinalIgnoreCase))
				{
					return true;
				}
			}
			return false;
		}

		private static void CheckAttentionPaint(ref int failed)
		{
			Form form = new Form();
			try
			{
				form.ShowInTaskbar = false;
				form.FormBorderStyle = FormBorderStyle.None;
				form.StartPosition = FormStartPosition.Manual;
				form.Location = new Point(-3200, -3200);
				form.ClientSize = new Size(640, 220);
				BreathingLog log = new BreathingLog();
				log.Dock = DockStyle.Fill;
				log.UseForcedBreath = true;
				log.ForcedBreath = 1;
				form.Controls.Add(log);
				form.Show();
				log.AppendLine("Device packages need attention", true);
				log.AppendLine("ordinary status line", false);
				Application.DoEvents();
				Bitmap bmp = new Bitmap(Math.Max(1, log.Width), Math.Max(1, log.Height));
				try
				{
					log.DrawToBitmap(bmp, new Rectangle(0, 0, bmp.Width, bmp.Height));
					bool sawRed = false;
					bool sawBlue = false;
					bool sawOrdinary = false;
					for (int py = 0; py < bmp.Height; py++)
					{
						for (int px = 0; px < bmp.Width; px++)
						{
							Color c = bmp.GetPixel(px, py);
							if (c.R > 150 && c.R > c.G * 2 && c.R > c.B * 2)
							{
								sawRed = true;
							}
							if (Math.Abs(c.R - 20) <= 2 && Math.Abs(c.G - 72) <= 2 && Math.Abs(c.B - 114) <= 2)
							{
								sawBlue = true;
							}
							if (c.R < 80 && c.G < 90 && c.B < 100 && Math.Abs(c.R - c.G) < 40 && Math.Abs(c.G - c.B) < 40)
							{
								sawOrdinary = true;
							}
						}
					}
					Check(sawBlue, "attention box is not blue", ref failed);
					Check(sawRed, "attention text is not red", ref failed);
					Check(sawOrdinary, "ordinary log text is missing", ref failed);
				}
				finally
				{
					bmp.Dispose();
				}
			}
			catch (Exception ex)
			{
				Check(false, "attention paint " + ex.Message, ref failed);
			}
			finally
			{
				form.Dispose();
			}
		}

		private static void Check(bool condition, string message, ref int failed)
		{
			if (!condition)
			{
				failed++;
				_lines.Add("FAIL " + message);
			}
		}

		private static int CountDevices(string workspace, string name)
		{
			XmlDocument doc = new XmlDocument();
			doc.Load(Path.Combine(workspace, "Workspace.config"));
			int count = 0;
			foreach (XmlElement device in doc.SelectNodes("/Workspace/Devices/Device"))
			{
				XmlNode node = device.SelectSingleNode("Name");
				if (node != null && string.Equals(node.InnerText, name, StringComparison.OrdinalIgnoreCase))
				{
					count++;
				}
			}
			return count;
		}

		private static int CountInit(string workspace, string name)
		{
			XmlDocument doc = new XmlDocument();
			doc.Load(Path.Combine(workspace, "InitializeOrder.xml"));
			int count = 0;
			foreach (XmlElement item in doc.SelectNodes("/ArrayOfMMInitHardwareItem/MMInitHardwareItem"))
			{
				XmlNode node = item.SelectSingleNode("DeviceName");
				if (node != null && string.Equals(node.InnerText, name, StringComparison.OrdinalIgnoreCase))
				{
					count++;
				}
			}
			return count;
		}

		private static void WriteWorkspace(string path)
		{
			File.WriteAllText(path,
				"<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n" +
				"<Workspace xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">\r\n" +
				"  <Name>UNIT</Name>\r\n" +
				"  <Devices>\r\n" +
				"    <Device>\r\n" +
				"      <Name>Logic</Name>\r\n" +
				"      <Id>05fb9ae8-0bef-44ae-939d-9bcda4238c84</Id>\r\n" +
				"      <ClassId>96875bc4-0900-4418-84f2-2d6069cb78fb</ClassId>\r\n" +
				"      <ClassName>Core</ClassName>\r\n" +
				"      <DeviceType>MethodManager.CoreDevice.Device.MMCoreDevice</DeviceType>\r\n" +
				"    </Device>\r\n" +
				"  </Devices>\r\n" +
				"</Workspace>\r\n", new UTF8Encoding(false));
		}

		private static void WriteInit(string path)
		{
			string xml =
				"<?xml version=\"1.0\" encoding=\"utf-16\"?>\r\n" +
				"<ArrayOfMMInitHardwareItem xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">\r\n" +
				"</ArrayOfMMInitHardwareItem>\r\n";
			File.WriteAllText(path, xml, Encoding.Unicode);
		}

		private static void WriteBrokenInit(string path, string deviceName, string componentName)
		{
			string xml =
				"<?xml version=\"1.0\" encoding=\"utf-16\"?>\r\n" +
				"<ArrayOfMMInitHardwareItem xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">\r\n" +
				"  <MMInitHardwareItem>\r\n" +
				"    <DeviceName>" + deviceName + "</DeviceName>\r\n" +
				"    <DeviceId>11111111-1111-1111-1111-111111111111</DeviceId>\r\n" +
				"    <ComponentName>" + componentName + "</ComponentName>\r\n" +
				"    <ComponentId>11111111-1111-1111-1111-111111111111</ComponentId>\r\n" +
				"    <Initialize>true</Initialize>\r\n" +
				"  </MMInitHardwareItem>\r\n" +
				"</ArrayOfMMInitHardwareItem>\r\n";
			File.WriteAllText(path, xml, new UTF8Encoding(false));
		}
	}
}
