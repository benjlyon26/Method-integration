QuantNorm SpectraMax v0_3_0 - transfer package
================================================
Copy into the EXISTING workspace on the target computer (paths relative to the workspace folder):

  Methods\Quant_Norm_SpectraMax_v0_3_0.met   -> <Workspace>\Methods\   (alongside v0_2_5; do not replace it)
  Scripts\*.cs  (5 files)                     -> <Workspace>\Scripts\   (keep the old script versions; v0_2_5 uses them)

  Variables\WorkspaceVariables_ADD_THESE.xml.txt
      MERGE, do not overwrite: back up <Workspace>\WorkspaceVariables.config, then paste the 26
      <Variable> blocks immediately before </Variables>.

Set up on the target computer (see Docs\SoftMax_Protocol_Setup_Guide.md, sections 4-5):
  - Add the SpectraMax device (SpectraMax.config + Workspace.config entry + InitializeOrder.xml), Simulation = False
  - Remove SR710 / BarCodeZAxis from the hardware config if that Lynx has no SR710
  - Build the SoftMax protocol (sections Blank / Read_1 / Read_2) and point Open File at it
  - Teach Loc_28 as the SpectraMax drawer; point Lunatic_01..04 at the half-area UV plate labware
  - Fill in the SPECTRAMAX: comment steps in the method with the reader commands
  - The worktable layout inside the .met came from the GSK Demo dev workspace - check it on first open

Docs\   setup guide, scientist review questions, adaptation plan (reference only)
Tests\  offline harness for ReaderNormVI (reference only; not needed by MM4)