using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace MM4DeviceInstaller
{
	public sealed class MainForm : Form
	{
		private readonly TextBox _dataFolder = new TextBox();
		private readonly TextBox _programFolder = new TextBox();
		private readonly CheckedListBox _workspaces = new CheckedListBox();
		private readonly CheckedListBox _devices = new CheckedListBox();
		private readonly Label _deviceDetail = new Label();
		private readonly BreathingLog _log = new BreathingLog();
		private readonly Button _install = new Button();
		private readonly Panel _itPanel = new Panel();
		private readonly TextBox _itMessage = new TextBox();
		private readonly Button _copyMessage = new Button();
		private readonly Label _status = new Label();
		private List<DevicePackage> _packages = new List<DevicePackage>();
		private string _loadedDataFolder = "";
		private bool _busy;

		public MainForm()
		{
			Text = "MM4 Device Installer";
			Font = new Font("Segoe UI", 9f);
			AutoScaleMode = AutoScaleMode.Font;
			Size sample = TextRenderer.MeasureText("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", Font);
			AutoScaleDimensions = new SizeF(sample.Width / 52f, Font.Height);
			ShowIcon = true;
			Icon = LoadWindowIcon();
			StartPosition = FormStartPosition.CenterScreen;
			ApplyWindowSize();
			BackColor = Color.FromArgb(244, 246, 248);

			int space = Font.Height + 8;
			Panel header = new Panel();
			header.Dock = DockStyle.Top;
			header.Padding = new Padding(space, space, space, space);
			header.Font = Font;
			header.BackColor = Color.FromArgb(20, 72, 114);
			Label title = new Label();
			title.Text = "MM4 Device Installer";
			title.ForeColor = Color.White;
			title.Font = new Font("Segoe UI", 16f, FontStyle.Bold);
			title.AutoSize = true;
			title.Dock = DockStyle.Top;
			title.Margin = new Padding(0, 0, 0, 4);
			Label subtitle = new Label();
			subtitle.Text = "Check the devices and the workspaces. This folder can live on a USB drive.";
			subtitle.ForeColor = Color.FromArgb(214, 228, 240);
			subtitle.AutoSize = true;
			subtitle.Dock = DockStyle.Top;
			subtitle.Margin = new Padding(2, 2, 0, 0);
			header.Controls.Add(subtitle);
			header.Controls.Add(title);
			header.Height = header.Padding.Vertical + title.PreferredHeight + subtitle.PreferredHeight + title.Margin.Vertical + subtitle.Margin.Vertical + 8;

			_itPanel.Dock = DockStyle.Bottom;
			_itPanel.Height = 250;
			_itPanel.Visible = false;
			_itPanel.Padding = new Padding(16, 8, 16, 12);
			_itPanel.BackColor = Color.FromArgb(255, 248, 236);
			Label itLabel = new Label();
			itLabel.Dock = DockStyle.Top;
			itLabel.Height = 22;
			itLabel.Text = "The workspace is updated. The program file still has to be moved. Send this to IT:";
			_itMessage.Multiline = true;
			_itMessage.ReadOnly = true;
			_itMessage.ShortcutsEnabled = true;
			_itMessage.HideSelection = false;
			_itMessage.TabStop = true;
			_itMessage.Cursor = Cursors.IBeam;
			_itMessage.ScrollBars = ScrollBars.Vertical;
			_itMessage.Dock = DockStyle.Fill;
			_itMessage.BorderStyle = BorderStyle.FixedSingle;
			_itMessage.BackColor = Color.White;
			_itMessage.Font = new Font("Segoe UI", 9f);
			ContextMenuStrip messageMenu = new ContextMenuStrip();
			messageMenu.Items.Add("Copy", null, delegate { CopyMessageText(SelectedOrAll(_itMessage)); });
			messageMenu.Items.Add("Select all", null, delegate { _itMessage.SelectAll(); _itMessage.Focus(); });
			_itMessage.ContextMenuStrip = messageMenu;
			_copyMessage.Text = "Copy message";
			_copyMessage.Dock = DockStyle.Bottom;
			_copyMessage.Height = 32;
			_copyMessage.FlatStyle = FlatStyle.Flat;
			_copyMessage.BackColor = Color.FromArgb(31, 106, 165);
			_copyMessage.ForeColor = Color.White;
			_copyMessage.Click += CopyMessageClick;
			_itPanel.Controls.Add(itLabel);
			_itPanel.Controls.Add(_copyMessage);
			_itPanel.Controls.Add(_itMessage);

			Panel body = new Panel();
			body.Dock = DockStyle.Fill;
			body.Padding = new Padding(space, space, space, space);

			TableLayoutPanel grid = new TableLayoutPanel();
			grid.Dock = DockStyle.Fill;
			grid.ColumnCount = 1;
			grid.RowCount = 5;
			grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
			grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));
			grid.RowStyles.Add(new RowStyle(SizeType.Percent, 56f));
			grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));
			grid.RowStyles.Add(new RowStyle(SizeType.Percent, 44f));
			grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));

			grid.Controls.Add(BuildFolderBlock(), 0, 0);
			grid.Controls.Add(BuildPickers(), 0, 1);
			grid.Controls.Add(BuildInstallRow(), 0, 2);
			_log.Dock = DockStyle.Fill;
			_log.Margin = new Padding(0, 0, 0, 8);
			grid.Controls.Add(_log, 0, 3);
			_status.Dock = DockStyle.Fill;
			_status.Margin = new Padding(0);
			_status.Padding = new Padding(2, 4, 2, 4);
			_status.TextAlign = ContentAlignment.MiddleLeft;
			_status.ForeColor = Color.FromArgb(60, 70, 80);
			grid.Controls.Add(_status, 0, 4);

			body.Controls.Add(grid);
			Controls.Add(body);
			Controls.Add(_itPanel);
			Controls.Add(header);
			_itPanel.SendToBack();
			header.SendToBack();

			_dataFolder.Text = Locations.DefaultDataRoot;
			_dataFolder.Leave += delegate
			{
				if (!string.Equals(_dataFolder.Text.Trim(), _loadedDataFolder, StringComparison.OrdinalIgnoreCase))
				{
					RefreshWorkspaces();
				}
			};
			_programFolder.Text = Locations.FindProgramFolder();
			LoadDevices();
			RefreshWorkspaces();
			WarnIfMethodManagerIsOpen();
		}

		protected override void OnShown(EventArgs e)
		{
			base.OnShown(e);
			RevealPathEnd(_dataFolder);
			RevealPathEnd(_programFolder);
			if (!Directory.Exists(_dataFolder.Text))
			{
				MessageBox.Show(this,
					"C:\\MethodManager4 was not found. Choose the Method Manager data folder. It is the folder that contains Workspaces.",
					"Choose a folder",
					MessageBoxButtons.OK,
					MessageBoxIcon.Information);
				BrowseData();
			}
		}

		protected override void OnFormClosing(FormClosingEventArgs e)
		{
			if (_busy)
			{
				e.Cancel = true;
			}
			base.OnFormClosing(e);
		}

		private void ApplyWindowSize()
		{
			Rectangle work = Screen.FromPoint(Cursor.Position).WorkingArea;
			int clientW = Math.Min(980, Math.Max(640, work.Width - 32));
			int clientH = Math.Min(820, Math.Max(520, work.Height - 48));
			ClientSize = new Size(clientW, clientH);
			MinimumSize = new Size(Math.Min(720, work.Width), Math.Min(520, work.Height));
		}

		private Control BuildFolderBlock()
		{
			TableLayoutPanel table = new TableLayoutPanel();
			table.Dock = DockStyle.Fill;
			table.ColumnCount = 2;
			table.RowCount = 2;
			int labelWidth = TextRenderer.MeasureText("Program folder", Font).Width + 16;
			table.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, labelWidth));
			table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
			table.RowStyles.Add(new RowStyle(SizeType.AutoSize));
			table.RowStyles.Add(new RowStyle(SizeType.AutoSize));
			table.Margin = new Padding(0, Font.Height / 3, 0, Font.Height / 2);
			table.Controls.Add(MakeLabel("Data folder"), 0, 0);
			table.Controls.Add(MakeLabel("Program folder"), 0, 1);
			table.Controls.Add(MakeFolderRow(_dataFolder, BrowseData), 1, 0);
			table.Controls.Add(MakeFolderRow(_programFolder, BrowseProgram), 1, 1);
			return table;
		}

		private Control MakeFolderRow(TextBox box, EventHandler browse)
		{
			int textHeight = TextRenderer.MeasureText("Ag", Font).Height;
			int rowHeight = textHeight + 16;
			Panel row = new Panel();
			row.Margin = new Padding(0, 6, 0, 6);
			row.Height = rowHeight;
			row.MinimumSize = new Size(0, rowHeight);
			row.Dock = DockStyle.Fill;
			Button button = MakeBrowse("Browse", browse);
			button.AutoSize = true;
			int browseWidth = button.PreferredSize.Width + 16;
			int browseHeight = Math.Max(button.PreferredSize.Height, textHeight + 8);
			button.AutoSize = false;
			button.Size = new Size(browseWidth, browseHeight);
			box.Width = 40;
			row.Controls.Add(button);
			row.Controls.Add(box);
			row.Resize += delegate { PlaceFolderRow(row, box, button); };
			PlaceFolderRow(row, box, button);
			return row;
		}

		private static void PlaceFolderRow(Panel row, TextBox box, Button button)
		{
			int gap = 8;
			int buttonTop = Math.Max(0, (row.ClientSize.Height - button.Height) / 2);
			button.SetBounds(Math.Max(0, row.ClientSize.Width - button.Width), buttonTop, button.Width, button.Height);
			int boxHeight = Math.Max(box.PreferredSize.Height, box.Height);
			int boxTop = Math.Max(0, (row.ClientSize.Height - boxHeight) / 2);
			int boxWidth = Math.Max(20, button.Left - gap);
			box.SetBounds(0, boxTop, boxWidth, boxHeight);
		}

		private Control BuildPickers()
		{
			TableLayoutPanel table = new TableLayoutPanel();
			table.Dock = DockStyle.Fill;
			table.ColumnCount = 2;
			table.RowCount = 2;
			table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 38f));
			table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 62f));
			table.RowStyles.Add(new RowStyle(SizeType.AutoSize));
			table.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
			table.Padding = new Padding(0, 6, 0, 0);
			table.Controls.Add(MakeCaption("Workspaces"), 0, 0);
			table.Controls.Add(MakeCaption("Devices"), 1, 0);
			_workspaces.Dock = DockStyle.Fill;
			_workspaces.CheckOnClick = true;
			_workspaces.IntegralHeight = false;
			_workspaces.Margin = new Padding(0, 2, 12, 0);
			_devices.Dock = DockStyle.Fill;
			_devices.CheckOnClick = true;
			_devices.IntegralHeight = false;
			_devices.Margin = new Padding(0);
			_devices.SelectedIndexChanged += DeviceSelectionChanged;
			Panel devicePanel = new Panel();
			devicePanel.Dock = DockStyle.Fill;
			devicePanel.Margin = new Padding(0, 2, 0, 0);
			_deviceDetail.Dock = DockStyle.Bottom;
			_deviceDetail.Height = Font.Height + 10;
			_deviceDetail.Padding = new Padding(0, 4, 0, 0);
			_deviceDetail.AutoEllipsis = true;
			_deviceDetail.ForeColor = Color.FromArgb(60, 70, 80);
			_devices.Dock = DockStyle.Fill;
			devicePanel.Controls.Add(_devices);
			devicePanel.Controls.Add(_deviceDetail);
			table.Controls.Add(_workspaces, 0, 1);
			table.Controls.Add(devicePanel, 1, 1);
			return table;
		}

		private Control BuildInstallRow()
		{
			FlowLayoutPanel row = new FlowLayoutPanel();
			row.Dock = DockStyle.Fill;
			row.FlowDirection = FlowDirection.RightToLeft;
			row.WrapContents = false;
			_install.Text = "Install";
			_install.AutoSize = true;
			Size installSize = _install.PreferredSize;
			_install.AutoSize = false;
			_install.Size = new Size(installSize.Width + 36, installSize.Height + 8);
			_install.Margin = new Padding(0, 8, 0, 8);
			_install.FlatStyle = FlatStyle.Flat;
			_install.FlatAppearance.BorderSize = 0;
			_install.BackColor = Color.FromArgb(31, 106, 165);
			_install.ForeColor = Color.White;
			_install.Click += InstallClick;
			row.Controls.Add(_install);
			return row;
		}

		private static Icon LoadWindowIcon()
		{
			try
			{
				using (Icon extracted = Icon.ExtractAssociatedIcon(Application.ExecutablePath))
				{
					if (extracted != null)
					{
						return (Icon)extracted.Clone();
					}
				}
			}
			catch
			{
			}
			return SystemIcons.Application;
		}

		private static void RevealPathEnd(TextBox box)
		{
			if (!box.IsHandleCreated || box.TextLength == 0)
			{
				return;
			}
			box.SelectionStart = box.TextLength;
			box.SelectionLength = 0;
			box.ScrollToCaret();
		}

		private static Label MakeLabel(string text)
		{
			Label label = new Label();
			label.Text = text;
			label.AutoSize = true;
			label.Anchor = AnchorStyles.Left;
			label.Margin = new Padding(0, 8, 8, 8);
			label.TextAlign = ContentAlignment.MiddleLeft;
			return label;
		}

		private static Label MakeCaption(string text)
		{
			Label label = new Label();
			label.Text = text;
			label.AutoSize = true;
			label.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
			label.Margin = new Padding(2, 4, 8, 8);
			label.Padding = new Padding(0, 2, 0, 2);
			return label;
		}

		private static Button MakeBrowse(string text, EventHandler click)
		{
			Button button = new Button();
			button.Text = text;
			button.Click += click;
			return button;
		}

		private void BrowseData(object sender, EventArgs e)
		{
			BrowseData();
		}

		private void BrowseProgram(object sender, EventArgs e)
		{
			using (FolderBrowserDialog dialog = new FolderBrowserDialog())
			{
				dialog.Description = "Select the Method Manager program folder. It contains MethodManager.DX.exe.";
				if (Directory.Exists(_programFolder.Text))
				{
					dialog.SelectedPath = _programFolder.Text;
				}
				if (dialog.ShowDialog(this) == DialogResult.OK)
				{
					_programFolder.Text = Locations.NormalizeProgramFolder(dialog.SelectedPath);
					RevealPathEnd(_programFolder);
				}
			}
		}

		private void BrowseData()
		{
			using (FolderBrowserDialog dialog = new FolderBrowserDialog())
			{
				dialog.Description = "Select the Method Manager data folder. It contains the Workspaces folder.";
				if (Directory.Exists(_dataFolder.Text))
				{
					dialog.SelectedPath = _dataFolder.Text;
				}
				if (dialog.ShowDialog(this) == DialogResult.OK)
				{
					_dataFolder.Text = dialog.SelectedPath;
					RevealPathEnd(_dataFolder);
					RefreshWorkspaces();
				}
			}
		}

		private void LoadDevices()
		{
			string folder = DevicePackage.FindDevicesFolder();
			List<string> errors = new List<string>();
			_packages = DevicePackage.LoadAll(folder, errors);
			_devices.Items.Clear();
			foreach (DevicePackage package in _packages)
			{
				_devices.Items.Add(package.DisplayName, false);
			}
			LogImportant("Device packages: " + folder);
			foreach (string error in errors)
			{
				LogImportant(error);
			}
			if (_packages.Count == 0)
			{
				LogImportant("No devices were found. Each device needs a subfolder of Devices with device.xml, a DLL, and a config file.");
			}
		}

		private void RefreshWorkspaces()
		{
			_workspaces.Items.Clear();
			_loadedDataFolder = _dataFolder.Text.Trim();
			if (!Directory.Exists(_loadedDataFolder))
			{
				_status.Text = "Choose the Method Manager data folder.";
				return;
			}
			List<WorkspaceChoice> choices = Locations.ListWorkspaces(_loadedDataFolder);
			foreach (WorkspaceChoice choice in choices)
			{
				_workspaces.Items.Add(choice);
			}
			if (choices.Count == 0)
			{
				_status.Text = "No workspaces were found in that folder.";
				LogImportant("No workspace with a Workspace.config file was found under " + _loadedDataFolder);
			}
			else
			{
				_status.Text = choices.Count == 1
					? "1 workspace found. Check it and the devices, then click Install."
					: choices.Count.ToString() + " workspaces found. Check the workspaces and the devices, then click Install.";
			}
		}

		private void DeviceSelectionChanged(object sender, EventArgs e)
		{
			int index = _devices.SelectedIndex;
			if (index < 0 || index >= _packages.Count)
			{
				_deviceDetail.Text = "";
				return;
			}
			_deviceDetail.Text = _packages[index].Description;
		}

		private void InstallClick(object sender, EventArgs e)
		{
			if (_busy)
			{
				return;
			}
			List<WorkspaceChoice> workspaces = SelectedWorkspaces();
			if (workspaces.Count == 0)
			{
				MessageBox.Show(this, "Check at least one workspace.", "Workspaces", MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}
			List<DevicePackage> selected = SelectedPackages();
			if (selected.Count == 0)
			{
				MessageBox.Show(this, "Check at least one device.", "Devices", MessageBoxButtons.OK, MessageBoxIcon.Information);
				return;
			}
			string programFolder = _programFolder.Text.Trim();
			bool programOk = Locations.ProgramFolderLooksValid(programFolder);
			_busy = true;
			_install.Enabled = false;
			_itPanel.Visible = false;
			UseWaitCursor = true;
			List<PendingDll> pending = new List<PendingDll>();
			List<DllCopyJob> needAdmin = new List<DllCopyJob>();
			bool allCopied = true;
			try
			{
				List<DevicePackage> ready = new List<DevicePackage>();
				foreach (DevicePackage package in selected)
				{
					string problem = package.ValidateFiles();
					if (problem != null)
					{
						allCopied = false;
						Log(package.DisplayName + ": " + problem);
						continue;
					}
					string compatibility = DeviceCompatibility.Problem(package, programFolder);
					if (compatibility != null)
					{
						bool unreadable = compatibility.IndexOf("could not be read", StringComparison.Ordinal) >= 0;
						UseWaitCursor = false;
						bool proceed = !unreadable && DeviceCompatibility.ConfirmProceed(this, compatibility);
						UseWaitCursor = true;
						LogImportant(package.DisplayName + ": " + compatibility);
						if (!proceed)
						{
							allCopied = false;
							if (!unreadable)
							{
								LogImportant(package.DisplayName + ": skipped. The workspace was left unchanged.");
							}
							continue;
						}
						Log(package.DisplayName + ": Proceed.");
					}
					ready.Add(package);
				}
				foreach (WorkspaceChoice workspace in workspaces)
				{
					Log("Installing into " + workspace.Name + ".");
					foreach (DevicePackage package in ready)
					{
						WorkspaceUpdate update = WorkspaceInstall.Apply(workspace.DirectoryPath, package);
						if (!string.IsNullOrEmpty(update.Error))
						{
							allCopied = false;
							LogImportant(workspace.Name + ": " + package.DisplayName + " workspace update failed: " + update.Error);
							continue;
						}
						LogWorkspaceUpdate(workspace, package, update);
					}
				}
				string library = programOk ? Locations.DevicesLibrary(programFolder) : "";
				foreach (DevicePackage package in ready)
				{
					foreach (string fileName in package.LibraryFiles)
					{
						string source = Path.Combine(package.Folder, fileName);
						if (!programOk)
						{
							allCopied = false;
							foreach (WorkspaceChoice workspace in workspaces)
							{
								QueuePending(pending, package, workspace, library, source, "MethodManager.DX.exe was not found in the program folder.");
							}
							continue;
						}
						string destination = Path.Combine(library, fileName);
						bool bytesMatch = DllCopy.SameContent(source, destination);
						bool marked = bytesMatch && DllCopy.HasZoneIdentifier(destination);
						string error = null;
						if (bytesMatch && !marked)
						{
							continue;
						}
						if (marked && DllCopy.TryClearZoneIdentifier(destination, out error))
						{
							Log("Removed the internet mark from:");
							Log("  " + destination);
							continue;
						}
						if (!bytesMatch && DllCopy.TryCopy(source, destination, out error))
						{
							Log("Copied the DLL to:");
							Log("  " + destination);
							continue;
						}
						LogImportant(package.DisplayName + " needs administrator approval before the DLL can be copied.");
						LogDllPlace("The DLL is located at:", source, "Copy it to:", destination);
						needAdmin.Add(new DllCopyJob
						{
							Source = source,
							Destination = destination,
							Error = error,
							DeviceName = package.DisplayName,
							WorkspaceName = workspaces[0].Name,
							WorkspaceDirectory = workspaces[0].DirectoryPath
						});
					}
				}
				if (needAdmin.Count > 0)
				{
					_status.Text = "Approve the Windows prompt. It may open in front of this window.";
					_status.Refresh();
					Application.DoEvents();
					string elevateError;
					DllCopy.TryElevatedCopy(needAdmin, out elevateError);
					if (!string.IsNullOrEmpty(elevateError))
					{
						LogImportant("The Windows approval did not finish: " + elevateError);
					}
					foreach (DllCopyJob job in needAdmin)
					{
						bool loadable = DllCopy.SameContent(job.Source, job.Destination) && !DllCopy.HasZoneIdentifier(job.Destination);
						if (loadable)
						{
							Log("Copied the DLL to:");
							Log("  " + job.Destination);
						}
						else
						{
							allCopied = false;
							string reason = job.Error;
							if (string.IsNullOrEmpty(reason))
							{
								reason = elevateError;
							}
							if (string.IsNullOrEmpty(reason) && DllCopy.HasZoneIdentifier(job.Destination))
							{
								reason = "The DLL is still marked as downloaded from the internet.";
							}
							foreach (WorkspaceChoice workspace in workspaces)
							{
								string saved = DllCopy.CopyIntoWorkspace(workspace.DirectoryPath, job.Source);
								LogDllPlace("The DLL is located at:", saved, "Copy it to:", job.Destination);
								pending.Add(new PendingDll
								{
									DeviceName = job.DeviceName,
									WorkspaceName = workspace.Name,
									SavedAt = saved,
									SourceFolder = Path.GetDirectoryName(job.Source),
									IntendedFolder = Path.GetDirectoryName(job.Destination),
									Reason = reason
								});
							}
						}
					}
				}
				if (pending.Count > 0)
				{
					allCopied = false;
					_itMessage.Text = ItMessage.Build(pending, programOk ? programFolder : "");
					_itPanel.Visible = true;
					_copyMessage.Text = "Copy message";
					_status.Text = "Workspace files are in place. Select the message below and copy it.";
					ShowUncopiedDllFolders(pending);
				}
				if (allCopied)
				{
					_log.Clear();
					_status.Text = "";
					Log("All files copied successfully.");
				}
				else
				{
					WarnIfMethodManagerIsOpen();
				}
			}
			catch (Exception ex)
			{
				LogImportant("Install failed: " + ex.Message);
				_status.Text = "Install failed.";
			}
			finally
			{
				_busy = false;
				_install.Enabled = true;
				UseWaitCursor = false;
			}
		}

		private void QueuePending(List<PendingDll> pending, DevicePackage package, WorkspaceChoice workspace, string library, string sourcePath, string reason)
		{
			string saved = DllCopy.CopyIntoWorkspace(workspace.DirectoryPath, sourcePath);
			string fileName = Path.GetFileName(sourcePath);
			string copyTo = string.IsNullOrEmpty(library) ? "" : Path.Combine(library, fileName);
			if (string.IsNullOrEmpty(copyTo))
			{
				copyTo = @"C:\Program Files (x86)\Dynamic Devices\MethodManager4\Libraries\Devices\" + fileName;
			}
			LogImportant("Could not copy the DLL into Method Manager.");
			LogDllPlace("The DLL is located at:", saved, "Copy it to:", copyTo);
			if (!string.IsNullOrEmpty(reason))
			{
				LogImportant(reason);
			}
			pending.Add(new PendingDll
			{
				DeviceName = package.DisplayName,
				WorkspaceName = workspace.Name,
				SavedAt = saved,
				SourceFolder = Path.GetDirectoryName(sourcePath),
				IntendedFolder = library,
				Reason = reason
			});
		}

		private void LogWorkspaceUpdate(WorkspaceChoice workspace, DevicePackage package, WorkspaceUpdate update)
		{
			string name = workspace.Name;
			if (update.DeviceAdded)
			{
				Log(name + ": added " + package.DeviceName + " to Workspace.config.");
			}
			if (update.DeviceAlreadyPresent)
			{
				Log(name + ": " + package.DeviceName + " is already in this workspace.");
			}
			if (update.InitAdded)
			{
				Log(name + ": added " + package.ComponentName + " to InitializeOrder.xml.");
			}
			if (update.ConfigCopied)
			{
				Log(name + ": saved Configuration\\" + package.DeviceName + ".config.");
			}
			if (update.ConfigReplaced)
			{
				Log(name + ": replaced the old " + package.DeviceName + ".config. The previous file was kept as a .bak beside it.");
			}
			if (update.ConfigKept)
			{
				Log(name + ": left the existing " + package.DeviceName + ".config in place, so the COM port is unchanged.");
			}
		}

		private List<WorkspaceChoice> SelectedWorkspaces()
		{
			List<WorkspaceChoice> selected = new List<WorkspaceChoice>();
			for (int i = 0; i < _workspaces.Items.Count; i++)
			{
				if (!_workspaces.GetItemChecked(i))
				{
					continue;
				}
				WorkspaceChoice choice = _workspaces.Items[i] as WorkspaceChoice;
				if (choice != null)
				{
					selected.Add(choice);
				}
			}
			return selected;
		}

		private List<DevicePackage> SelectedPackages()
		{
			List<DevicePackage> selected = new List<DevicePackage>();
			for (int i = 0; i < _devices.Items.Count && i < _packages.Count; i++)
			{
				if (_devices.GetItemChecked(i))
				{
					selected.Add(_packages[i]);
				}
			}
			return selected;
		}

		private void CopyMessageClick(object sender, EventArgs e)
		{
			CopyMessageText(_itMessage.Text);
		}

		private void CopyMessageText(string text)
		{
			if (string.IsNullOrEmpty(text))
			{
				return;
			}
			try
			{
				Clipboard.SetText(text);
				_copyMessage.Text = "Copied";
				_status.Text = "The message is on the clipboard. Paste it into an email to IT.";
			}
			catch (Exception ex)
			{
				_status.Text = "Could not copy the message: " + ex.Message;
			}
		}

		private static string SelectedOrAll(TextBox box)
		{
			if (box == null)
			{
				return "";
			}
			if (!string.IsNullOrEmpty(box.SelectedText))
			{
				return box.SelectedText;
			}
			return box.Text;
		}

		private void ShowUncopiedDllFolders(IList<PendingDll> pending)
		{
			List<string> destinations = new List<string>();
			List<string> sources = new List<string>();
			ExplorerFolders.Collect(pending, destinations, sources);
			OpenFolderList(destinations, "Opened the folder where the DLL is pasted:", "Could not open the folder where the DLL is pasted:");
			OpenFolderList(sources, "Opened the folder that contains the DLL:", "Could not open the folder that contains the DLL:");
		}

		private void OpenFolderList(IList<string> folders, string openedLabel, string failedLabel)
		{
			foreach (string folder in folders)
			{
				string error = ExplorerFolders.Open(folder);
				if (error == "")
				{
					LogImportant(openedLabel);
					LogImportant("  " + folder);
				}
				else
				{
					LogImportant(failedLabel);
					LogImportant("  " + folder);
					LogImportant("  " + error);
				}
			}
		}

		private void WarnIfMethodManagerIsOpen()
		{
			if (Process.GetProcessesByName("MethodManager.DX").Length > 0)
			{
				LogImportant("Method Manager is open. Close it and choose not to save the workspace if it asks. A save from the open session can overwrite the files this installer writes.");
			}
		}

		private void LogDllPlace(string locatedLabel, string locatedAt, string copyLabel, string copyTo)
		{
			LogImportant(locatedLabel);
			LogImportant("  " + locatedAt);
			LogImportant(copyLabel);
			LogImportant("  " + copyTo);
		}

		private void Log(string line)
		{
			AppendLog(line, false);
		}

		private void LogImportant(string line)
		{
			AppendLog(line, true);
		}

		private void AppendLog(string line, bool important)
		{
			if (string.IsNullOrEmpty(line))
			{
				return;
			}
			_log.AppendLine(line, important);
		}
	}
}
