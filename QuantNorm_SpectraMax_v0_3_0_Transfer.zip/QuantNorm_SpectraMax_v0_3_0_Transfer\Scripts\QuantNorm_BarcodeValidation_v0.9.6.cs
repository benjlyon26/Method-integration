﻿using System;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using MethodManager.Core;
using MMScriptObjects;

// ============================================================================
// QuantNorm_BarcodeValidation — Track B (LM900) In-Vivo RNA Quant/Norm, script 2 of the spine
// ============================================================================
// VERSION HISTORY (why-first)
//   v0.1.0  2026-07-28  First pass. Modelled on Tody's reference workflow BarcodeValidation_v5 but reshaped for
//                       this workflow, which is NOT the same problem.
//
//   THE STRUCTURAL DIFFERENCE FROM REFERENCE WORKFLOW, AND IT DRIVES EVERYTHING BELOW:
//     reference workflow knows what barcode to expect at BOTH ends - it compares expected-vs-scanned for sources
//     AND destinations. Track B does not. Appendix B fields 9 and 11 (QuantificationPlateBarcode,
//     OutputPlateBarcode) are marked "Lynx (kickoff) - Captured during deck scan": they are EMPTY in
//     the incoming worklist and the whole point of scanning them is to find out what they are
//     (Jim's ruling, S14). So:
//       SOURCE  plates -> full expected-vs-scanned VALIDATION (presence, extras, duplicates, position)
//       QUANT / OUTPUT -> CAPTURE. There is nothing to compare against, so the only faults possible
//                         are "nothing came back" and "the same barcode twice".
//     Copying reference workflow's Checks 2 and 4 would have meant inventing expected values that do not exist.
//
//   IT EVALUATES AGAINST THE WORKLIST DIRECTLY (Jim, and it is also D-S15-17). The expected source
//   barcodes are RE-DERIVED here by re-reading the worklist CSV from disk. It deliberately does NOT
//   consume User.ExpectedSourceBarcode_List_01, even though the ingestion script writes it: trusting
//   that variable would mean this check agrees with ingestion's parse instead of testing it. If
//   ingestion mis-read the file, a check built on its output would confirm the mistake.
//
//   ONE COUNT, NOT THREE (Jim: "it always looks at source count"). The spec fixes 1:1:1 - QUANT-001
//   one Quantification Plate per Source Plate, GEN-002 one Output Plate per Source Plate - so the
//   number of source plates governs all three scan loops. Three independent counts could drift apart
//   and silently skip a plate.
//
//   NO OVERRIDE. VERIFY-003 permits re-scan / documented override / abort; Jim has ruled the override
//   OUT for now. This script therefore never offers a way to accept a mismatch. It reports and fails;
//   the method decides between rescan and abort. RECORDED AS A DELIBERATE DEVIATION from the spec,
//   not an omission.
//
//   MANUAL ENTRY IS NOT AN OVERRIDE, and the distinction is a WIRING rule the method must honour:
//   typing a barcode in because the scanner read NOTHING is capture, and the typed value is still
//   validated here. Typing over a barcode that WAS read and disagrees is an override by another name.
//   Only offer manual entry when the scan actually returned nothing.
//
//   v0.2.0  2026-07-28  THE POSITION CHECK WAS WRONG AND IS REMOVED. Jim: the order in which the
//                       operator loads the source plates will almost certainly NOT match worklist
//                       order, and that is fine.
//                       v0.1.0 compared expected[i] against scanned[i] and would therefore have failed
//                       most real runs. It also contradicted this project's OWN design: the S14 devlog
//                       specifies a "provisional deck mapping (distinct source barcodes in first-seen
//                       order ...) - recomputed later at barcode scan" and lists the deck-mapping
//                       variables as "ingestion (provisional), corrected at barcode reconcile".
//                       WHAT REPLACES IT: source validation is now SET equality - every expected
//                       barcode present, exactly once, none extra, correct count. Then THE SCAN DEFINES
//                       THE MAPPING: a barcode found at scan position k belongs to plate set k, so its
//                       worklist rows are re-pointed at Source_Standin_k / Lunatic_k / Output_k /
//                       Sample_Tips_k. The provisional lists ingestion wrote are overwritten with what
//                       was actually found.
//                       THIS IS NOT THE "REINDEX" VERIFY-003 FORBIDS. Forbidden is remapping to accept
//                       a deck that DISAGREES with the worklist. Here the deck AGREES exactly - every
//                       expected plate present once - and only the arrangement differs. Nothing is
//                       being accepted that should not be.
//                       ⚠ ROWS ARE NEVER REORDERED, only re-pointed in place. Tody's v4 was a CRITICAL
//                       fix precisely because v2 moved row GROUPS while the plate-name strings still
//                       referred to the original worktable locations - "the robot goes to the right
//                       location name but finds the wrong plate there". Keeping rows in worklist order
//                       and rewriting only their handle/location makes that failure structurally
//                       impossible.
//                       PLATE SETS ARE CONTIGUOUS FROM SET 1 (Jim), and the operator is told which
//                       positions to load from the ingestion report, then verifies with Show Worktable.
//                       Which BARCODE goes in which of those positions is the operator's choice and is
//                       discovered here.
//
//   v0.3.0  2026-07-28  NAMES MATCHED TO THE METHOD, NO NEW VARIABLES INVENTED (Jim). The scan loop
//                       Jim wired writes User.Barcode_Scanned_List_01 and User.Barcode_Read_By_01.
//                       v0.2.0 read User.ScannedSourceBarcode_List_01 / User.SourceBCReadBy_List_01,
//                       which exist nowhere - so the validator would have seen an empty scan and
//                       reported every plate missing. Jim's rule: use the variables that are actually
//                       in the method rather than adding unused ones. The script moves, not the method.
//                       ALSO: the result message now goes to User.ScriptMessage_01, not
//                       User.BarcodeMessage_01. The method's abort guard displays ScriptMessage_01
//                       (steps [34]/[35], mirroring the ingestion guard at [06]/[07]), and only the
//                       ingestion script was setting it - so a validation failure would have shown the
//                       PREVIOUS script's message, or a blank box. BarcodeMessage_01 stays what the
//                       method already uses it for: the operator's manual-scan prompt at [21]/[22].
//                       One variable, one job.
//                       ⚠ QUANT AND OUTPUT NAMES ARE STILL PLACEHOLDERS. Those two scan loops are not
//                       wired yet, so V_SCAN_Q / V_SCAN_O / V_RB_Q / V_RB_O name variables that do not
//                       exist. They are left alone deliberately - they get renamed to whatever the
//                       method actually writes when those loops are built, exactly as this change did
//                       for source. Until then both groups scan EMPTY and are reported as missing,
//                       which is correct: they ARE missing. See the note on V_SCAN_Q_ON below.
//
//   v0.4.0  2026-07-28  THE QUANT SCAN LOOP IS WIRED, so its two names are no longer placeholders:
//                       User.QuantBarcode_Scanned_List_01 and User.QuantBarcode_Read_By_List_01.
//                       ALSO CORRECTS A v0.3.0 MISTAKE, and it is worth naming: v0.3.0 pointed the
//                       source read-by at User.Barcode_Read_By_01 - the SCALAR that holds one plate's
//                       answer and is overwritten every iteration. At the time that was genuinely all
//                       the method had. The method now accumulates a real list at [29]
//                       (User.Barcode_Read_By_List_01), matching reference workflow's own pattern - scalar set
//                       inside the branches, appended to a list after End If. Reading the scalar would
//                       have given a one-element audit trail for an N-plate run and reported "unknown"
//                       for every plate after the first. The lesson is the general one: a script
//                       constant pointed at a method variable is a CONTRACT, and it goes stale the
//                       moment the method changes shape. Re-read the method, do not trust the constant.
//
//   v0.5.0  2026-07-28  ALL THREE SCAN LOOPS ARE NOW WIRED. Output's two names are no longer
//                       placeholders: User.OutputBarcode_Scanned_List_01 and
//                       User.OutputBarcode_Read_By_List_01. Scan ORDER in the method is
//                       source -> quant -> output (Jim). Order does not matter to this script - it
//                       reads three independent lists - but it is recorded because the loops were
//                       briefly built in the other order and the ambiguity cost real time.
//                       THE NAMING RULE THIS SETTLED, worth stating once: each loop owns FOUR things -
//                       the location list it walks, the Loc variable the ListParser fills, the barcode
//                       list it appends to, and the read-by list. All four must name the SAME group.
//                       A loop whose location list says one group and whose barcode list says another
//                       scans the right positions into the wrong list, and nothing at runtime says so.
//
//   READ-BY IS OPTIONAL. MM4's own manual-entry prompt may or may not populate the read-by lists, and
//   that is not established, so this script uses them when present and records "unknown" when absent
//   rather than assuming either way. VERIFY-004 wants to know how each barcode was read; this reports
//   what it actually knows.
// ============================================================================

// v0.9.5: customer-neutral presentation release; execution logic is unchanged.
public class MMScriptExecutor : IMMScriptExecutor
{
    // v0.9.3  2026-07-30  MATCHES THE NEW LIST CONTRACT (Jim, D-S20-05 + D-S20-06). No logic change.
    //                     The seven per-row lists this script rewrites after the scan moved to Row_*
    //                     names, because the un-prefixed names now belong to the METHOD and hold ONE
    //                     ELEMENT PER PLATE SET — commands are plate/labware major, and a plate loop
    //                     indexing a 168-element per-row list read plate 1 every time.
    //                     This script deliberately does NOT write the plate-major lists: the handle
    //                     for set k is <prefix>_kk, fixed by the set number, and a scan that passes
    //                     set-equality cannot change the number of sets. It writes only what the scan
    //                     actually determines — which ROW belongs to which set.
    //                     Everything published now leads with a comma so a base-1 counter needs no -1.
    // v0.9.4  2026-10-07  Coordinated repair release; see CHANGELOG.md and README.md.
    // v0.9.6  2026-11-18  SpectraMax / no-SR710 variant. Quant VIs rebuilt from ingestion's published
    //                     QuantSampleVolume_01 / QuantDiluentVolume_01 (were literals "5;5;0"/"3"), and
    //                     the quant-diluent + mix VI lists are rebuilt alongside them. Operator wording
    //                     says "re-enter the barcodes" (typed at the keyboard) instead of "re-scan".
    //                     Matching logic is unchanged: typed barcodes are Read_By = Manual.
    private const string SCRIPT_VERSION = "v0.9.6";
    private const int    MAX_SOURCE_PLATES = 4;

    // ---- what ingestion left for us ----
    const string V_WLFILE   = "User.WorklistFile_01";
    const string V_SRCLOC   = "User.ExpectedSourceLoc_List_01";   // context for messages only
    const string V_QLOC     = "User.QuantScanLoc_List_01";
    const string V_OLOC     = "User.OutputScanLoc_List_01";

    // ---- what the method's scan loops produce ----
    // WIRED - Read Source Barcodes section. Cleared at [15]/[16], built inside the loop.
    const string V_SCAN_SRC = "User.Barcode_Scanned_List_01";        // [24] manual / [27] scanner
    const string V_RB_SRC   = "User.Barcode_Read_By_List_01";       // optional; accumulated at [29]
    // WIRED - Read Quant Barcodes section. Same shape, own lists (cleared at [33]/[34]).
    const string V_SCAN_Q   = "User.QuantBarcode_Scanned_List_01";   // [42] manual / [45] scanner
    const string V_RB_Q     = "User.QuantBarcode_Read_By_List_01";  // optional; accumulated at [47]
    // WIRED - Read OutPut Barcodes section. Same shape again (cleared at [51]/[52]).
    const string V_SCAN_O   = "User.OutputBarcode_Scanned_List_01"; // [60] manual / [63] scanner
    const string V_RB_O     = "User.OutputBarcode_Read_By_List_01"; // optional; accumulated at [65]

    // ---- switch: is the Lunatic group being scanned at all? ----
    // Jim wants a plan for removing the Lunatic plates. If that group is disabled its scanned list is
    // simply EMPTY - and an absence must never be read as a result. This states the intent explicitly
    // instead of inferring it from emptiness. Anything other than "False" means the group is scanned.
    // ---- v0.6.0 BARCODE MODE GATES (Jim, S18) — replaces User.ScanQuantPlates_01 ----------------
    // The METHOD gates each optional scan section on these with Operator = NotEmpty:
    //     [33] If User.QuantBarcode_Perform_01  NotEmpty ... [50] End If
    //     [53] If User.OutputBarcode_Perform_01 NotEmpty ... [70] End If
    // ⚠ NotEmpty, NOT a True/False test. The old V_SCAN_Q_ON convention ("False" = off) is WRONG
    // against this method: the string "False" is non-empty and would RUN the scan. Emptiness is the
    // gate; the text carries the MODE this script pairs by.
    //
    //   ""         NOT BARCODED  — no scan happened. Pair by deck ROW. Generate a tracking ID,
    //                              because Appendix B fields 9/11 still have to be populated
    //                              (DATA-001), and a blank there is not acceptable output.
    //   "CAPTURE"  BARCODED, assigned as loaded — scan ran. Pair by deck ROW. Keep the scanned value.
    //   "WORKLIST" BARCODED and DESIGNATED by the worklist — scan ran. Pair BY BARCODE: the plate
    //              carrying the barcode this row names is the one to use, and it MAY SIT IN A
    //              DIFFERENT DECK ROW from the source plate. Verify designated == found.
    const string V_QPERFORM = "User.QuantBarcode_Perform_01";
    const string V_OPERFORM = "User.OutputBarcode_Perform_01";
    const string MODE_NONE     = "";
    const string MODE_CAPTURE  = "CAPTURE";
    const string MODE_WORKLIST = "WORKLIST";

    const string V_RUNID = "User.RunID_01";   // read-only here; seeds the generated tracking IDs

    // ---- v0.7.0 OPERATOR RESOLUTION (Jim, S18) ---------------------------------------------
    // The script now owns the decision surface. It pauses the run, explains the fault, and offers
    // named buttons; the answer lands here for the method to branch on. Chosen over the method's own
    // Show Message because (a) the script writes these strings itself, so there is no guessing what
    // MM4's ResultsVariable returns, (b) the script can lay the diagnostic out properly, and (c) the
    // script can OutputMsg the operator's decision into the MM4 log — which Show Message cannot do,
    // and which is exactly what VERIFY-003 ("log all resolution actions") and DATA-004 require.
    //
    // ⚠ CLEARED AT THE START OF EVERY ATTEMPT. If a RESCAN from attempt 1 survived, the method would
    // jump back to the Rescan label, this script would pass, and the stale RESCAN would send it back
    // again — an INFINITE LOOP on the deck. Same bug class as the V_ABORT one fixed in v0.6.0.
    const string V_RESOLUTION = "User.BarcodeResolution_01";
    const string RES_RESCAN   = "RESCAN";
    const string RES_ABORT    = "ABORT";

    // Attempt counter for this RUN (ingestion blanks it at run start; this script increments it).
    // Jim, S18: cap at 3. On the final attempt the re-scan button is not offered at all, so a deck
    // fault that is not going to resolve cannot loop forever.
    const string V_ATTEMPT    = "User.BarcodeAttempt_01";
    private const int MAX_ATTEMPTS = 3;

    // ---- v0.8.0 REPORT ----------------------------------------------------------------------
    // MM4's own post-scan record of the deck: Location, Stack index, Plate name, Plate barcode,
    // Labware, X, Y, Z, Worktable, Device — rows '|' separated, fields ','. Captured by method step
    // [74] AFTER all three scan sections. CONFIRMED on this LM900 (2026-07-29) to carry the scanned
    // barcode, and to leave a present-but-unscanned plate BLANK — so it evidences scan coverage too.
    // This is an INDEPENDENT anchor: MM4 wrote it, this script did not, so agreement between the two
    // is a real cross-check rather than the script confirming itself.
    const string V_WORKTBL2 = "User.OutputWorktable_02";
    // ⚠ THIS VARIABLE HOLDS A FILE PATH BY THE TIME WE READ IT, NOT A FOLDER.
    // Ingestion sets it to the output FOLDER early (v0.8.2 line 651), then OVERWRITES it with the
    // full path of its own HTML report when it emits it (line 977). Since the validator runs after
    // ingestion, it always sees the file. v0.8.0's first live run fell back to %TEMP% for exactly
    // this reason — the earlier comment here claimed it was a folder, which was simply wrong.
    // ResolveReportDir() below accepts either meaning rather than depending on which one it is.
    const string V_REPORTDIR = "User.ReportPath_01";

    // Whether the run is on a real instrument. NOTHING IN MM4 EXPOSES THIS — the run log of a test-mode
    // run is byte-for-byte the same shape as a live one (established VR-002 F8). So it cannot be
    // detected and must be DECLARED. The validation-record standard makes it mandatory (field 3,
    // "Test mode vs live instrument stated explicitly"), and VR-002 had to leave that field open for
    // exactly this reason. Absent a declaration the report says so rather than implying either.
    const string V_TESTMODE = "User.RunIsTestMode_01";

    private const string ATTEMPT_SENTINEL = "<!--ATTEMPTS-->";

    // ---- outputs ----
    const string V_CHECK    = "User.BarcodeCheck_01";
    // The method's abort guard after this Run Script step shows User.ScriptMessage_01 - the same
    // variable the ingestion guard shows. Writing anywhere else means the operator reads a stale
    // message from the previous script, or nothing at all. User.BarcodeMessage_01 is NOT reused here:
    // the method already owns it as the manual-scan prompt at [21]/[22].
    const string V_MESSAGE  = "User.ScriptMessage_01";
    const string V_ABORT    = "User.AbortMethod_01";

    // ---- per-sample lists we populate on success, for the eventual worklist write-back ----
    const string L_QBC      = "User.QuantBarcode_List_01";
    const string L_OBC      = "User.OutputBarcode_List_01";

    // ---- per-sample deck mapping: PROVISIONAL from ingestion, CORRECTED here from the scan ----
    // v0.9.3 — THESE ARE NOW ROW-LEVEL NAMES, AND THAT IS THE WHOLE CHANGE.
    // MM4 commands are plate/labware major (Jim, D-S20-06), so the names the METHOD reads —
    // SourcePlate_List_01, QuantPlate_List_01, OutputPlate_List_01, TipBox_List_01 — now hold ONE
    // ELEMENT PER PLATE SET and are written by ingestion. This script must NOT overwrite them: the
    // handle for plate set k is simply <prefix>_kk, fixed by the set number, and a scan that passes
    // set-equality cannot change how many sets there are. What the scan DOES decide is which ROWS
    // belong to which set, and that is what these row-level lists carry — for the completed worklist
    // and for the sibling scripts. Nothing in the method reads them, by design.
    const string R_SRCPLATE = "User.Row_SourcePlate_List_01";
    const string R_SRCLOC   = "User.Row_SourceLoc_List_01";
    const string R_QPLATE   = "User.Row_QuantPlate_List_01";
    const string R_QLOC     = "User.Row_QuantLoc_List_01";
    const string R_OPLATE   = "User.Row_OutputPlate_List_01";
    const string R_OLOC     = "User.Row_OutputLoc_List_01";
    const string R_TIPBOX   = "User.Row_TipBox_List_01";

    const string HDL_SOURCE  = "Source_Standin_";
    const string HDL_LUNATIC = "Lunatic_";
    const string HDL_OUTPUT  = "Output_";
    const string HDL_SAMPTIP = "Sample_Tips_";

    private class Problem
    {
        public string What = "", Where = "", Detail = "", Fix = "";
    }

    private List<Problem> problems = new List<Problem>();
    private int attempt = 1;                 // 1-based; capped at MAX_ATTEMPTS

    // ---- v0.8.0 report state -----------------------------------------------------------------
    // STATE, not outcome — each field is set at the moment the thing it describes becomes true, so
    // the report can never describe a comparison it had nothing to compare against. Same discipline
    // ingestion adopted in v0.7.6 after a report claimed a validation it had not performed.
    // Only what the report cannot read live. Verdict, resolution and message are deliberately NOT
    // cached here - the report reads them with GetVariableValue at write time, so it shows the state
    // the METHOD will actually see rather than a copy that could have drifted from it.
    private string rpRunId = "", rpQMode = "", rpOMode = "";
    private List<string> rpScanSrc = new List<string>(), rpScanQ = new List<string>(), rpScanO = new List<string>();
    private List<string> rpRbSrc = new List<string>(),   rpRbQ = new List<string>(),   rpRbO = new List<string>();
    private List<string> rpLocSrc = new List<string>(),  rpLocQ = new List<string>(),  rpLocO = new List<string>();
    private int rpRows = 0, rpPlates = 0;
    private bool reportWritten = false;
    private bool reportInWorkspace = true;   // false => written outside the workspace, NOT production-valid
    private string reportPath = "";          // set by WriteReport so the operator message can cite it
    private bool checksReached = false;      // false => we failed before any comparison was possible

    public void Execute(IMMApp app)
    {
        try
        {
            RunChecks(app);
        }
        catch (Exception ex)
        {
            // A crash here must not look like a pass. Fail closed, loudly.
            Set(app, V_CHECK, "False");
            Set(app, V_MESSAGE, "Barcode validation could not run:\n\n" + ex.Message
                + "\n\nThe run has been stopped because the barcodes could not be checked.");
            Set(app, V_ABORT, "True");
            // A crash offers no re-scan, and must not leave a RESCAN from a previous attempt standing
            // — the method would jump back to the Rescan label on the strength of a stale value.
            Set(app, V_RESOLUTION, RES_ABORT);
            try { app.OutputMsg("[QuantNorm barcode " + SCRIPT_VERSION + "] EXCEPTION: " + ex.ToString(), true); }
            catch (Exception) { }
            // A crash is exactly when a record matters most - it is the only account of what the run
            // held at the moment it failed.
            WriteReport(app);
        }
    }

    private void RunChecks(IMMApp app)
    {
        problems.Clear(); reportWritten = false; checksReached = false;
        Qn.CheckWorklist(app);
        // ---------- 0. THIS ATTEMPT STARTS WITH NO VERDICT ----------
        // Required for the RE-SCAN loop. Ingestion sets AbortMethod_01 = "False" once per run, but a
        // re-scan re-enters THIS script without re-running ingestion. Without this line the sequence
        // is: attempt 1 fails -> flag True -> operator chooses re-scan -> attempt 2 PASSES -> flag is
        // still True -> the guard fires and aborts a run that just passed. The flag has to describe
        // THIS attempt, not the worst attempt so far.
        Set(app, V_ABORT, "False");
        Set(app, V_RESOLUTION, "");   // ⚠ MUST be cleared, or a stale RESCAN loops the deck forever
        problems.Clear();          // same reason: a retry must not inherit the previous attempt's list

        // Which attempt is this? Ingestion blanks the counter at run start, so a blank means attempt 1.
        int prior; if (!int.TryParse(Get(app, V_ATTEMPT).Trim(), out prior)) prior = 0;
        attempt = prior + 1;
        Set(app, V_ATTEMPT, attempt.ToString());
        // Read early so even a failure BEFORE the checks lands in the right report file rather than
        // in a stray NORUNID one.
        rpRunId = Get(app, V_RUNID).Trim();

        // ---------- 1. RE-DERIVE THE TRUTH FROM THE WORKLIST ITSELF ----------
        string wl = Get(app, V_WLFILE);
        if (wl.Length == 0 || !File.Exists(wl))
        {
            Fail(app, "The worklist file could not be found, so the scanned barcodes cannot be checked "
                + "against it.\n\nExpected: " + (wl.Length == 0 ? "(no path recorded)" : wl)
                + "\n\nRun the worklist ingestion step again, then re-enter the barcodes.");
            return;
        }

        List<string> expectedSrc;                  // distinct source barcodes, first-seen order
        List<int> plateOfRow;                      // per worklist row -> plate index, for the fan-out
        List<string> desigQOfRow, desigOOfRow;     // per row, designated quant/output barcode (WORKLIST mode)
        string readErr = ReadWorklist(wl, out expectedSrc, out plateOfRow, out desigQOfRow, out desigOOfRow);
        if (readErr.Length > 0) { Fail(app, "The worklist could not be re-read: " + readErr); return; }

        if (expectedSrc.Count == 0)
        { Fail(app, "The worklist lists no source plates, so there is nothing to check the scan against."); return; }

        // ---------- 2. WHAT THE SCAN PRODUCED ----------
        List<string> scanSrc = ParseList(Get(app, V_SCAN_SRC));
        List<string> scanQ   = ParseList(Get(app, V_SCAN_Q));
        List<string> scanO   = ParseList(Get(app, V_SCAN_O));
        List<string> rbSrc   = ParseList(Get(app, V_RB_SRC));
        List<string> rbQ     = ParseList(Get(app, V_RB_Q));
        List<string> rbO     = ParseList(Get(app, V_RB_O));
        List<string> locSrc  = ParseList(Get(app, V_SRCLOC));
        List<string> locQ    = ParseList(Get(app, V_QLOC));
        List<string> locO    = ParseList(Get(app, V_OLOC));

        // v0.6.0 — read the two mode gates exactly as the METHOD reads them: emptiness is the gate.
        // Anything the operator did not choose comes back "" and means "not barcoded, no scan".
        string qMode = NormMode(Get(app, V_QPERFORM));
        string oMode = NormMode(Get(app, V_OPERFORM));
        bool quantScanned  = qMode.Length > 0;     // exactly what [33] If NotEmpty decided
        bool outputScanned = oMode.Length > 0;     // exactly what [53] If NotEmpty decided
        string runId = Get(app, V_RUNID).Trim();

        // Snapshot for the report, taken from the SAME values the checks below run on — so the report
        // shows what was actually judged, not a re-read that could have changed underneath it.
        rpRunId = runId; rpQMode = qMode; rpOMode = oMode;
        rpScanSrc = scanSrc; rpScanQ = scanQ; rpScanO = scanO;
        rpRbSrc = rbSrc;     rpRbQ = rbQ;     rpRbO = rbO;
        rpLocSrc = locSrc;   rpLocQ = locQ;   rpLocO = locO;
        rpRows = plateOfRow.Count; rpPlates = expectedSrc.Count;
        checksReached = true;

        int n = expectedSrc.Count;      // the source count governs all three groups (1:1:1 per the spec)

        // ---------- 3. SOURCE PLATES - the only group with expected values ----------
        CheckCount(scanSrc, n, "source", locSrc);
        CheckDuplicates(scanSrc, "source", locSrc);

        var expectedSet = new HashSet<string>(expectedSrc);
        var scannedSet  = new HashSet<string>(scanSrc);

        for (int i = 0; i < expectedSrc.Count; i++)
            if (!scannedSet.Contains(expectedSrc[i]))
                problems.Add(new Problem {
                    // v0.9.2: NAME THE PLATE. v0.9.1 gave every missing source plate the SAME headline,
                    // so a 2-plate failure printed the identical line twice with nothing to tell them
                    // apart — seen live in the 13:53 run's abort message. S18 fixed exactly this for the
                    // output headlines and the source half was left behind.
                    What = "The worklist needs source plate " + expectedSrc[i] + ", and it is not on the deck",
                    Where = "expected at " + At(locSrc, i) + " (source plate " + (i + 1) + " of " + n + ")",
                    Detail = "The worklist expects barcode " + expectedSrc[i] + ". Nothing with that barcode was scanned.",
                    Fix = "Put the correct plate at " + At(locSrc, i) + " and re-enter the barcodes, or abort the run." });

        for (int i = 0; i < scanSrc.Count; i++)
            if (!expectedSet.Contains(scanSrc[i]))
                problems.Add(new Problem {
                    What = "Source plate " + scanSrc[i] + " is on the deck at " + At(locSrc, i)
                         + ", and the worklist does not mention it",
                    Where = At(locSrc, i) + " (read by " + ReadBy(rbSrc, i) + ")",
                    Detail = "Scanned barcode " + scanSrc[i] + " is not in the worklist.",
                    Fix = "Remove that plate, put the correct one at " + At(locSrc, i)
                        + " and re-enter the barcodes, or abort the run." });

        // NO POSITION CHECK. The operator loads the source plates in whatever order suits them and
        // that is expected (Jim) - so worklist order carries no positional meaning and comparing
        // expected[i] to scanned[i] would fail most real runs. The checks above are SET equality, which
        // is the real requirement: the plates on the deck are exactly the plates the worklist names.
        // Where each one physically sits is DISCOVERED below, not asserted.

        // ---------- 4. QUANT AND OUTPUT - what is checked depends on the MODE ----------
        // v0.6.0. Three modes per group, and the checks that are POSSIBLE differ in each:
        //   NONE      nothing was scanned, so there is nothing to check. Verifying an empty list
        //             against anything would be a check that can never fail (the S16 D-S16-01 trap).
        //   CAPTURE   values exist but no expectation does, so only "something came back for every
        //             position" and "nothing repeats" are available.
        //   WORKLIST  an expectation DOES exist, so this is real reconciliation - set equality
        //             between what the worklist designates and what the deck actually holds.
        CheckGroup(qMode, scanQ, n, "quantification (SpectraMax)", locQ, rbQ, expectedSet,
                   DistinctNonEmpty(desigQOfRow), V_QPERFORM);
        CheckGroup(oMode, scanO, n, "output", locO, rbO, expectedSet,
                   DistinctNonEmpty(desigOOfRow), V_OPERFORM);

        // ---------- 5. VERDICT ----------
        // The ONLY failure that offers a re-scan: these are deck faults, and a deck fault is the one
        // thing the operator can actually go and correct.
        if (problems.Count > 0) { Fail(app, BuildMessage(n, quantScanned), true); return; }

        // ---------- 6. PASS - THE SCAN NOW DEFINES WHERE EVERY PLATE IS ----------
        // scanPosOf[barcode] = the scan position that barcode was found at. Because the scan loop walks
        // the location list in order and the plate sets are contiguous from set 1, scan position k IS
        // plate set k+1: Source_Standin_(k+1) at locSrc[k], Lunatic_(k+1) at locQ[k], and so on.
        var scanPosOf = new Dictionary<string, int>();
        for (int i = 0; i < scanSrc.Count; i++)
            if (scanSrc[i].Length > 0 && !scanPosOf.ContainsKey(scanSrc[i])) scanPosOf[scanSrc[i]] = i;

        // Rewrite the per-sample lists from what was ACTUALLY found. Rows stay in worklist order and
        // are only RE-POINTED - see the v4 note in the header: moving rows around while their plate
        // names still refer to the old locations is how reference workflow sent the arm to the right location
        // name and the wrong plate.
        // v0.6.0 — WORKLIST mode needs to know where each barcode actually turned up, exactly as the
        // source group already does. Built for both groups; only consulted in WORKLIST mode.
        var qPosOf = PosOf(scanQ);
        var oPosOf = PosOf(scanO);

        var qPerRow = new List<string>(); var oPerRow = new List<string>();
        var srcPlate = new List<string>(); var srcLoc = new List<string>();
        var qPlate = new List<string>();   var qLoc = new List<string>();
        var oPlate = new List<string>();   var oLoc = new List<string>();
        var tipBox = new List<string>();
        for (int r = 0; r < plateOfRow.Count; r++)
        {
            string bc = expectedSrc[plateOfRow[r]];
            // The SOURCE plate's own scan position is the deck ROW this sample belongs to. Verified
            // physically: Loc_07/13/19 share Y ~ -10.2, Loc_08/14/20 ~ -114.6, Loc_09/15/21 ~ -219,
            // Loc_10/16/22 ~ -323, so Source_Standin_0N / Lunatic_0N / Output_0N ARE the same row.
            int kRow = scanPosOf.ContainsKey(bc) ? scanPosOf[bc] : plateOfRow[r];   // set equality passed
            string ixRow = (kRow + 1).ToString("D2");

            srcPlate.Add(HDL_SOURCE + ixRow);  srcLoc.Add(Val(locSrc, kRow));
            tipBox.Add(HDL_SAMPTIP + ixRow);

            // ⚠ THE S18 FIX (VR-002 F2). Up to v0.5.0 the quant and output plates were taken at the
            // SOURCE plate's scan position unconditionally — the quant/output barcode text was never
            // read. Swapping two Lunatic plates therefore sent all 133 rows to the wrong plate with
            // nothing reporting it. Each group now resolves its OWN index according to its own mode.
            int kQ = GroupIndex(qMode, kRow, Row(desigQOfRow, r), qPosOf);
            string qName = HDL_LUNATIC + (kQ + 1).ToString("D2");
            qPlate.Add(qName); qLoc.Add(Val(locQ, kQ));
            qPerRow.Add(BarcodeFor(qMode, scanQ, kQ, runId, qName));

            int kO = GroupIndex(oMode, kRow, Row(desigOOfRow, r), oPosOf);
            string oName = HDL_OUTPUT + (kO + 1).ToString("D2");
            oPlate.Add(oName); oLoc.Add(Val(locO, kO));
            oPerRow.Add(BarcodeFor(oMode, scanO, kO, runId, oName));
        }
        Set(app, R_SRCPLATE, Join2(srcPlate)); Set(app, R_SRCLOC, Join2(srcLoc));
        Set(app, R_QPLATE,   Join2(qPlate));   Set(app, R_QLOC,   Join2(qLoc));
        Set(app, R_OPLATE,   Join2(oPlate));   Set(app, R_OLOC,   Join2(oLoc));
        Set(app, R_TIPBOX,   Join2(tipBox));
        Set(app, L_QBC, Join2(qPerRow));
        Set(app, L_OBC, Join2(oPerRow));

        // v0.6.0 — when a group was not scanned, the method never reached its read-by String Builder
        // (Jim's If gate encloses it), so that list is blank. Record HOW the value was obtained, so a
        // generated tracking ID can never be mistaken later for something a scanner actually read.
        // Uses the existing per-plate variables rather than inventing new ones (D-S17-01, Jim).
        if (qMode.Length == 0) Set(app, V_RB_Q, GeneratedReadBy(n));
        if (oMode.Length == 0) Set(app, V_RB_O, GeneratedReadBy(n));

        // What ended up where, for the log and for the operator-facing message.
        var mapText = new StringBuilder();
        for (int i = 0; i < scanSrc.Count; i++)
            mapText.Append(i > 0 ? "; " : "").Append(scanSrc[i]).Append(" -> ")
                   .Append(HDL_SOURCE).Append((i + 1).ToString("D2")).Append(" @ ").Append(At(locSrc, i));

        RebuildExecutionPlan(app, srcPlate, qPlate, oPlate, tipBox, n);
        RecordBarcodeAttempt(app, "PASS");
        Set(app, V_CHECK, "True");
        // The message states WHAT WAS ACTUALLY DONE per group rather than a single blanket sentence,
        // because "verified" now means three different things and an operator reading a PASS is
        // entitled to know which one applied to which plates.
        string ok = "All barcodes verified: " + n + " source plate(s) match the worklist. "
            + "Quant plates: " + ModeSentence(qMode) + " Output plates: " + ModeSentence(oMode);
        Set(app, V_MESSAGE, ok);
        try {
            app.OutputMsg("[QuantNorm barcode " + SCRIPT_VERSION + "] " + ok
                + "  AS LOADED: " + mapText.ToString()
                + "  quant[" + (quantScanned ? qMode : "not barcoded") + "]: " + Join(scanQ)
                + "  output[" + (outputScanned ? oMode : "not barcoded") + "]: " + Join(scanO)
                + "  (deck mapping and barcodes rewritten per sample row)", false);
        } catch (Exception) { }

        WriteReport(app);     // the pass path writes too - a report that only appears on failure is not evidence
    }

    // =====================================================================================
    //  CHECK HELPERS
    // =====================================================================================

    private void CheckCount(List<string> scanned, int expected, string label, List<string> locs)
    {
        if (scanned.Count == expected) return;
        problems.Add(new Problem {
            What = "The wrong number of " + label + " plates was scanned",
            Where = "the " + label + " scan loop",
            Detail = "The worklist needs " + expected + " " + label + " plate(s); the scan produced "
                   + scanned.Count + " barcode(s).",
            Fix = scanned.Count < expected
                ? "A plate is missing from the deck, or a barcode entry was skipped. Load the missing plate and re-enter the barcodes, or abort."
                : "There are more plates on the deck than the worklist uses. Remove the extras and re-enter the barcodes, or abort." });
    }

    private void CheckDuplicates(List<string> scanned, string label, List<string> locs)
    {
        var firstAt = new Dictionary<string, int>();
        for (int i = 0; i < scanned.Count; i++)
        {
            if (scanned[i].Length == 0) continue;
            if (firstAt.ContainsKey(scanned[i]))
                problems.Add(new Problem {
                    What = "The same " + label + " barcode was read twice",
                    Where = At(locs, firstAt[scanned[i]]) + " and " + At(locs, i),
                    Detail = "Barcode " + scanned[i] + " was scanned at both positions.",
                    Fix = "Two positions cannot hold the same plate - one was misread, or the same plate "
                        + "was entered twice. Check both positions and re-enter the barcodes, or abort." });
            else firstAt[scanned[i]] = i;
        }
    }

    // Capture-only group: we do not know what these SHOULD say, so we can only insist that something
    // came back for every position and that nothing repeats.
    private void CheckCapture(List<string> scanned, int expected, string label, List<string> locs, List<string> readby)
    {
        CheckCount(scanned, expected, label, locs);
        for (int i = 0; i < scanned.Count && i < expected; i++)
            if (scanned[i].Trim().Length == 0)
                problems.Add(new Problem {
                    What = "No barcode was captured for " + Art(label).ToLowerInvariant() + " " + label + " plate",
                    Where = At(locs, i) + " (" + label + " plate " + (i + 1) + " of " + expected + ")",
                    Detail = "The scan returned nothing for this position and no value was entered.",
                    Fix = "This barcode is written into the completed worklist, so it cannot be left blank. "
                        + "Re-enter the barcode for that position (check for a typo), or abort the run." });
        CheckDuplicates(scanned, label, locs);
    }

    private void CrossCollision(List<string> scanned, HashSet<string> sourceBarcodes, string label, List<string> locs)
    {
        for (int i = 0; i < scanned.Count; i++)
            if (scanned[i].Length > 0 && sourceBarcodes.Contains(scanned[i]))
                problems.Add(new Problem {
                    What = "A source plate appears to be sitting in " + Art(label).ToLowerInvariant() + " " + label + " position",
                    Where = At(locs, i),
                    Detail = "Barcode " + scanned[i] + " is a SOURCE plate barcode from the worklist, but it "
                           + "was scanned at " + Art(label).ToLowerInvariant() + " " + label + " position.",
                    Fix = "The plates are in the wrong places. Put the correct plate at " + At(locs, i)
                        + " and re-enter the barcodes, or abort the run." });
    }

    // =====================================================================================
    //  v0.6.0  MODE-DRIVEN GROUP CHECK
    // =====================================================================================
    //  The checks that are POSSIBLE differ by mode, and running a check that cannot fail is worse
    //  than running none - that is exactly what D-S16-01 caught (two self-report checks that
    //  compared against text the code itself had reworded, so they printed PASS on worklists built
    //  to break them). So each mode gets only the checks that can actually detect something.
    private void CheckGroup(string mode, List<string> scanned, int expected, string label,
                            List<string> locs, List<string> readby, HashSet<string> sourceBarcodes,
                            List<string> designated, string gateVar)
    {
        if (mode.Length == 0)
        {
            // Not barcoded, so no scan ran. The only detectable fault is values being present anyway,
            // which means a list survived from an earlier run. Ingestion blanks these four lists at
            // the top of every run precisely so this condition is real evidence rather than noise.
            if (scanned.Count > 0)
                problems.Add(new Problem {
                    What = label + " barcodes are present even though those plates are set as not barcoded",
                    Where = "run configuration (" + gateVar + ")",
                    Detail = gateVar + " is empty, so the " + label + " scan was skipped, yet " + scanned.Count
                           + " barcode(s) are in the list. They are left over from an earlier run.",
                    Fix = "Start the method again from the first step so worklist ingestion clears them, or set "
                        + "the " + label + " plates to barcoded in the worklist dialog if they really are." });
            return;
        }

        if (!mode.Equals(MODE_CAPTURE) && !mode.Equals(MODE_WORKLIST))
        {
            // Fail closed. Any non-empty value made the METHOD run the scan, but only these two words
            // tell this script how to pair. An unrecognised value means the run is not configured.
            problems.Add(new Problem {
                What = "The " + label + " barcode setting is not recognised",
                Where = "run configuration (" + gateVar + ")",
                Detail = gateVar + " holds \"" + mode + "\". The only values understood are an empty value "
                       + "(not barcoded), \"" + MODE_CAPTURE + "\", or \"" + MODE_WORKLIST + "\".",
                Fix = "Start the method again and choose the " + label + " option in the worklist dialog." });
            return;
        }

        // Both scanning modes: something must have come back for every position, nothing may repeat,
        // and no SOURCE plate may be sitting in one of these positions.
        CheckCapture(scanned, expected, label, locs, readby);
        CrossCollision(scanned, sourceBarcodes, label, locs);

        if (!mode.Equals(MODE_WORKLIST)) return;

        // WORKLIST is the only mode carrying a real expectation, so it is the only one that can do
        // genuine reconciliation. Same SET-equality shape as the source group: presence is what
        // matters, order is not. Position is DISCOVERED - the whole point of this mode is that the
        // designated plate MAY sit in a different deck row from its source plate.
        if (designated.Count == 0)
        {
            problems.Add(new Problem {
                What = "The worklist does not say which " + label + " plates to use",
                Where = "the worklist",
                Detail = gateVar + " is set to " + MODE_WORKLIST + ", meaning the worklist designates the "
                       + label + " plate for each sample - but that column is empty on every row.",
                Fix = "Use a worklist that names the " + label + " plate barcodes, or choose the "
                    + "\"assign as loaded\" option in the worklist dialog instead." });
            return;
        }
        var found = new HashSet<string>(scanned);
        foreach (string d in designated)
            if (!found.Contains(d))
                problems.Add(new Problem {
                    // NAMES THE BARCODE. Two missing plates previously produced two identical
                    // headlines, so an operator reading the summary learned nothing from the second.
                    What = "The worklist asks for " + label + " plate " + d + ", and it is not on the deck",
                    Where = "the " + label + " positions",
                    Detail = "The worklist designates barcode " + d + ". Nothing with that barcode was scanned.",
                    Fix = "Load that plate and re-enter the barcodes, or abort the run." });
        var desigSet = new HashSet<string>(designated);
        for (int i = 0; i < scanned.Count; i++)
            if (scanned[i].Length > 0 && !desigSet.Contains(scanned[i]))
                problems.Add(new Problem {
                    What = label + " plate " + scanned[i] + " is on the deck at " + At(locs, i)
                         + ", and the worklist does not ask for it",
                    Where = At(locs, i),
                    Detail = "Scanned barcode " + scanned[i] + " is not designated anywhere in the worklist.",
                    Fix = "Remove that plate, load the correct one, and re-enter the barcodes, or abort the run." });
    }

    // Which index of THIS group a row uses. NONE and CAPTURE both pair by deck row; only WORKLIST
    // relocates, following the designated barcode to wherever it was actually found.
    private static int GroupIndex(string mode, int kRow, string designated, Dictionary<string, int> posOf)
    {
        if (!mode.Equals(MODE_WORKLIST)) return kRow;
        if (designated.Length > 0 && posOf.ContainsKey(designated)) return posOf[designated];
        return kRow;    // unreachable once the WORKLIST checks pass; row-pairing is the safe fallback
    }

    // The value written into Appendix B field 9 / field 11 for this row.
    private static string BarcodeFor(string mode, List<string> scanned, int k, string runId, string plateName)
    {
        if (mode.Length > 0) return Val(scanned, k);        // scanned, in either scanning mode
        return GeneratedId(runId, plateName);
    }

    // Not barcoded, but DATA-001 still requires the completed worklist populated per the field-source
    // mapping - a blank there is not acceptable output. So the traceability is GENERATED. It does not
    // need to encode the source plate: Appendix B is one row per sample, so this value and the row's
    // SourcePlateBarcode already sit on the same line, and that line IS the link.
    private static string GeneratedId(string runId, string plateName)
    { return (runId.Length > 0 ? runId : "NORUNID") + "-" + plateName; }

    // Per-PLATE read-by list in the method's leading-delimiter convention (",a,b"), so a loop counter
    // starting at 1 indexes the first real value - the same shape the scan loops build.
    private static string GeneratedReadBy(int n)
    {
        var sb = new StringBuilder();
        for (int i = 0; i < n; i++) sb.Append(",Generated");
        return sb.ToString();
    }

    private static Dictionary<string, int> PosOf(List<string> scanned)
    {
        var d = new Dictionary<string, int>();
        for (int i = 0; i < scanned.Count; i++)
            if (scanned[i].Length > 0 && !d.ContainsKey(scanned[i])) d[scanned[i]] = i;
        return d;
    }

    private static List<string> DistinctNonEmpty(List<string> src)
    {
        var outp = new List<string>();
        foreach (string s in src)
        { string t = (s ?? "").Trim(); if (t.Length > 0 && !outp.Contains(t)) outp.Add(t); }
        return outp;
    }

    private static string Row(List<string> l, int r)
    { return (r >= 0 && r < l.Count) ? (l[r] ?? "").Trim() : ""; }

    private static string ModeSentence(string mode)
    {
        if (mode.Length == 0)               return "not barcoded - used the plate in the same deck row as its source plate, tracking ID generated.";
        if (mode.Equals(MODE_CAPTURE))      return "barcoded - used the plate in the same deck row as its source plate, barcode recorded as loaded.";
        if (mode.Equals(MODE_WORKLIST))     return "barcoded - matched to the plate the worklist designates, wherever it was loaded.";
        return "setting not recognised (\"" + mode + "\").";
    }

    private static string NormMode(string raw)
    {
        string s = (raw ?? "").Trim();
        if (s.Length == 0) return MODE_NONE;
        if (s.Equals(MODE_CAPTURE,  StringComparison.OrdinalIgnoreCase)) return MODE_CAPTURE;
        if (s.Equals(MODE_WORKLIST, StringComparison.OrdinalIgnoreCase)) return MODE_WORKLIST;
        return s;   // unrecognised, kept verbatim so the diagnostic can name what was actually there
    }

    // =====================================================================================
    //  WORKLIST RE-READ - the independent derivation of what SHOULD be there
    // =====================================================================================
    //  Deliberately its own parser rather than a shared one: this exists to disagree with ingestion
    //  when ingestion is wrong, and code shared with the thing under test cannot do that.
    // v0.6.0 — also returns the DESIGNATED quantification/output barcodes per row. They are normally
    // empty (Appendix B.1: "Plate barcodes that are scanned at run kickoff are left empty"), and are
    // only meaningful in WORKLIST mode, where the worklist is what says which plate belongs to which
    // source. Read unconditionally so the caller can tell an empty column from an absent one.
    private string ReadWorklist(string path, out List<string> distinctSrc, out List<int> plateOfRow,
                                out List<string> desigQOfRow, out List<string> desigOOfRow)
    {
        distinctSrc = new List<string>();
        plateOfRow = new List<int>();
        desigQOfRow = new List<string>();
        desigOOfRow = new List<string>();
        try
        {
            List<string> hdr = null;
            foreach (string raw in Qn.ReadRecords(path))
            {
                string line = raw.TrimEnd();
                if (line.Length == 0 || line.TrimStart().StartsWith("#")) continue;
                string[] cells = Qn.Fields(line, ',');
                if (hdr == null)
                {
                    bool looksHeader = false;
                    foreach (string c in cells)
                    { string k = Key(c); if (k == "sourceplatebarcode" || k == "sourcewell") { looksHeader = true; break; } }
                    if (looksHeader) { hdr = new List<string>(); foreach (string c in cells) hdr.Add(Key(c)); }
                    continue;
                }
                int iBc = hdr.IndexOf("sourceplatebarcode"), iSw = hdr.IndexOf("sourcewell");
                if (iBc < 0 || iSw < 0) return "the worklist has no SourcePlateBarcode / SourceWell column";
                string bc = Cell(cells, iBc), sw = Cell(cells, iSw);
                if (bc.Length == 0 || sw.Length == 0) continue;      // ingestion already rejects these
                if (!distinctSrc.Contains(bc))
                {
                    if (distinctSrc.Count >= MAX_SOURCE_PLATES) continue;   // ingestion already rejects over-capacity
                    distinctSrc.Add(bc);
                }
                plateOfRow.Add(distinctSrc.IndexOf(bc));
                // Kept index-matched with plateOfRow so row r's designated barcodes are always [r].
                int iQ = hdr.IndexOf("quantificationplatebarcode"), iO = hdr.IndexOf("outputplatebarcode");
                desigQOfRow.Add(iQ >= 0 ? Cell(cells, iQ) : "");
                desigOOfRow.Add(iO >= 0 ? Cell(cells, iO) : "");
            }
            if (hdr == null) return "no column header row was found";
            return "";
        }
        catch (Exception ex) { return ex.Message; }
    }

    // =====================================================================================
    //  OUTPUT
    // =====================================================================================

    private string BuildMessage(int n, bool quantScanned)
    {
        var m = new StringBuilder();
        m.Append(problems.Count == 1 ? "1 barcode problem was found" : problems.Count + " barcode problems were found");
        m.Append(", so the run has been stopped.\n");
        int k = 0;
        foreach (Problem p in problems)
        {
            k++;
            m.Append("\n").Append(k).Append(". ").Append(p.What)
             .Append("\n     WHERE: ").Append(p.Where)
             .Append("\n     WHAT:  ").Append(p.Detail)
             .Append("\n     FIX:   ").Append(p.Fix).Append("\n");
        }
        // No override is offered anywhere in this text on purpose - see the header note.
        m.Append("\nRe-enter the barcodes after correcting the deck, or abort the run.");
        return m.ToString();
    }

    // Structural failures — a missing or unreadable worklist, or one naming no source plates. There is
    // nothing on the deck to correct, so re-scanning cannot help and the option is not offered.
    private void Fail(IMMApp app, string message) { Fail(app, message, false); }

    private void Fail(IMMApp app, string message, bool canRescan)
    {
        Set(app, V_CHECK, "False");
        Set(app, V_MESSAGE, message);
        // ⚠ v0.6.0 — THIS LINE IS THE FIX FOR THE S18 DEFECT (VR-002 F3).
        // Up to v0.5.0 this method set BarcodeCheck_01 = False and stopped there. Nothing in the
        // method reads BarcodeCheck_01 — grep of Quant_Norm_DEV_01.met returns ZERO occurrences —
        // and the guard after this script tests User.AbortMethod_01, which ingestion had already set
        // to "False" at the start of the run and which nothing here ever changed. So every real
        // barcode failure left the guard reading False: no message, no abort, and execution fell
        // straight through into Quant_Norm and Output. The script even told the operator "the run
        // has been stopped" while the run carried on.
        // The abort flag is the ONLY channel the method actually listens to, so a failure must set it.
        Set(app, V_ABORT, "True");
        try { app.OutputMsg("[QuantNorm barcode " + SCRIPT_VERSION + "] FAILED (attempt " + attempt
            + " of " + MAX_ATTEMPTS + "): " + message.Replace("\n", " "), true); } catch (Exception) { }

        // ---- v0.7.0 OPERATOR RESOLUTION -----------------------------------------------------
        // On the last permitted attempt the re-scan button is not offered at all, rather than offered
        // and then refused. An option the operator cannot use should not be on the screen.
        RecordBarcodeAttempt(app, "FAILED: " + Flatten(message));
        bool offerRescan = canRescan && attempt < MAX_ATTEMPTS;
        bool rescan = AskOperator(app, message, offerRescan);
        RecordBarcodeAttempt(app, rescan ? "OPERATOR: RESCAN" : "OPERATOR: ABORT");

        if (rescan)
        {
            // Deck is being corrected and the method will jump back to the Rescan label. This attempt
            // failed, but the RUN has not — so the abort flag must come back down or the guard fires
            // on the way past. BarcodeCheck_01 stays False; it describes this attempt.
            Set(app, V_RESOLUTION, RES_RESCAN);
            Set(app, V_ABORT, "False");
        }
        else
        {
            Set(app, V_RESOLUTION, RES_ABORT);
            Set(app, V_ABORT, "True");

            // Write the record FIRST, while V_MESSAGE still holds the full diagnostic — the report is
            // where the detail belongs, and it needs to capture what the operator was actually shown.
            WriteReport(app);

            // ⚠ TWO THINGS DRIVE THE WORDING BELOW, BOTH LEARNED FROM A REAL RUN (2026-07-29 12:33).
            //
            // 1. MM4's Show Message STRIPS "\n" FROM A MessageVariable ENTIRELY — not converted to a
            //    space, REMOVED. The v0.8.2 text rendered as "...start the method again.What was
            //    wrong:2 barcode problems..." with words fused together. So this message must read
            //    correctly as ONE UNBROKEN PARAGRAPH. Nothing below relies on a line break; separation
            //    is carried by sentence punctuation and " - " only.
            //    (This script's OWN dialog is unaffected: it converts \n to \r\n for the TextBox.)
            //
            // 2. IT MUST BE SHORT. D-S18-08 decided this screen should CONFIRM a decision already
            //    taken, not repeat the question — and v0.8.2 then appended the entire problem list,
            //    defeating exactly that. The operator has already read the full diagnostic in this
            //    script's own dialog and chosen from it. Repeating it here produced a wall of fused
            //    text that is harder to act on than the short version, and buried the one thing that
            //    is genuinely new at this point: where the record is.
            // The report has just been opened on screen (see WriteReport), so this message points at
            // it rather than reciting a path. A path that wraps over three lines of a message box is
            // the least actionable thing on it, and the operator cannot click it anyway.
            string where = reportPath.Length > 0
                ? "  The full report has opened in your browser." : "";

            if (!canRescan)
            {
                // A STRUCTURAL failure - no worklist, unreadable worklist, no source plates. "Correct
                // the deck" would be wrong advice here, so the specific explanation is kept. It is
                // only FLATTENED, because Show Message would otherwise fuse its lines together.
                Set(app, V_MESSAGE, Flatten(message) + where);
            }
            else
            {
                Set(app, V_MESSAGE,
                    (offerRescan
                        ? "You chose to stop the run. "
                        : "The run has been stopped - barcodes were re-entered " + MAX_ATTEMPTS
                          + " times and the barcodes still did not match. ")
                    + Headlines()
                    + " Nothing has been moved and no labware has been used. "
                    + "Correct the deck, then start the method again." + where);
            }
        }
        // The decision itself goes to the MM4 log. This is the line VERIFY-003 ("log all resolution
        // actions") and DATA-004 (audit trail of operator interventions) are asking for, and it is
        // something the method's own Show Message could not produce.
        try { app.OutputMsg("[QuantNorm barcode " + SCRIPT_VERSION + "] OPERATOR RESOLUTION (attempt "
            + attempt + " of " + MAX_ATTEMPTS + "): " + (rescan ? RES_RESCAN : RES_ABORT)
            + (offerRescan ? "" : "  (re-scan not offered - attempt limit reached)"), true); }
        catch (Exception) { }

        // Written AFTER the decision, so the record is complete rather than half-formed. The operator
        // does not need it to decide - the dialog already carries the full diagnostic, which is the
        // whole reason the script owns the decision surface (D-S18-04).
        WriteReport(app);
    }

    // The decision surface. A custom Form rather than MessageBox so the buttons can say what they
    // actually do and the diagnostic can be read in full without truncation.
    //
    // FAILS CLOSED: any exception building or showing this returns false, i.e. abort. A dialog that
    // cannot be shown must never leave the run sitting on an unanswered question, and must never be
    // mistaken for the operator having chosen to continue.
    // VIRTUAL so the offline harness can substitute a scripted answer and regression-test every path
    // around the dialog — the attempt counter, the flag pairing, the cap — against the SHIPPED logic
    // rather than a copy of it. MM4 instantiates this class directly and is unaffected. The dialog
    // interaction itself (that the buttons look right and read clearly) still needs a real run; that
    // is stated as untested rather than covered by a test that only exercises a stub.
    public virtual bool AskOperator(IMMApp app, string message, bool offerRescan)
    {
        try
        {
            bool rescan = false;
            Form f = new Form();
            f.Text = "Barcode check FAILED - attempt " + attempt + " of " + MAX_ATTEMPTS;
            f.Size = new Size(760, 560);
            f.FormBorderStyle = FormBorderStyle.FixedDialog;
            f.StartPosition = FormStartPosition.CenterScreen;
            f.MaximizeBox = false; f.MinimizeBox = false; f.ControlBox = false;

            Label head = new Label();
            head.Text = "The barcodes on the deck do not match what this run needs. Nothing has been moved "
                      + "and no labware has been used.";
            head.Location = new Point(14, 12); head.Size = new Size(720, 34);
            f.Controls.Add(head);

            TextBox body = new TextBox();
            body.Multiline = true; body.ReadOnly = true; body.WordWrap = true;
            body.ScrollBars = ScrollBars.Vertical;
            body.Font = new Font(FontFamily.GenericMonospace, 9f);
            body.Text = message.Replace("\n", "\r\n");     // TextBox needs CRLF or it renders as one line
            body.Location = new Point(14, 52); body.Size = new Size(722, 380);
            body.SelectionStart = 0; body.SelectionLength = 0;
            f.Controls.Add(body);

            Label foot = new Label();
            foot.Text = offerRescan
                ? "Correct the deck as described above, then choose Re-enter barcodes. Choose Stop the run to end it here."
                : "This was attempt " + MAX_ATTEMPTS + " of " + MAX_ATTEMPTS
                  + ". The run can only be stopped now. Correct the deck and start the method again.";
            foot.Location = new Point(14, 442); foot.Size = new Size(722, 34);
            f.Controls.Add(foot);

            Button stop = new Button();
            stop.Text = "Stop the run";
            stop.Location = new Point(608, 482); stop.Size = new Size(128, 30);
            stop.DialogResult = DialogResult.Cancel;
            f.Controls.Add(stop);
            f.CancelButton = stop;
            f.AcceptButton = stop;            // safe default: Enter/Escape both stop, never continue

            if (offerRescan)
            {
                Button again = new Button();
                again.Text = "Re-enter barcodes";
                again.Location = new Point(462, 482); again.Size = new Size(138, 30);
                again.DialogResult = DialogResult.Retry;
                f.Controls.Add(again);
            }

            rescan = (f.ShowDialog() == DialogResult.Retry);
            f.Dispose();
            return rescan;
        }
        catch (Exception ex)
        {
            try { app.OutputMsg("[QuantNorm barcode " + SCRIPT_VERSION
                + "] could not show the resolution dialog, stopping the run: " + ex.Message, true); }
            catch (Exception) { }
            return false;      // fail closed - abort
        }
    }

    // =====================================================================================
    //  v0.8.0  THE REPORT
    // =====================================================================================
    //  WHY THIS EXISTS. Until now this script wrote NO file. Its per-row output therefore could not
    //  be independently checked by anything: the ingestion report is written BEFORE the scan, and
    //  WorkspaceVariables.config lags a run, so the only account of what the validator decided was
    //  its own one-line log message. Three separate verification questions were blocked by that in a
    //  single session. VERIFY-004, VERIFY-003's logging clause and DATA-004 all require a written
    //  record; none of them can be met without this.
    //
    //  ALWAYS WRITTEN, ON EVERY PATH — pass, deck fault, structural failure, crash. This is the
    //  D-S16-03 lesson: ingestion once returned before writing its report on nine of ten failure
    //  paths, so a real failure produced nothing but a dialog. A report that only appears when things
    //  go well is not evidence.
    //
    //  WRITTEN BEFORE THE OPERATOR IS ASKED, so they can read it while deciding — the same ordering
    //  ingestion uses ("the run report has opened in your browser").
    //
    //  ATTEMPTS ACCUMULATE (Jim). A re-scan appends a new block rather than overwriting, because
    //  VERIFY-003 asks for ALL resolution actions and DATA-004 for an audit trail: if attempt 2
    //  overwrote attempt 1 the record would lose what was wrong the first time, which is the part
    //  worth keeping.
    private void WriteReport(IMMApp app)
    {
        if (reportWritten) return;            // one block per attempt, never two
        reportWritten = true;
        try
        {
            bool inWorkspace;
            string dir = ResolveReportDir(app, out inWorkspace);
            reportInWorkspace = inWorkspace;
            string runId = rpRunId.Length > 0 ? rpRunId : "NORUNID";
            string path = Path.Combine(dir, "QuantNorm_barcode_" + runId + ".html");

            string block = BuildAttemptBlock(app);
            string html;
            if (File.Exists(path))
            {
                // Accumulate: splice this attempt in ahead of the sentinel, keeping the earlier ones.
                string prior = File.ReadAllText(path);
                int at = prior.IndexOf(ATTEMPT_SENTINEL, StringComparison.Ordinal);
                html = at >= 0 ? prior.Substring(0, at) + block + prior.Substring(at)
                               : prior + block;      // sentinel lost somehow - append rather than lose it
            }
            else html = BuildShell(runId, block);

            File.WriteAllText(path, html, new UTF8Encoding(false));
            reportPath = path;      // only after the write succeeded - never cite a file that is not there

            // OPEN IT when something went wrong. Ingestion already does this for its own report
            // (v0.8.3 line 978, same call), so the mechanism is proven in this workspace and the
            // operator is used to a report appearing.
            //
            // WHY ONLY ON FAILURE: a clean run should not throw a browser window at someone who has
            // nothing to act on. On a failure the report is the readable, complete, correctly
            // formatted account - which matters more than usual here, because the method's own
            // Show Message cannot format anything (it strips newlines) and a long file path in that
            // box is the least actionable thing on the screen. Opening the file lets that message
            // stay short and say WHAT was wrong instead of just how many.
            if (problems.Count > 0) OpenReport(path);
            try { app.OutputMsg("[QuantNorm barcode " + SCRIPT_VERSION + "] report: " + path, false); }
            catch (Exception) { }
        }
        catch (Exception ex)
        {
            // A report that cannot be written must not take the run down with it, but it must not be
            // silent either - a missing report has to be visible or it looks like a clean run.
            try { app.OutputMsg("[QuantNorm barcode " + SCRIPT_VERSION + "] REPORT NOT WRITTEN: "
                + ex.Message, true); } catch (Exception) { }
        }
    }

    // WHERE THE REPORT GOES — and this is a production requirement, not a preference (Jim, S18):
    // reports that will be used in production MUST live inside the WORKSPACE, the same way the
    // worklist does. The reasons all point the same way:
    //   - The workspace is the unit that TRAVELS. Workspaces get zipped, copied and restored between
    //     machines and sites; anything outside one is lost the moment it moves.
    //   - %TEMP% is SWEPT by Windows on its own schedule. A record that can silently disappear is not
    //     a record — and DATA-006 requires run summary reports saved to local storage, DATA-003 a
    //     DEFINED location reachable from the configured operating sites. A per-user profile path is
    //     neither defined nor portable.
    //   - Evidence for one run must not be split across two places: ingestion already writes to the
    //     workspace Output folder, so a second report elsewhere is a report nobody finds.
    //
    // PRIMARY SOURCE IS app.WorkspaceOutputPath — the same call ingestion uses. v0.8.0/v0.8.1 read
    // another script's variable instead and inherited its meaning drift (ReportPath_01 starts as the
    // folder and is later overwritten with a FILE path), which is how the first live run silently
    // landed in %TEMP%. Asking MM4 directly removes the dependency rather than compensating for it.
    private string ResolveReportDir(IMMApp app, out bool inWorkspace)
    {
        inWorkspace = true;
        try
        {
            string wp = app.WorkspaceOutputPath;
            if (wp != null && wp.Trim().Length > 0)
            {
                wp = wp.Trim();
                if (!Directory.Exists(wp)) { try { Directory.CreateDirectory(wp); } catch (Exception) { } }
                if (Directory.Exists(wp)) return wp;
            }
        }
        catch (Exception) { }

        // Secondary: whatever ingestion published, accepting EITHER meaning (folder, or a file in the
        // folder we want). Still inside the workspace, so still production-valid.
        string raw = Get(app, V_REPORTDIR).Trim();
        if (raw.Length > 0)
        {
            if (Directory.Exists(raw)) return raw;
            try
            {
                string parent = Path.GetDirectoryName(raw);
                if (parent != null && parent.Length > 0 && Directory.Exists(parent)) return parent;
            }
            catch (Exception) { }
        }

        // Last resort. The report is still written — losing the record entirely would be worse — but
        // it is NOT a production location, and both the log and the report itself say so. It must
        // never be possible to end up with a temp-folder record that looks like a filed one.
        inWorkspace = false;
        try { app.OutputMsg("[QuantNorm barcode " + SCRIPT_VERSION + "] ⚠ THE WORKSPACE OUTPUT FOLDER "
            + "COULD NOT BE RESOLVED. The report has been written to the temp folder instead, which is "
            + "NOT a production location - temp is swept and does not travel with the workspace. "
            + "WorkspaceOutputPath failed and " + V_REPORTDIR + " held \"" + raw + "\".", true); }
        catch (Exception) { }
        return Path.GetTempPath();
    }

    // VIRTUAL for the same reason AskOperator is: the offline harness runs the failure paths dozens of
    // times, and without a seam here every one of them would launch a browser window. A test-only
    // branch inside the production path would mean the tests exercise a route the instrument never
    // takes, so the seam goes here instead.
    public virtual void OpenReport(string path)
    { try { Process.Start(new ProcessStartInfo(path) { UseShellExecute = true }); } catch (Exception) { } }

    private string BuildShell(string runId, string firstBlock)
    {
        var h = new StringBuilder();
        h.Append("<!DOCTYPE html><html><head><meta charset='utf-8'>");
        h.Append("<title>QuantNorm barcode validation - ").Append(E(runId)).Append("</title><style>");
        h.Append("body{font-family:Segoe UI,Arial,sans-serif;margin:24px;color:#1a1a1a;background:#fff}");
        h.Append("h1{font-size:20px;margin:0 0 4px}h2{font-size:15px;margin:22px 0 6px;border-bottom:1px solid #ddd;padding-bottom:3px}");
        h.Append("h3{font-size:13px;margin:14px 0 4px;color:#444}");
        h.Append("table{border-collapse:collapse;margin:6px 0 12px;font-size:12px}");
        h.Append("th,td{border:1px solid #ccc;padding:3px 7px;text-align:left;vertical-align:top}");
        h.Append("th{background:#f2f2f2;font-weight:600}");
        h.Append(".mono{font-family:Consolas,monospace}");
        h.Append(".att{border:2px solid #888;border-radius:5px;padding:12px 16px;margin:18px 0;background:#fbfbfb}");
        h.Append(".pass{border-color:#2e7d32}.fail{border-color:#c62828}");
        h.Append(".v-pass{color:#2e7d32;font-weight:700}.v-fail{color:#c62828;font-weight:700}");
        h.Append(".warn{background:#fff8e1;border:1px solid #f0c36d;padding:8px 12px;margin:8px 0;border-radius:4px}");
        h.Append(".sub{color:#666;font-size:12px}.empty{color:#999;font-style:italic}");
        h.Append("@media print{body{margin:8mm}.att{break-inside:avoid}}");
        h.Append("</style></head><body>\n");
        h.Append("<h1>Barcode validation - run ").Append(E(runId)).Append("</h1>\n");
        h.Append("<div class='sub'>QuantNorm_BarcodeValidation ").Append(SCRIPT_VERSION)
         .Append(" &middot; DEV / TESTING RECORD &middot; attempts accumulate below, newest last</div>\n");
        h.Append(firstBlock);
        h.Append(ATTEMPT_SENTINEL).Append("\n</body></html>");
        return h.ToString();
    }

    private string BuildAttemptBlock(IMMApp app)
    {
        bool ok = problems.Count == 0 && checksReached;
        var h = new StringBuilder();
        h.Append("<div class='att ").Append(ok ? "pass" : "fail").Append("'>\n");
        h.Append("<h2>Attempt ").Append(attempt).Append(" of ").Append(MAX_ATTEMPTS)
         .Append(" &mdash; <span class='").Append(ok ? "v-pass'>PASSED" : "v-fail'>FAILED").Append("</span></h2>\n");

        // ---- run context ----
        h.Append("<table><tr><th>Written</th><td class='mono'>").Append(E(Now())).Append("</td></tr>");
        h.Append("<tr><th>Run ID</th><td class='mono'>").Append(E(rpRunId)).Append("</td></tr>");
        h.Append("<tr><th>Script</th><td class='mono'>QuantNorm_BarcodeValidation ").Append(SCRIPT_VERSION).Append("</td></tr>");
        h.Append("<tr><th>Worklist</th><td class='mono'>").Append(E(Get(app, V_WLFILE))).Append("</td></tr>");
        h.Append("<tr><th>Scale</th><td>").Append(rpPlates).Append(" source plate(s), ").Append(rpRows).Append(" sample row(s)</td></tr>");

        // RUN MODE — READ FROM MM4, not declared and not inferred.
        // v0.9.1 and earlier printed "MM4 exposes no test-mode indicator, so this cannot be detected
        // from inside the run". That was FALSE. IMMApp.IsExecuteMode is a documented property of the
        // very interface this script is handed: true = Hardware Execute, false = Testing mode
        // (knowledge-base/references/mm4-script-api-reference.md:92). The run log genuinely cannot
        // distinguish the two — a test-mode log has the same shape as a live one — which is what the
        // old sentence was really about, and it stated it about the wrong surface.
        bool execMode;
        string modeNote;
        try
        {
            execMode = app.IsExecuteMode;
            modeNote = execMode
                ? "<b>Hardware Execute mode</b> &mdash; read from <span class='mono'>IMMApp.IsExecuteMode</span>. "
                + "Commands in this run were dispatched to real hardware."
                : "<b>Test mode (simulation)</b> &mdash; read from <span class='mono'>IMMApp.IsExecuteMode</span>. "
                + "Barcode values in this run were supplied by the operator through MM4's <i>Simulate Read "
                + "Barcodes From Stack</i> prompt; the SR-710 did not read a label. Nothing here is evidence "
                + "about the scanner, read heights, or the plate read face.";
        }
        catch (Exception ex)
        {
            execMode = false;
            modeNote = "<b class='v-fail'>COULD NOT BE READ</b> &mdash; <span class='mono'>IMMApp.IsExecuteMode</span> "
                     + "threw: " + E(ex.Message) + ". Treat the run mode as unknown rather than assuming either.";
        }
        h.Append("<tr><th>Run mode</th><td>").Append(modeNote).Append("</td></tr>");

        // INSTRUMENT CONNECTION — still a DECLARATION, and deliberately kept separate from run mode.
        // These are two different facts. Run mode is script-readable (above); whether a Lynx is
        // physically connected is not exposed anywhere on IMMApp's property surface (all 11 read,
        // Cardinal S19), so it can only come from the operator.
        string tm = Get(app, V_TESTMODE).Trim();
        h.Append("<tr><th>Instrument connection</th><td>");
        if (tm.Length == 0)
            h.Append("<span class='empty'>NOT DECLARED</span> &mdash; whether a Lynx is physically connected is "
                   + "<i>not</i> exposed to a script, so unlike the run mode above it cannot be read and must be "
                   + "declared in <span class='mono'>" + V_TESTMODE + "</span>. Absent that, nothing here may be "
                   + "read as evidence about the instrument.");
        else h.Append(E(tm));
        h.Append("</td></tr>");

        // A record has to say whether it is filed where records belong. Production reports live in the
        // workspace so they travel with it and are not swept; one written elsewhere must announce that
        // rather than look like a filed record.
        h.Append("<tr><th>Report location</th><td>");
        if (reportInWorkspace) h.Append("inside the workspace output folder &mdash; production location");
        else h.Append("<b class='v-fail'>OUTSIDE THE WORKSPACE</b> &mdash; written to the temp folder because the "
                    + "workspace output folder could not be resolved. Temp is swept and does not travel with the "
                    + "workspace, so <b>this copy is not a production record</b>. Re-run once the workspace path "
                    + "resolves, or file this copy manually before it is lost.");
        h.Append("</td></tr></table>\n");

        if (!checksReached)
        {
            h.Append("<div class='warn'><b>The checks were never reached.</b> This attempt failed before any "
                   + "comparison was possible, so the sections below have nothing to report. The reason is in "
                   + "the verdict message.</div>\n");
        }

        // ---- verdict + resolution ----
        h.Append("<h3>Verdict</h3><table><tr><th>BarcodeCheck_01</th><td class='mono'>")
         .Append(E(Get(app, V_CHECK))).Append("</td></tr>");
        h.Append("<tr><th>AbortMethod_01</th><td class='mono'>").Append(E(Get(app, V_ABORT))).Append("</td></tr>");
        string res = Get(app, V_RESOLUTION).Trim();
        h.Append("<tr><th>Operator resolution</th><td class='mono'>")
         .Append(res.Length > 0 ? E(res) : "<span class='empty'>none - operator was not asked</span>").Append("</td></tr>");
        h.Append("<tr><th>Message shown</th><td>").Append(E(Get(app, V_MESSAGE)).Replace("\n", "<br>")).Append("</td></tr></table>\n");

        // ---- what was asked of each group ----
        h.Append("<h3>How each plate group was handled</h3><table>");
        h.Append("<tr><th>Group</th><th>Setting</th><th>What that means</th></tr>");
        h.Append("<tr><td>Source</td><td class='mono'>(always scanned)</td><td>Validated against the worklist by set equality; the scan defines which deck row each plate set occupies.</td></tr>");
        h.Append("<tr><td>Quantification (SpectraMax)</td><td class='mono'>").Append(rpQMode.Length > 0 ? E(rpQMode) : "(empty)")
         .Append("</td><td>").Append(E(ModeSentence(rpQMode))).Append("</td></tr>");
        h.Append("<tr><td>Output</td><td class='mono'>").Append(rpOMode.Length > 0 ? E(rpOMode) : "(empty)")
         .Append("</td><td>").Append(E(ModeSentence(rpOMode))).Append("</td></tr></table>\n");

        // ---- what the scan produced ----
        h.Append("<h3>What the scan produced</h3>\n");
        h.Append(ScanTable("Source", rpLocSrc, rpScanSrc, rpRbSrc));
        h.Append(ScanTable("Quantification (SpectraMax)", rpLocQ, rpScanQ, rpRbQ));
        h.Append(ScanTable("Output", rpLocO, rpScanO, rpRbO));

        // ---- MM4's own record + the cross-check ----
        h.Append(WorktableSection(app));

        // ---- problems ----
        if (problems.Count > 0)
        {
            h.Append("<h3>Problems found (").Append(problems.Count).Append(")</h3><table>");
            h.Append("<tr><th>#</th><th>What</th><th>Where</th><th>Detail</th><th>Fix</th></tr>");
            int k = 0;
            foreach (Problem p in problems)
            {
                k++;
                h.Append("<tr><td>").Append(k).Append("</td><td>").Append(E(p.What))
                 .Append("</td><td class='mono'>").Append(E(p.Where))
                 .Append("</td><td>").Append(E(p.Detail))
                 .Append("</td><td>").Append(E(p.Fix)).Append("</td></tr>");
            }
            h.Append("</table>\n");
        }

        // ---- the live variable dump ----
        h.Append(VariableDump(app));

        h.Append("</div>\n");
        return h.ToString();
    }

    private string ScanTable(string label, List<string> locs, List<string> codes, List<string> readby)
    {
        var h = new StringBuilder();
        h.Append("<b>").Append(E(label)).Append("</b>");
        if (codes.Count == 0 && locs.Count == 0)
        { h.Append(" <span class='empty'>&mdash; not scanned</span><br>\n"); return h.ToString(); }
        h.Append("<table><tr><th>Scan position</th><th>Deck location</th><th>Barcode</th><th>Read by</th></tr>");
        int n = Math.Max(codes.Count, locs.Count);
        for (int i = 0; i < n; i++)
        {
            h.Append("<tr><td>").Append(i + 1).Append("</td><td class='mono'>")
             .Append(i < locs.Count && locs[i].Length > 0 ? E(locs[i]) : "<span class='empty'>-</span>")
             .Append("</td><td class='mono'>")
             .Append(i < codes.Count && codes[i].Length > 0 ? E(codes[i]) : "<span class='empty'>(nothing came back)</span>")
             .Append("</td><td class='mono'>")
             .Append(i < readby.Count && readby[i].Length > 0 ? E(readby[i]) : "<span class='empty'>-</span>")
             .Append("</td></tr>");
        }
        h.Append("</table>\n");
        return h.ToString();
    }

    // MM4's own post-scan deck record, and the cross-check against it. This is the only part of this
    // report that is INDEPENDENT of the script: MM4 wrote the worktable, so agreement is evidence
    // rather than self-confirmation. Disagreement means the script's view of the deck is wrong, which
    // is precisely the S17 "wrong list target" defect class - invisible at runtime by any other means.
    private string WorktableSection(IMMApp app)
    {
        var h = new StringBuilder();
        h.Append("<h3>MM4's own deck record, after scanning &mdash; independent cross-check</h3>\n");
        string raw = Get(app, V_WORKTBL2);
        if (raw.Trim().Length == 0)
        {
            h.Append("<div class='warn'><b>").Append(E(V_WORKTBL2)).Append(" is empty.</b> The cross-check could "
                   + "not run. Either the Output Worktable step did not execute before this script, or the "
                   + "variable is not being written. This is not a barcode fault, but it means the deck mapping "
                   + "below rests on this script alone.</div>\n");
            return h.ToString();
        }
        h.Append("<table><tr><th>Deck location</th><th>Plate</th><th>Barcode MM4 recorded</th><th>Agrees with the scan?</th></tr>");
        // Left-anchored parse ONLY: fields 1/3/4 all sit BEFORE Labware, which carries unquoted commas
        // ("Eppendorf twin.tec PCR Plate 96, skirted, 150 uL" splits into three). Confirmed on live data.
        foreach (string row in raw.Split('|'))
        {
            string[] f = row.Split(',');
            if (f.Length < 10) continue;
            if (f[0].Trim().Equals("Location", StringComparison.OrdinalIgnoreCase)) continue;
            string loc = f[0].Trim(), plate = f[2].Trim(), bc = f[3].Trim();
            string verdict;
            if (bc.Length == 0) verdict = "<span class='empty'>blank &mdash; not scanned</span>";
            else if (rpScanSrc.Contains(bc) || rpScanQ.Contains(bc) || rpScanO.Contains(bc))
                verdict = "<span class='v-pass'>yes</span>";
            else verdict = "<span class='v-fail'>NO &mdash; MM4 holds a barcode this script never saw</span>";
            h.Append("<tr><td class='mono'>").Append(E(loc)).Append("</td><td class='mono'>").Append(E(plate))
             .Append("</td><td class='mono'>").Append(bc.Length > 0 ? E(bc) : "&mdash;")
             .Append("</td><td>").Append(verdict).Append("</td></tr>");
        }
        h.Append("</table>\n");
        h.Append("<div class='sub'>A blank barcode against a plate that IS on the deck means that group's scan "
               + "was skipped &mdash; MM4 records what was actually read, so this evidences scan coverage as well "
               + "as scanned values.</div>\n");
        return h.ToString();
    }

    // Every variable this script read or wrote, with its live value. THIS IS THE POINT OF THE REPORT:
    // WorkspaceVariables.config lags a run, so a run's own variable state was previously unreadable
    // after the fact. app.GetVariableValue() reads it live, from inside the run, and writing it down
    // is what makes the run self-evidencing instead of dependent on a snapshot that trails it.
    private string VariableDump(IMMApp app)
    {
        string[] names = new string[] {
            // V_REPORTDIR is dumped because the report's OWN location is decided from it. When v0.8.0
            // first ran live it silently landed in %TEMP%, and the report could not explain why
            // because it did not record the value it had used. A record should account for its own
            // placement.
            V_WLFILE, V_RUNID, V_TESTMODE, V_REPORTDIR, V_QPERFORM, V_OPERFORM, V_ATTEMPT, V_RESOLUTION,
            V_CHECK, V_ABORT, V_MESSAGE,
            V_SRCLOC, V_QLOC, V_OLOC,
            V_SCAN_SRC, V_RB_SRC, V_SCAN_Q, V_RB_Q, V_SCAN_O, V_RB_O,
            R_SRCPLATE, R_SRCLOC, R_QPLATE, R_QLOC, R_OPLATE, R_OLOC, R_TIPBOX, L_QBC, L_OBC,
            // v0.9.3 — the plate-major lists the METHOD reads are dumped too. This script does not
            // write them, and that is exactly why they are worth showing: if a run ever goes wrong at
            // the plate level, the record has to say what the loops were actually reading.
            "User.SourcePlate_List_01", "User.QuantPlate_List_01", "User.OutputPlate_List_01",
            "User.TipBox_List_01",
            V_WORKTBL2
        };
        var h = new StringBuilder();
        h.Append("<h3>Variable state, read live at the end of this attempt</h3>\n");
        h.Append("<div class='sub'>Read with GetVariableValue from inside the run. "
               + "WorkspaceVariables.config on disk lags by one run and cannot evidence this.</div>\n");
        h.Append("<table><tr><th>Variable</th><th>Elements</th><th>Value</th></tr>");
        foreach (string nm in names)
        {
            string v = Get(app, nm);
            int elems = v.Length == 0 ? 0 : v.Split(',').Length;
            string shown = v.Length == 0 ? "<span class='empty'>(empty)</span>"
                         : E(v.Length > 400 ? v.Substring(0, 400) + " ...[" + v.Length + " chars]" : v);
            h.Append("<tr><td class='mono'>").Append(E(nm)).Append("</td><td>").Append(elems)
             .Append("</td><td class='mono'>").Append(shown).Append("</td></tr>");
        }
        h.Append("</table>\n");
        return h.ToString();
    }

    // Makes text safe for MM4's Show Message, which STRIPS "\n" from a MessageVariable rather than
    // rendering or even spacing it - so "…again.\n\nWhat was wrong" arrives as "…again.What was
    // wrong". Anything destined for that command must already read as one paragraph.
    // The one-line "What" of each problem, as a sentence the operator can act on. v0.9.0 gave only a
    // COUNT, which was an over-correction: v0.8.2 dumped the entire what/where/why/fix into a box that
    // strips newlines and fused it into a wall; v0.9.0 then said "1 problem was found" and left the
    // operator no idea WHICH. The headline is the part that changes what they do next; the where/why/
    // fix detail is in the report that has just opened.
    //
    // CAPPED at three, because this must stay one readable paragraph in a box that cannot wrap on
    // meaning. What is dropped is stated rather than silently truncated.
    private string Headlines()
    {
        if (problems.Count == 0) return "";
        int show = Math.Min(3, problems.Count);
        var sb = new StringBuilder();
        sb.Append(problems.Count == 1 ? "The problem: " : problems.Count + " problems, ");
        if (problems.Count > 1) sb.Append(show == problems.Count ? "namely: " : "the first " + show + ": ");
        for (int i = 0; i < show; i++)
        {
            if (i > 0) sb.Append("; ");
            sb.Append(problems[i].What.TrimEnd('.'));
        }
        sb.Append(".");
        if (problems.Count > show)
            sb.Append(" A further ").Append(problems.Count - show)
              .Append(problems.Count - show == 1 ? " problem is" : " problems are").Append(" in the report.");
        return sb.ToString();
    }

    // "A output plate" read badly in the operator message. The article follows the word rather than
    // being hard-coded, because the label is a variable ("source", "output", "quantification (SpectraMax)").
    private static string Art(string word)
    {
        string w = (word ?? "").TrimStart();
        if (w.Length == 0) return "A";
        char c = char.ToLowerInvariant(w[0]);
        return (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') ? "An" : "A";
    }

    private static string Flatten(string s)
    {
        if (s == null) return "";
        string t = s.Replace("\r\n", " ").Replace("\n", " ").Replace("\r", " ");
        while (t.IndexOf("   ", StringComparison.Ordinal) >= 0) t = t.Replace("   ", "  ");
        return t.Trim();
    }

    private static string Now()
    { return DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"); }

    private static string E(string s)
    {
        if (s == null) return "";
        return s.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");
    }

    // =====================================================================================
    //  SMALL HELPERS
    // =====================================================================================

    // The method builds its lists with a LEADING delimiter so a loop counter starting at 1 indexes the
    // first real value (KB d2-barcode-scanning-reference). That leaves ONE empty element at index 0.
    //
    // ⚠ ONLY THAT FIRST EMPTY IS DROPPED. Tody's ParseList discards EVERY empty element, and copying
    // that here was a real bug, caught by the test for a Lunatic scan that returned nothing:
    // ",LUN-001," means "position 1 read, POSITION 2 READ NOTHING". Dropping the trailing empty
    // collapsed the list to one item, and the script then reported "the wrong number of plates was
    // scanned" instead of "no barcode was captured at Loc_14". The run stopped either way, but the
    // operator was pointed at the wrong problem.
    // An empty element in the middle or at the end is MEANINGFUL - it is a position that produced no
    // barcode - so position must be preserved and the emptiness reported as itself.
    // (It matters less for reference workflow because that script compares SETS; here position is the point.)
    private static List<string> ParseList(string raw)
    {
        var outp = new List<string>();
        if (raw == null || raw.Length == 0) return outp;
        string[] parts = raw.Split(',');
        int start = (parts.Length > 0 && parts[0].Trim().Length == 0) ? 1 : 0;   // the phantom, and only it
        for (int i = start; i < parts.Length; i++) outp.Add(parts[i].Trim());
        return outp;
    }

    // At() is for MESSAGES ONLY — it substitutes readable prose when there is nothing to show.
    private static string At(List<string> l, int i)
    { return (i >= 0 && i < l.Count && l[i].Length > 0) ? l[i] : "an unrecorded position"; }

    // Val() is for DATA. v0.6.0 added it because v0.5.0 used At() for both, which meant a missing
    // element would have written the literal words "an unrecorded position" into a deck-location or
    // barcode list — and a transfer step would then have been told to drive to a location by that
    // name. The checks above stop that reaching here, but a value destined for the instrument and
    // for the customer's completed worklist must never be able to carry an error message as its content.
    private static string Val(List<string> l, int i)
    { return (i >= 0 && i < l.Count) ? (l[i] ?? "") : ""; }

    private static string ReadBy(List<string> rb, int i)
    { return (i >= 0 && i < rb.Count && rb[i].Length > 0) ? rb[i] : "unknown"; }

    // v0.9.3 — LEADING COMMA on everything this script publishes (Jim, D-S20-05), so a base-1 loop
    // counter indexes the first real element with no -1 adjustment anywhere. This is the write-side
    // partner of ParseList below, which strips exactly that one phantom on read.
    private static string Join2(List<string> l) { return "," + string.Join(",", l.ToArray()); }

    private static string Join(List<string> l)
    { return l.Count == 0 ? "(none)" : string.Join(", ", l.ToArray()); }

    private static string User(string v) { return v; }

    private static string Key(string s)
    { return (s ?? "").Trim().Replace("µ", "u").Replace("μ", "u").Replace(" ", "").ToLowerInvariant(); }

    private static string Cell(string[] row, int i) { return (i >= 0 && i < row.Length) ? row[i].Trim() : ""; }

    private static string Get(IMMApp app, string name)
    { try { string v = app.GetVariableValue(name); return v == null ? "" : v; } catch (Exception) { return ""; } }

    private static void Set(IMMApp app, string name, string value)
    { Qn.Write(app, name, value); }

    // One execution set per PHYSICAL quantification slot. Source and output handles may differ.
    // Scan-location lists remain in physical order. All pipetting lists and masks are rebuilt together.
    private void RebuildExecutionPlan(IMMApp app, List<string> source, List<string> quant,
        List<string> output, List<string> tips, int plateCount)
    {
        var wells = Qn.List(Get(app, "User.SourceWell_List_01"), ',');
        Qn.Require(wells.Count == source.Count && quant.Count == source.Count && output.Count == source.Count,
            "Barcode reconciliation produced inconsistent row counts.");
        var ps = new List<string>(); var pq = new List<string>(); var po = new List<string>(); var pt = new List<string>();
        var va = new List<string>(); var vd = new List<string>();
        var qda = new List<string>(); var qdd = new List<string>(); var qmx = new List<string>();
        // v0.9.6 — the quant volumes come from ingestion's published variables, NOT literals. v0.9.5
        // hard-coded "5;5;0" / "3" here, duplicating ingestion's constants; the SpectraMax variant makes
        // them run-configurable, and two copies of one number is exactly how they drift apart.
        string qs = Get(app, "User.QuantSampleVolume_01"), qdv = Get(app, "User.QuantDiluentVolume_01");
        double qsN, qdN;
        Qn.Require(double.TryParse(qs, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out qsN) && qsN >= 2
            && double.TryParse(qdv, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out qdN) && qdN >= 2,
            "Quant sample/diluent volumes were not published by worklist ingestion (v0.8.9+). Re-run ingestion.");
        const string QUANT_MIX = "20";
        var usedSources = new HashSet<string>(); var usedOutputs = new HashSet<string>();
        for (int slot = 1; slot <= plateCount; slot++)
        {
            string q = HDL_LUNATIC + slot.ToString("00");
            string src = "", dst = "", tip = ""; int count = 0;
            var a = new string[97]; var d = new string[97]; a[0] = d[0] = "VI;12;8";
            var xa = new string[97]; var xd = new string[97]; var mx = new string[97]; xa[0] = xd[0] = mx[0] = "VI;12;8";
            for (int row = 0; row < quant.Count; row++)
            {
                if (quant[row] != q) continue;
                if (count == 0) { src = source[row]; dst = output[row]; tip = tips[row]; }
                Qn.Require(src == source[row] && dst == output[row] && tip == tips[row],
                    "Each source must map to exactly one quantification plate and one output plate. Split/pooled plate mappings are not supported.");
                int channel = Qn.Channel(wells[row]);
                Qn.Require(channel > 0 && a[channel] == null, "Duplicate or invalid channel after barcode reconciliation.");
                a[channel] = qs + ";5;0"; d[channel] = qs;
                xa[channel] = qdv + ";5;0"; xd[channel] = qdv; mx[channel] = QUANT_MIX; count++;
            }
            Qn.Require(count > 0 && usedSources.Add(src) && usedOutputs.Add(dst),
                "Plate assignments are not one-to-one. Check the designated quantification and output barcodes.");
            ps.Add(src); pq.Add(q); po.Add(dst); pt.Add(tip);
            va.Add(string.Join(",", a)); vd.Add(string.Join(",", d));
            qda.Add(string.Join(",", xa)); qdd.Add(string.Join(",", xd)); qmx.Add(string.Join(",", mx));
        }
        Set(app, "User.QuantDiluent_Aspirate_VI_List_01", "-" + string.Join("-", qda.ToArray()));
        Set(app, "User.QuantDiluent_Dispense_VI_List_01", "-" + string.Join("-", qdd.ToArray()));
        Set(app, "User.QuantMix_VI_List_01", "-" + string.Join("-", qmx.ToArray()));
        Set(app, "User.SourcePlate_List_01", Join2(ps)); Set(app, "User.QuantPlate_List_01", Join2(pq));
        Set(app, "User.OutputPlate_List_01", Join2(po)); Set(app, "User.TipBox_List_01", Join2(pt));
        Set(app, "User.Quant_Aspirate_VI_List_01", "-" + string.Join("-", va.ToArray()));
        Set(app, "User.Quant_Dispense_VI_List_01", "-" + string.Join("-", vd.ToArray()));
        app.OutputMsg("Barcode-reconciled execution order: sources " + Join(ps) + "; quant " + Join(pq) + "; output " + Join(po), false);
    }
    private void RecordBarcodeAttempt(IMMApp app, string outcome)
    {
        string path = Get(app, "User.BarcodeAuditFile_01");
        Qn.Require(path.Length > 0, "Barcode audit path was not initialized by ingestion.");
        File.AppendAllText(path, DateTime.Now.ToString("o") + " | validation attempt " + attempt + " | " + outcome
            + " | source=" + Get(app, V_SCAN_SRC) + " | quant=" + Get(app, V_SCAN_Q) + " | output=" + Get(app, V_SCAN_O)
            + " | read-by=" + Get(app, V_RB_SRC) + ";" + Get(app, V_RB_Q) + ";" + Get(app, V_RB_O) + Environment.NewLine);
        // This is a validation/decision timestamp, not an invented individual scanner timestamp.
    }


    // Shared, self-contained helpers. Kept in each script: no extra runtime DLL is required.
    private static class Qn
    {
        public static string Get(IMMApp app, string name)
        { try { return app.GetVariableValue(name) ?? ""; } catch (Exception) { return ""; } }
        public static void Write(IMMApp app, string name, string value)
        {
            app.SetVariable(name, value ?? "");
            if (!string.Equals(app.GetVariableValue(name) ?? "", value ?? "", StringComparison.Ordinal))
                throw new InvalidOperationException("MM4 variable did not retain its assigned value: " + name);
        }
        public static void Require(bool condition, string message)
        { if (!condition) throw new InvalidOperationException(message); }
        public static bool Finite(double value)
        { return !double.IsNaN(value) && !double.IsInfinity(value); }
        public static bool TryNumber(string text, out double value)
        {
            return double.TryParse((text ?? "").Trim(), System.Globalization.NumberStyles.Float,
                System.Globalization.CultureInfo.InvariantCulture, out value) && Finite(value);
        }
        public static string Number(double value)
        { return value.ToString("0.################", System.Globalization.CultureInfo.InvariantCulture); }
        public static string Well(string text)
        {
            string s = (text ?? "").Trim().ToUpperInvariant();
            int c;
            if (s.Length < 2 || s.Length > 3 || s[0] < 'A' || s[0] > 'H') return "";
            for (int i = 1; i < s.Length; i++) if (s[i] < '0' || s[i] > '9') return "";
            if (!int.TryParse(s.Substring(1), out c) || c < 1 || c > 12) return "";
            return s.Substring(0, 1) + c.ToString("00");
        }
        public static int Channel(string well)
        {
            string w = Well(well);
            return w.Length == 0 ? -1 : (w[0] - 'A') * 12 + int.Parse(w.Substring(1));
        }
        public static List<string> List(string raw, char separator)
        {
            var result = new List<string>();
            if (string.IsNullOrEmpty(raw)) return result;
            string[] parts = raw.Split(separator);
            int start = parts[0].Length == 0 ? 1 : 0;
            for (int i = start; i < parts.Length; i++) result.Add(parts[i]);
            return result;
        }
        public static string At(List<string> values, int index)
        { return index >= 0 && index < values.Count ? values[index] : ""; }
        public static void PlateValue(IMMApp app, string variable, int index, int count, string value, char separator)
        {
            Require(index >= 1 && index <= count && count <= 4, "Invalid plate index for " + variable);
            var prior = List(Get(app, variable), separator);
            Require(prior.Count <= count, "Too many plate entries in " + variable + ". Start from ingestion.");
            while (prior.Count < count) prior.Add("");
            prior[index - 1] = value ?? "";
            Write(app, variable, separator.ToString() + string.Join(separator.ToString(), prior.ToArray()));
        }
        public static void SafeToken(string value, string description)
        {
            Require(!string.IsNullOrEmpty(value) && value.IndexOfAny(new char[] { ',', '|', '&', '\r', '\n', '\t' }) < 0,
                description + " is empty or contains a reserved MM4 list delimiter.");
        }
        public static string HashBytes(byte[] data)
        {
            using (var sha = System.Security.Cryptography.SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(data)).Replace("-", "").ToLowerInvariant();
        }
        public static string HashFile(string path) { return HashBytes(File.ReadAllBytes(path)); }
        public static void CheckWorklist(IMMApp app)
        {
            string p = Get(app, "User.WorklistFile_01"), h = Get(app, "User.SourceWorklistHash_01");
            Require(h.Length > 0 && File.Exists(p) && HashFile(p) == h,
                "The worklist is missing or changed after ingestion. Start a new run; current results must not be paired with changed input.");
        }
        public static List<string> ReadRecords(string path) { return Records(File.ReadAllText(path)); }
        public static List<string> Records(string text)
        {
            var result = new List<string>();
            var b = new StringBuilder();
            bool quoted = false;
            string s = (text ?? "").TrimStart('\uFEFF');
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (c == '"')
                {
                    b.Append(c);
                    if (quoted && i + 1 < s.Length && s[i + 1] == '"') { b.Append(s[++i]); continue; }
                    // Comments and header preambles are plain text, not CSV records.
                    if (!b.ToString().TrimStart().StartsWith("#")) quoted = !quoted;
                }
                else if ((c == '\r' || c == '\n') && !quoted)
                {
                    result.Add(b.ToString()); b.Length = 0;
                    if (c == '\r' && i + 1 < s.Length && s[i + 1] == '\n') i++;
                }
                else b.Append(c);
            }
            Require(!quoted, "Unterminated quoted field in the input file.");
            if (b.Length > 0) result.Add(b.ToString());
            return result;
        }
        public static string[] Fields(string record, char separator)
        {
            var result = new List<string>(); var cell = new StringBuilder();
            bool quoted = false, closed = false;
            string s = record ?? "";
            // Preambles/comments are not CSV: callers retain them verbatim.
            if (s.TrimStart().StartsWith("#") || (s.IndexOf(separator) < 0 && s.IndexOf(':') > 0)) return new string[] { s };
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (quoted)
                {
                    if (c == '"')
                    {
                        if (i + 1 < s.Length && s[i + 1] == '"') { cell.Append('"'); i++; }
                        else { quoted = false; closed = true; }
                    }
                    else cell.Append(c);
                }
                else if (c == separator) { result.Add(cell.ToString()); cell.Length = 0; closed = false; }
                else if (c == '"')
                {
                    Require(!closed && cell.ToString().Trim().Length == 0, "Unexpected quote in a delimited field.");
                    cell.Length = 0; quoted = true;
                }
                else if (closed) Require(char.IsWhiteSpace(c), "Unexpected text following a quoted field.");
                else cell.Append(c);
            }
            Require(!quoted, "Unterminated quoted field."); result.Add(cell.ToString());
            return result.ToArray();
        }
    }

}
