using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Remoting.Proxies;
using MMScriptObjects;

// Offline harness for QuantNorm_ReaderNormVI v0.20.8 SpectraMax path. In-memory MM4 variable store.
class FakeApp : RealProxy
{
    public Dictionary<string, string> V = new Dictionary<string, string>();
    public string Out;
    public List<string> Log = new List<string>();
    public FakeApp(string outDir) : base(typeof(IMMApp)) { Out = outDir; }
    public override IMessage Invoke(IMessage msg)
    {
        var call = (IMethodCallMessage)msg; string n = call.MethodName; object ret = null;
        if (n == "GetVariableValue") { string v; ret = V.TryGetValue((string)call.Args[0], out v) ? v : ""; }
        else if (n == "SetVariable") V[(string)call.Args[0]] = Convert.ToString(call.Args[1], System.Globalization.CultureInfo.InvariantCulture);
        else if (n == "OutputMsg") Log.Add((string)call.Args[0]);
        else if (n == "get_WorkspaceOutputPath") ret = Out;
        else if (n == "get_IsExecuteMode") ret = false;
        else if (n == "get_IsStopSignal") ret = false;
        else if (n == "get_Username") ret = "harness";
        else if (n == "get_WorkspaceName") ret = "harness";
        else throw new NotImplementedException("FakeApp: " + n);
        return new ReturnMessage(ret, null, 0, call.LogicalCallContext, call);
    }
}

static class Program
{
    static int fails = 0;
    static void Check(bool ok, string what) { Console.WriteLine((ok ? "PASS " : "FAIL ") + what); if (!ok) fails++; }

    static string Smx(string[] wells, Func<string, double[]> od, bool withPath)
    {
        // SoftMax-like column export: ##BLOCKS preamble, tab-separated, ~End trailer
        var s = "##BLOCKS= 1\r\nPlate:\tPlate1\t1.3\tPlateFormat\tEndpoint\tAbsorbance\r\n\r\n";
        s += "Sample\tWells\tValues 230\tValues 260\tValues 280" + (withPath ? "\tPathlength" : "") + "\r\n";
        foreach (var w in wells)
        {
            var v = od(w);
            s += "S\t" + w + "\t" + string.Join("\t", v.Select(x => double.IsNaN(x) ? "Range?" : x.ToString("0.0000", System.Globalization.CultureInfo.InvariantCulture)))
                + (withPath ? "\t0.2900" : "") + "\r\n";
        }
        return s + "\r\n~End\r\n";
    }

    static void Main(string[] args)
    {
        string root = args[0]; string outDir = Path.Combine(root, "out"); Directory.CreateDirectory(outDir);
        var asm = typeof(MMScriptExecutor).Assembly;
        var qn = asm.GetType("MMScriptExecutor+Qn", true);
        string wl = Path.Combine(root, "wl.csv"); File.WriteAllText(wl, "SourcePlateBarcode,SourceWell\nSRC1,A1\n");
        string hash = (string)qn.GetMethod("HashFile", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic).Invoke(null, new object[] { wl });

        string[] sample = { "A1", "A2", "B1", "B2" };
        string[] all = new string[96]; for (int i = 0; i < 96; i++) all[i] = "" + (char)('A' + i / 12) + (i % 12 + 1);

        var fake = new FakeApp(outDir); var app = (IMMApp)fake.GetTransparentProxy(); var V = fake.V;
        V["User.RunID_01"] = "R1"; V["User.WorklistFile_01"] = wl; V["User.SourceWorklistHash_01"] = hash;
        V["User.TransferCount_01"] = "4"; V["User.ScanPlateCount_01"] = "1"; V["User.CurrentPlateIndex_01"] = "1";
        V["User.ReaderPreparedRun_01"] = "R1"; V["User.ReaderPreparedPlate_01"] = "1";
        V["User.ReaderPreparedUtc_01"] = DateTime.UtcNow.AddMinutes(-1).ToString("o");
        V["User.ReaderExpectedPlateID_01"] = "Lunatic_01";
        V["User.SourceWell_List_01"] = "A1,A2,B1,B2"; V["User.QuantWell_List_01"] = "A1,A2,B1,B2"; V["User.OutputWell_List_01"] = "A1,A2,B1,B2";
        V["User.Row_QuantPlate_List_01"] = "Lunatic_01,Lunatic_01,Lunatic_01,Lunatic_01";
        V["User.SourcePlateBarcode_List_01"] = "SRC1,SRC1,SRC1,SRC1"; V["User.QuantBarcode_List_01"] = "Q1,Q1,Q1,Q1";
        V["User.ExtinctionCoefficient_01"] = "0.025"; V["User.TargetConcentration_01"] = "50"; V["User.RequestedOutputVolume_01"] = "50";
        V["User.A260AcceptanceLogic_01"] = "Average"; V["User.OutputWellCapacity_01"] = "150"; V["User.TipWorkingCapacity_01"] = "200";
        V["User.ReportPath_01"] = outDir; V["User.ReaderModel_01"] = "SpectraMax"; V["User.QuantDilutionFactor_01"] = "10";
        V["User.ReaderLowSignalOD_01"] = "0.01"; V["User.ReaderPathlengthCm_01"] = "0.3";
        V["User.PurityThreshold_A260_A280_01"] = "1.7"; V["User.PurityThreshold_A260_A230_01"] = "1.7";
        foreach (var l in new[] { "User.A260_1_List_01", "User.A260_2_List_01", "User.AcceptedA260_List_01", "User.A280_List_01", "User.A230_List_01",
            "User.CalculatedConcentration_List_01", "User.TransferVolume_List_01", "User.DiluentVolume_List_01", "User.PurityFlag_List_01",
            "User.TransferStatus_List_01", "User.RowCalculationTimestamp_List_01", "User.RowCalculationNote_List_01" }) V[l] = ",,,";
        V["User.RowDisposition_List_01"] = ",PENDING,PENDING,PENDING,PENDING";
        V["User.NormalizationPlateStatus_List_01"] = ","; V["User.NormalizationPlateRun_List_01"] = ",";
        V["User.ReaderPayloadHash_List_01"] = ","; V["User.ReaderDataSource_List_01"] = ",";
        foreach (var l in new[] { "User.Sample_Aspirate_VI_List_01", "User.Sample_Dispense_VI_List_01", "User.Diluent_Aspirate_VI_List_01", "User.Diluent_Dispense_VI_List_01" }) V[l] = "-";

        // ---- BLANK phase: plate background 0.05 at all wavelengths
        string blankF = Path.Combine(root, "blank.txt");
        File.WriteAllText(blankF, Smx(all, w => new[] { 0.06, 0.05, 0.045 }, false));
        V["User.SpectraMaxBlankFile_01"] = blankF; V["User.ReaderPhase_01"] = "BLANK"; V["User.ReaderPreparedRun_01"] = "R1"; V["User.ReaderPreparedPlate_01"] = "1";
        new Quiet().Execute(app);
        Check(V.ContainsKey("User.BlankPlate1_01") && V["User.BlankPlate1_01"].StartsWith("RUN=R1;A01=0.06|0.05|0.045"), "blank stored for plate 1: " + (V.ContainsKey("User.BlankPlate1_01") ? V["User.BlankPlate1_01"].Substring(0, 40) : "(none)"));
        Check(!V.ContainsKey("User.AbortMethod_01") || V["User.AbortMethod_01"] != "True", "blank phase did not abort: " + (V.ContainsKey("User.ScriptMessage_01") ? V["User.ScriptMessage_01"] : ""));

        // ---- SAMPLE phase. Path 0.3 cm, DF 10, e 0.025:
        // A1 raw260 0.05+0.30 -> A_eq = 0.30*10/0.3 = 10 -> 400 ng/uL -> transfer 50*50/400 = 6.25 uL
        // A2 raw260 0.05+0.0375 -> A_eq 1.25 -> 50 ng/uL -> transfer 50 (neat)
        // B1 raw260 0.05+0.005 -> below 0.01 OD -> low_signal
        // B2 duplicates disagree (0.20 vs 0.30 over blank) -> flagged
        var r1 = new Dictionary<string, double[]> {
            {"A1", new[]{0.06+0.15, 0.05+0.30, 0.045+0.15}}, {"A2", new[]{0.06+0.02, 0.05+0.0375, 0.045+0.02}},
            {"B1", new[]{0.06+0.003, 0.05+0.005, 0.045+0.003}}, {"B2", new[]{0.06+0.1, 0.05+0.20, 0.045+0.1}} };
        var r2 = new Dictionary<string, double[]>(r1); r2["B2"] = new[] { 0.06 + 0.1, 0.05 + 0.30, 0.045 + 0.1 };
        string f1 = Path.Combine(root, "read1.txt"), f2 = Path.Combine(root, "read2.txt");
        File.WriteAllText(f1, Smx(all, w => r1.ContainsKey(w) ? r1[w] : new[] { 0.06, 0.05, 0.045 }, false));
        File.WriteAllText(f2, Smx(all, w => r2.ContainsKey(w) ? r2[w] : new[] { 0.06, 0.05, 0.045 }, false));
        V["User.SpectraMaxRead1File_01"] = f1; V["User.SpectraMaxRead2File_01"] = f2; V["User.ReaderPhase_01"] = "SAMPLE"; V["User.ReaderPreparedRun_01"] = "R1"; V["User.ReaderPreparedPlate_01"] = "1";
        new Quiet().Execute(app);
        Console.WriteLine("  abort=" + (V.ContainsKey("User.AbortMethod_01") ? V["User.AbortMethod_01"] : "") + " msg=" + (V.ContainsKey("User.ScriptMessage_01") ? V["User.ScriptMessage_01"].Replace("\n", " ") : ""));
        Console.WriteLine("  A260_1  " + V["User.A260_1_List_01"]);
        Console.WriteLine("  conc    " + V["User.CalculatedConcentration_List_01"]);
        Console.WriteLine("  xfer    " + V["User.TransferVolume_List_01"]);
        Console.WriteLine("  dil     " + V["User.DiluentVolume_List_01"]);
        Console.WriteLine("  purity  " + V["User.PurityFlag_List_01"]);
        var conc = V["User.CalculatedConcentration_List_01"].Split(',').Skip(1).ToArray();
        var xfer = V["User.TransferVolume_List_01"].Split(',').Skip(1).ToArray();
        var pur = V["User.PurityFlag_List_01"].Split(',').Skip(1).ToArray();
        Check(Math.Abs(double.Parse(conc[0], System.Globalization.CultureInfo.InvariantCulture) - 400) < 1e-6, "A1 concentration = 400 ng/uL (blank-corrected, x10, /0.3 cm)");
        Check(xfer[0] == "6.25", "A1 transfer = 6.25 uL");
        Check(Math.Abs(double.Parse(conc[1], System.Globalization.CultureInfo.InvariantCulture) - 50) < 1e-6 && xfer[1] == "50", "A2 at target -> 50 uL neat");
        Check(pur[2] == "low_signal", "B1 flagged low_signal");
        Check(xfer[3] == "" || xfer[3] == "0", "B1 low_signal still normalized (flag, not reject); B2 (duplicate disagreement) left untouched: '" + xfer[3] + "'");
        Check(File.Exists(Path.Combine(outDir, "QuantNorm_spectramax_R1_plate1.txt")), "conversion trace file written");

        // ---- negative: stale blank from another run must stop the sample phase
        V["User.BlankPlate1_01"] = "RUN=OTHER;A01=0|0|0"; V["User.AbortMethod_01"] = ""; V["User.ReaderPhase_01"] = "SAMPLE"; V["User.ReaderPreparedRun_01"] = "R1"; V["User.ReaderPreparedPlate_01"] = "1";
        new Quiet().Execute(app);
        Check(V["User.AbortMethod_01"] == "True" && V["User.ScriptMessage_01"].Contains("No blank is stored"), "blank from another run is refused");

        // ---- negative: no pathlength anywhere must stop
        V["User.BlankPlate1_01"] = ""; V["User.AbortMethod_01"] = ""; V["User.ReaderPhase_01"] = "BLANK"; V["User.ReaderPreparedRun_01"] = "R1"; V["User.ReaderPreparedPlate_01"] = "1";
        new Quiet().Execute(app);
        V["User.ReaderPathlengthCm_01"] = ""; V["User.AbortMethod_01"] = ""; V["User.ReaderPhase_01"] = "SAMPLE"; V["User.ReaderPreparedRun_01"] = "R1"; V["User.ReaderPreparedPlate_01"] = "1";
        new Quiet().Execute(app);
        Check(V["User.AbortMethod_01"] == "True" && V["User.ScriptMessage_01"].Contains("No pathlength"), "missing pathlength is refused");

        // ---- per-well PathCheck column used when present (0.29 cm) and config absent
        File.WriteAllText(f1, Smx(all, w => r1.ContainsKey(w) ? r1[w] : new[] { 0.06, 0.05, 0.045 }, true));
        File.WriteAllText(f2, Smx(all, w => r2.ContainsKey(w) ? r2[w] : new[] { 0.06, 0.05, 0.045 }, true));
        V["User.AbortMethod_01"] = ""; V["User.ReaderPhase_01"] = "SAMPLE"; V["User.ReaderPreparedRun_01"] = "R1"; V["User.ReaderPreparedPlate_01"] = "1";
        new Quiet().Execute(app);
        conc = V["User.CalculatedConcentration_List_01"].Split(',').Skip(1).ToArray();
        Check(V["User.AbortMethod_01"] != "True" && Math.Abs(double.Parse(conc[0], System.Globalization.CultureInfo.InvariantCulture) - 0.30 * 10 / 0.29 / 0.025) < 1e-3, "per-well PathCheck pathlength used: A1 = " + conc[0]);

        // ---- plate-format export is refused with a readable message
        File.WriteAllText(blankF, "##BLOCKS= 1\r\nPlate:\tPlate1\r\n\tTemperature(C)\t1\t2\t3\r\n\t23.1\t0.05\t0.05\t0.05\r\n~End\r\n");
        V["User.AbortMethod_01"] = ""; V["User.ReaderPhase_01"] = "BLANK"; V["User.ReaderPreparedRun_01"] = "R1"; V["User.ReaderPreparedPlate_01"] = "1";
        new Quiet().Execute(app);
        Check(V["User.AbortMethod_01"] == "True" && V["User.ScriptMessage_01"].Contains("COLUMN (list) format"), "plate-format export refused with guidance");

        Console.WriteLine(fails == 0 ? "ALL PASS" : fails + " FAILURE(S)");
        Environment.Exit(fails);
    }
}
class Quiet : MMScriptExecutor
{
    public override void Alert(IMMApp app, string message) { Console.WriteLine("  [alert suppressed] " + message.Split('\n')[0]); }
    public override void OpenReport(string path) { }
}
