# Quant/Norm (in vivo RNA): SpectraMax and manual-barcode adaptation plan

**Base:** `Methods/Quant_Norm_Generic_v0_2_5.met` + spine scripts (Ingestion v0.8.8, BarcodeValidation v0.9.5, ReaderNormVI v0.20.7, RunGuard v0.40.4, OutputReport v0.30.6)
**Target:** the same workflow on a Lynx with a **Molecular Devices SpectraMax** (MM4 `MDSpectraMax` driver, SoftMax Pro automation) and a **96-well UV plate** in place of the Lunatic. There is **no SR710 deck barcode reader**.

## Build status (2026-11-18)

| Item | File | State |
|---|---|---|
| Method | `Methods/Quant_Norm_SpectraMax_v0_3_0.met` (291 steps; v0_2_5 untouched) | Built. Structure checked: balanced If/Loop/Section blocks, 0 SR710 commands, all 5 script references updated. **Reader commands are `SPECTRAMAX:` comment steps** to be filled in MM4 (see the setup guide §5). Not yet opened in MM4. |
| Ingestion | `Scripts/QuantNorm_WorklistIngestion_v0.8.9.cs` | Built; compiles with `/warnaserror` |
| Barcode validation | `Scripts/QuantNorm_BarcodeValidation_v0.9.6.cs` | Built; compiles |
| Reader/norm | `Scripts/QuantNorm_ReaderNormVI_v0.20.8.cs` | Built; compiles; **offline harness 11/11 pass** (`Tests/ReaderNormVI_SpectraMax_Harness.cs`) |
| RunGuard | `Scripts/QuantNorm_RunGuard_v0.40.5.cs` | Built; compiles |
| Output report | `Scripts/QuantNorm_OutputReport_v0.30.7.cs` | Built; compiles |
| Variables | `WorkspaceVariables.config` (+26; backup `.pre-spectramax.bak`) | Done |
| SpectraMax device / SR710 removal | Workspace hardware config | **Not changed.** v0_2_5 in this workspace still uses the SR710. Do this on the target Lynx (setup guide §4). |
| Deck handles | `Lunatic_01..04` | Kept. They need to point at the half-area UV labware. |
| Open decisions | `Scientist_Review_Questions.md` | ★ values are provisional |
| SoftMax setup | `SoftMax_Protocol_Setup_Guide.md` | Export layout and driver Open-File behaviour still **VERIFY** |

Not covered in this build:
- RunGuard response checks for the **mix** aspirate/dispense (they have no VO binding).
- Final-report verification of the quant-diluent responses. These are recorded per plate by `RECORD_QDIL` but aren't re-checked in the output report.
- Normalization-transfer tip reuse is unchanged (Q16).

## Decisions taken

| # | Decision | Choice |
|---|---|---|
| D1 | Quant plate scheme | **5 µL sample + 45 µL diluent (1:10)** in a UV-transparent **half-area** 96-well plate |
| D2 | Blanking | **Per-well pre-read**: read each quant plate after the diluent fill and before sample addition, then subtract per well |
| D3 | Barcodes | Operator **types source barcodes only**. Quant and output plates get **generated tracking IDs** (the existing "not barcoded" mode) |
| D4 | Duplicate A260 (QUANT-004) | **Two identical read sections** in the SoftMax `.spr` protocol (`Read_1`, `Read_2`) |

## 1. Configuration and deck

1. **Add the SpectraMax device to the GSK Demo workspace.** Copy `SpectraMaxTest/Configuration/SpectraMax.config` into `GSK Demo/Configuration`. Set `<Simulation>False</Simulation>` on the real system and add the device to `InitializeOrder.xml`.
2. **Remove the SR710 / `BarCodeZAxis` from `InitializeOrder.xml`** if that hardware isn't present, so initialization doesn't fault on a missing axis.
3. **Worktable:**
   - `Loc_28` (Lunatic) becomes the SpectraMax drawer teach position.
   - `Loc_29` (Lunatic turntable staging) is probably no longer needed. Use a direct gripper put/get unless the drawer orientation requires a regrip.
   - Redefine the quant labware as the half-area UV plate. Candidates are Corning 3679 and Greiner UV-Star half-area; pick one and get Lilly's RNA team to approve it under CAPACITY-007.
4. **Handle names:** `Lunatic_01..04` is hard-coded as `HDL_LUNATIC` in Ingestion, BarcodeValidation and ReaderNormVI. Recommendation: rename it to `Quant_` in the same release, which is a one-constant change per script plus the worktable. If the rename is deferred, the scripts work unchanged with the old handles.

## 2. SoftMax Pro protocol (`QuantNorm_RNA.spr`)

- Plate type: the chosen half-area UV plate. Read type: absorbance endpoint at **230, 260 and 280 nm**.
- Sections:
  - `Blank`: read after the diluent fill.
  - `Read_1` and `Read_2`: read after the stamp and mix.
  - All three sections use identical read settings.
- **Export raw OD**, without SoftMax plate-blank or PathCheck normalization, in **column/list format** with one row per well and a `Well` column. The script does the blanking and the pathlength math, so every number in the completed worklist can be traced.
  - Optional: if PathCheck is enabled, also export its per-well pathlength column. The script will use it when present and fall back to the configured constant otherwise.
- The driver supports what the method needs: `Open File` (.spr), `Drawer Control`, `Select Section`, `Start Read`, `Export Section As`, `Get Drawer Status` and `Query Values`. **Verify the exact export layout on the instrument before finalizing the header aliases** (§4.3).

## 3. New method sequence (`Quant_Norm_SpectraMax_v0_3_0.met`, a copy; v0_2_5 stays untouched)

| Block | Change vs v0_2_5 |
|---|---|
| **Ingest worklist** | Unchanged. Ingestion must leave `User.QuantBarcode_Perform_01` and `User.OutputBarcode_Perform_01` **empty** (the "not barcoded" mode), which generates tracking IDs for Appendix B fields 9 and 11. |
| **Enter barcodes** (was Read Barcodes) | Delete `Move To Location(SR710)` and the `Read Barcodes(SR710)` / `If Lynx.SR710.Barcodes IsEmpty` / `Else` branch. Each source-loop pass becomes:<br>(1) String Builder: *"Type the barcode of SOURCE plate #k of #N at deck position #User.SourceLoc_01#"*<br>(2) User Input<br>(3) **If empty → re-prompt**<br>(4) `Barcode_Read_By_01 = Manual`<br>(5) append to the list<br>(6) RunGuard `SCAN_SOURCE` (as now).<br>The quant and output scan sections stay in place but are gated off by the empty Perform variables. Rename the label "Rescan Barcodes" to "Re-enter Barcodes". |
| **Barcode validation** | Unchanged wiring. `RESCAN` now returns the operator to re-entry. |
| **Quant: diluent fill** *(new)* | Load `Diluent_Tips_01`. For each plate: aspirate the quant-diluent VI (45 µL + 5 µL gap) from the reservoir and dispense into `Quant_k`. Keep the tips; the same water-only tips are reused later for the output-plate diluent. New guard stages `PREPARE_QDIL` / `CHECK_QDIL`. |
| **Quant: blank read** *(new)* | For each plate:<br>gripper `Quant_k` → drawer → close → `Select Section Blank` → `Start Read` → `Export Section As` (path `…/Output/QuantNorm_<RunID>_P<k>_blank.txt`) → open → gripper back.<br>Then RunGuard `PREPARE_BLANK` and ReaderNormVI in **BLANK phase**, which stores the per-well blank for plate k. |
| **Quant: stamp** | Same loop as now, with new volumes: aspirate **5 µL** (+5 µL gap), dispense **5 µL into a wet well, then mix** (e.g. 3 × 20 µL). Wells now hold liquid, so the "quant cannot over-dispense" rule no longer applies and a blowout/over-stroke is allowed. |
| **Quant: sample read** | Replaces the Lunatic placeholder, `Loc_29` turntable moves and comments.<br>For each plate: gripper → drawer → `Select Section Read_1` → `Start Read` → `Select Section Read_2` → `Start Read` → export both sections → gripper back.<br>RunGuard `PREPARE_READER` (now also checks that plate k's blank exists) → ReaderNormVI (**SAMPLE phase**). |
| **Norm: diluent / sample transfer** | Logic unchanged. **Tip policy needs a decision**: v0_2_5 reuses the quant-stamp tips for the normalization transfer. That was harmless with a dry Lunatic stamp, but the tips now touch a wet, mixed quant well, and reusing them carries quant-plate liquid back into the source well. Recommendation: fresh sample tips for the transfer, which adds 1 tip box per plate (CAPACITY-002/003). |
| **Output report** | Wording and new header fields only (§4.5). |

## 4. Script changes (new files by copy, each within its own version band)

### 4.1 Ingestion v0.8.9
- Replace `STAMP_ASPIRATE_UL = 5 / STAMP_DISPENSE_UL = 3` with run-configurable values: `QuantSampleVolume` (default 5), `QuantDiluentVolume` (default 45) and the derived `QuantDilutionFactor = (5+45)/5 = 10`.
- Read them from new run-metadata header keys when present, otherwise use the defaults, and say so in the report. Also read `ReaderPathlengthCm` (the configured effective pathlength for 50 µL in the chosen plate, calibrated at validation), `ReaderLowSignalOD` (default 0.01) and `ReaderModel` (`SpectraMax`).
- Emit the new `User.QuantDiluent_Aspirate_VI_List_01` / `_Dispense_VI_List_01`, masked to occupied wells like the stamp VIs.
- Force `QuantBarcode_Perform_01` and `OutputBarcode_Perform_01` to empty for this method (D3).

### 4.2 BarcodeValidation v0.9.6
- `RebuildExecutionPlan` duplicates the stamp volumes (`a = "5;5;0"`, `d = "3"`). It must read the same variables as Ingestion, not hard-coded literals, and it must rebuild the quant-diluent VI lists too.
- Operator messages: "Re-scan the position…" becomes "Re-enter the barcode…". "Quantification (Lunatic)" becomes "Quantification (SpectraMax)".

### 4.3 ReaderNormVI v0.20.8 (the core change)
- **Phase variable** `User.ReaderPhase_01 = BLANK | SAMPLE`.
  - BLANK parses the blank export and stores per-well `A230/A260/A280` blanks in `User.Blank_List_P<k>_01`. It computes nothing else.
- **SAMPLE** parses the `Read_1` and `Read_2` exports and converts each reading to the **equivalent neat 1 cm absorbance**:

  `A_eq = (A_raw − A_blank) × DF / L`, where DF = 10 and L is the per-well PathCheck value if exported, else `ReaderPathlengthCm`.

  This puts `A260_1`, `A260_2`, `A280` and `A230` in the same units the Lunatic reported. So **everything downstream is untouched**: duplicate-agreement logic, `CalculatedConcentration = Accepted_A260 / ε`, purity ratios (DF and L cancel in the ratio, and blank correction is what matters), and the NORM volumes. Raw, blank, DF and L per well go into the per-plate calculation report for traceability.
- **`low_signal`** (already in the PurityFlag enum): set it when the blank-corrected raw A260 is below `ReaderLowSignalOD`. It flags, it does not reject (GEN-007).
- A negative blank-corrected A260 is treated as "no result": the well is flagged and left untouched, the same disposition as `-` today.
- Header aliases: add the SoftMax column names (e.g. `Well`; `260`, `A260`, `OD260`; `280`; `230`; `Pathlength`). **These must be confirmed against a real export**; the parser already stops with the column list when a column is missing.
- Plate ID check: the SoftMax export has no plate barcode, so skip the "Plate ID" match when the reader is SpectraMax. The per-plate file name (`…_P<k>_…`) and the prepared-run timestamp check carry the identity instead.

### 4.4 RunGuard v0.40.5
- New stages: `PREPARE_QDIL` / `CHECK_QDIL_ASP` / `CHECK_QDIL_DISP` / `RECORD_QDIL` and `PREPARE_BLANK`.
- `PREPARE_READER` additionally requires the blank for the current plate, and clears the reader payload variables for both sections.

### 4.5 OutputReport v0.30.7
- Run-metadata header additions: `ReaderModel`, `QuantPlateType`, `QuantSampleVolume`, `QuantDiluentVolume`, `QuantDilutionFactor`, `ReaderPathlengthCm`, `BlankMethod = PerWellPreRead` and `BarcodeEntry = Manual(source); Generated(quant, output)`.
- Per-row schema is **unchanged** (29 fields).

## 5. Deviations from Lilly MRS v0.1 to raise

| Spec ref | MRS says | This adaptation |
|---|---|---|
| §3.1, §8.2 | Lunatic is the quantification instrument; alternative readers are out of scope | SpectraMax with a 96-well half-area UV plate |
| QUANT-002, App. A | 2 µL stamp read neat | 5 µL stamp diluted 1:10 into 45 µL, then mixed |
| CAPACITY-007 | Lunatic plate 701-2019 | Half-area UV plate (P/N TBD; RNA-team approval needed) |
| QUANT-005 | Concentration from Accepted_A260 / ε | Same formula, with A260 first blank-corrected (per-well pre-read), dilution-corrected and pathlength-normalized to 1 cm |
| VERIFY-001, §3.4 0c/0e, GEN-005 | Automated VPP-arm deck scan of every plate | Operator types source barcodes (reconciled against the worklist as before). Quant/output plates get generated tracking IDs in App. B fields 9/11 |
| Step 1 / risk table | ≥25 µL input covers a 2 µL stamp plus the transfer | Stamp now consumes 5 µL plus dead volume. Max usable transfer drops by ~3 µL; confirm against RequestedOutputVolume (TBD-013) |
| App. B §B.2.1 | Header field list | New header keys (§4.5). Per-row schema unchanged |
| QUANT-TBD-005 | Lunatic chip carry-over | N/A. New risk: half-area UV plate background at 230 nm. The per-well blank mitigates it; A260/A230 should still be validated |

## 6. Open items (DD side)

1. Confirm the SoftMax export layout on the real instrument: column names, one file per section vs combined, decimal and separator format. Then lock the parser aliases.
2. Teach the drawer position (`Loc_28`) and confirm gripper orientation. Decide whether `Loc_29` can be retired.
3. Labware definition for the half-area UV plate: 50 µL liquid height, aspirate/dispense heights, mix parameters.
4. Calibrate `ReaderPathlengthCm` (or validate PathCheck) with a known RNA or dsDNA standard at 50 µL.
5. Decide the tip policy for the normalization transfer (fresh vs reused) and update the tip-capacity calculator (TBD-020).
6. Rename `Lunatic_` to `Quant_` handles now, or defer.
7. Remove the SR710 / BarCodeZ hardware from initialization.
