using System.Collections.Generic;
using System.IO;
using System.Text;

namespace MM4DeviceInstaller
{
	public sealed class PendingDll
	{
		public string DeviceName { get; set; }
		public string WorkspaceName { get; set; }
		public string SavedAt { get; set; }
		public string SourceFolder { get; set; }
		public string IntendedFolder { get; set; }
		public string Reason { get; set; }
	}

	public static class ItMessage
	{
		public static string Build(IList<PendingDll> pending, string programFolder)
		{
			StringBuilder text = new StringBuilder();
			text.AppendLine("Method Manager 4 needs one or more device files copied into a protected program folder.");
			text.AppendLine("The workspace files are already saved. Only the DLL copy is left.");
			text.AppendLine();
			text.AppendLine("Please close Method Manager 4, then copy each file below.");
			text.AppendLine("Administrator rights are required for the destination folder.");
			text.AppendLine();
			foreach (PendingDll item in pending)
			{
				string fileName = Path.GetFileName(item.SavedAt);
				string destinationFolder = item.IntendedFolder;
				if (string.IsNullOrWhiteSpace(destinationFolder))
				{
					destinationFolder = @"C:\Program Files (x86)\Dynamic Devices\MethodManager4\Libraries\Devices";
				}
				string destinationFile = Path.Combine(destinationFolder, fileName);
				text.AppendLine("Device: " + item.DeviceName);
				text.AppendLine("Workspace: " + item.WorkspaceName);
				text.AppendLine("The DLL is located at:");
				text.AppendLine("  " + item.SavedAt);
				text.AppendLine("Copy it to:");
				text.AppendLine("  " + destinationFile);
				if (!string.IsNullOrWhiteSpace(item.Reason))
				{
					text.AppendLine("The installer could not copy it because: " + item.Reason);
				}
				text.AppendLine();
			}
			if (!string.IsNullOrWhiteSpace(programFolder))
			{
				text.AppendLine("Method Manager program folder:");
				text.AppendLine("  " + programFolder);
			}
			else
			{
				text.AppendLine("The installer did not find MethodManager.DX.exe.");
				text.AppendLine("The DLL belongs in the Libraries\\Devices folder next to MethodManager.DX.exe.");
				text.AppendLine("The usual folder is:");
				text.AppendLine(@"  C:\Program Files (x86)\Dynamic Devices\MethodManager4\Libraries\Devices");
			}
			text.AppendLine();
			text.AppendLine("After the copy, start Method Manager and open each workspace named above.");
			text.AppendLine("The device then appears in the toolbox.");
			return text.ToString().TrimEnd();
		}
	}
}
