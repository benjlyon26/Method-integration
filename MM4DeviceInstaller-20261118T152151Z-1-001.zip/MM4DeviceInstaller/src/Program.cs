using System;
using System.IO;
using System.Windows.Forms;

namespace MM4DeviceInstaller
{
	internal static class Program
	{
		[STAThread]
		private static int Main(string[] args)
		{
			if (args != null && args.Length >= 2 && args[0] == "--copy-dlls")
			{
				return DllCopy.RunElevatedJob(args[1]);
			}
			if (args != null && args.Length >= 1 && args[0] == "--self-test")
			{
				string logPath = args.Length >= 2 ? args[1] : Path.Combine(Path.GetTempPath(), "mm4-selftest.txt");
				return SelfTest.Run(logPath);
			}
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new MainForm());
			return 0;
		}
	}
}
