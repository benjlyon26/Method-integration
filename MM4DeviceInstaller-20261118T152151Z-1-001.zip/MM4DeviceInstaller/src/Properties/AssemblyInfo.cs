using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("MM4 Device Installer")]
[assembly: AssemblyDescription("Install Method Manager 4 device plugins into a workspace.")]
[assembly: AssemblyCompany("Dynamic Devices")]
[assembly: AssemblyProduct("MM4 Device Installer")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: ComVisible(false)]
[assembly: Guid("8c1e4a60-5b27-4f93-9d14-6a0e2c7b91f4")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
