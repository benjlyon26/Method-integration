using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace MM4DeviceInstaller
{
	internal static class DeviceCompatibility
	{
		public static string Problem(DevicePackage package, string programFolder)
		{
			if (package == null || string.IsNullOrWhiteSpace(programFolder) || string.IsNullOrWhiteSpace(package.DllPath))
			{
				return null;
			}
			if (!File.Exists(package.DllPath))
			{
				return null;
			}
			if (!File.Exists(Path.Combine(programFolder, "MethodManager.Core.dll")))
			{
				return null;
			}
			AssemblyName[] references;
			try
			{
				Assembly assembly = Assembly.ReflectionOnlyLoadFrom(package.DllPath);
				references = assembly.GetReferencedAssemblies();
			}
			catch (Exception ex)
			{
				return package.DllFile + " could not be read (" + ex.Message + "). The workspace was left unchanged.";
			}
			List<string> mismatches = new List<string>();
			foreach (AssemblyName reference in references)
			{
				if (reference.Version == null || string.IsNullOrEmpty(reference.Name))
				{
					continue;
				}
				string installedPath = FindInstalled(programFolder, reference.Name);
				if (installedPath == null)
				{
					continue;
				}
				Version installed = AssemblyName.GetAssemblyName(installedPath).Version;
				if (installed != null && reference.Version > installed)
				{
					mismatches.Add(reference.Name + " " + reference.Version + " (this Method Manager has " + installed + ")");
				}
			}
			if (mismatches.Count == 0)
			{
				return null;
			}
			string focus = mismatches[0];
			foreach (string mismatch in mismatches)
			{
				if (mismatch.StartsWith("MethodManager.Core ", StringComparison.Ordinal))
				{
					focus = mismatch;
					break;
				}
			}
			return package.DllFile + " was built for " + focus + ". This Method Manager may not be able to load it.";
		}

		public static bool ConfirmProceed(IWin32Window owner, string compatibility)
		{
			using (Form dialog = new Form())
			{
				dialog.Text = "Different Method Manager version";
				dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
				dialog.StartPosition = FormStartPosition.CenterParent;
				dialog.MinimizeBox = false;
				dialog.MaximizeBox = false;
				dialog.ShowInTaskbar = false;
				dialog.AutoScaleMode = AutoScaleMode.Font;
				if (owner is Control ownerControl)
				{
					dialog.Font = ownerControl.Font;
				}
				Label body = new Label();
				body.AutoSize = true;
				body.MaximumSize = new Size(460, 0);
				body.Location = new Point(16, 16);
				body.Text = compatibility + Environment.NewLine + Environment.NewLine
					+ "Proceed installs this device anyway. Skip leaves the workspace unchanged.";
				Button proceed = new Button();
				proceed.Text = "Proceed";
				proceed.AutoSize = true;
				proceed.DialogResult = DialogResult.OK;
				Button skip = new Button();
				skip.Text = "Skip";
				skip.AutoSize = true;
				skip.DialogResult = DialogResult.Cancel;
				dialog.Controls.Add(body);
				dialog.Controls.Add(proceed);
				dialog.Controls.Add(skip);
				dialog.CancelButton = skip;
				int textWidth = body.GetPreferredSize(new Size(460, 0)).Width;
				int textHeight = body.GetPreferredSize(new Size(460, 0)).Height;
				int clientWidth = Math.Max(textWidth + 32, proceed.PreferredSize.Width + skip.PreferredSize.Width + 48);
				int buttonsTop = textHeight + 28;
				skip.Location = new Point(clientWidth - skip.PreferredSize.Width - 16, buttonsTop);
				proceed.Location = new Point(skip.Left - proceed.PreferredSize.Width - 8, buttonsTop);
				dialog.ClientSize = new Size(clientWidth, buttonsTop + proceed.PreferredSize.Height + 16);
				return dialog.ShowDialog(owner) == DialogResult.OK;
			}
		}

		private static string FindInstalled(string programFolder, string assemblyName)
		{
			string[] folders = new string[]
			{
				programFolder,
				Path.Combine(programFolder, "Libraries"),
				Path.Combine(programFolder, "Libraries", "Devices"),
				Path.Combine(programFolder, "Libraries", "Components"),
				Path.Combine(programFolder, "Libraries", "Required"),
				Path.Combine(programFolder, "Libraries", "3rdPartyLibraries")
			};
			foreach (string folder in folders)
			{
				string path = Path.Combine(folder, assemblyName + ".dll");
				if (File.Exists(path))
				{
					return path;
				}
			}
			return null;
		}
	}
}
