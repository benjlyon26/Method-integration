using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace MM4DeviceInstaller
{
	internal sealed class BreathingLog : Control
	{
		private sealed class Line
		{
			public string Text;
			public bool Attention;
		}

		private const TextFormatFlags Flags = TextFormatFlags.WordBreak | TextFormatFlags.Left | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix;
		private readonly List<Line> _lines = new List<Line>();
		private readonly VScrollBar _scroll = new VScrollBar();
		private readonly Timer _timer = new Timer();
		private readonly DateTime _started = DateTime.UtcNow;
		private readonly List<Rectangle> _lineRects = new List<Rectangle>();
		private readonly ContextMenuStrip _menu = new ContextMenuStrip();
		private bool _layoutBusy;
		private bool _stickToEnd = true;
		private bool _dragging;
		private int _selAnchor = -1;
		private int _selFocus = -1;
		internal bool UseForcedBreath;
		internal double ForcedBreath;

		public BreathingLog()
		{
			SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
			BackColor = Color.White;
			ForeColor = Color.FromArgb(32, 40, 48);
			Font = new Font("Consolas", 9f);
			_scroll.Dock = DockStyle.Right;
			_scroll.Visible = false;
			_scroll.Scroll += ScrollMoved;
			Controls.Add(_scroll);
			Cursor = Cursors.IBeam;
			_menu.Items.Add("Copy", null, delegate { CopySelection(); });
			_menu.Items.Add("Select all", null, delegate { SelectAll(); });
			ContextMenuStrip = _menu;
			_timer.Interval = 33;
			_timer.Tick += TimerTick;
			_timer.Start();
		}

		public void AppendLine(string text, bool attention)
		{
			_lines.Add(new Line { Text = text, Attention = attention });
			Reflow(true);
			Invalidate();
		}

		public void Clear()
		{
			_lines.Clear();
			_lineRects.Clear();
			_selAnchor = -1;
			_selFocus = -1;
			_dragging = false;
			_stickToEnd = true;
			Reflow(true);
			Invalidate();
		}

		protected override void OnMouseDown(MouseEventArgs e)
		{
			base.OnMouseDown(e);
			Focus();
			if (e.Button == MouseButtons.Right)
			{
				int line = LineAt(e.Y);
				if (line >= 0 && !IsSelected(line))
				{
					_selAnchor = line;
					_selFocus = line;
					Invalidate();
				}
				return;
			}
			if (e.Button != MouseButtons.Left)
			{
				return;
			}
			int hit = LineAt(e.Y);
			_selAnchor = hit;
			_selFocus = hit;
			_dragging = hit >= 0;
			if (_dragging)
			{
				Capture = true;
			}
			Invalidate();
		}

		protected override void OnMouseMove(MouseEventArgs e)
		{
			base.OnMouseMove(e);
			if (!_dragging)
			{
				return;
			}
			int hit = LineAt(e.Y);
			if (hit >= 0 && hit != _selFocus)
			{
				_selFocus = hit;
				Invalidate();
			}
		}

		protected override void OnMouseUp(MouseEventArgs e)
		{
			base.OnMouseUp(e);
			if (e.Button == MouseButtons.Left)
			{
				_dragging = false;
				Capture = false;
			}
		}

		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
			if (keyData == (Keys.Control | Keys.C))
			{
				CopySelection();
				return true;
			}
			if (keyData == (Keys.Control | Keys.A))
			{
				SelectAll();
				return true;
			}
			return base.ProcessCmdKey(ref msg, keyData);
		}

		protected override void OnMouseEnter(EventArgs e)
		{
			base.OnMouseEnter(e);
			if (!Focused)
			{
				Focus();
			}
		}

		protected override void OnMouseWheel(MouseEventArgs e)
		{
			base.OnMouseWheel(e);
			if (!_scroll.Visible)
			{
				return;
			}
			int step = Math.Max(Font.Height, 12);
			if (e.Delta > 0)
			{
				step = -step;
			}
			SetScroll(_scroll.Value + step);
			Invalidate();
		}

		protected override void OnHandleCreated(EventArgs e)
		{
			base.OnHandleCreated(e);
			Reflow(true);
		}

		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			Reflow(false);
			Invalidate();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				_timer.Stop();
				_timer.Dispose();
				_menu.Dispose();
			}
			base.Dispose(disposing);
		}

		protected override void OnPaint(PaintEventArgs e)
		{
			e.Graphics.Clear(BackColor);
			int width = TextWidth();
			int y = 8 - ScrollValue();
			Color attention = Blend(Color.White, Color.FromArgb(20, 72, 114), Breath());
			_lineRects.Clear();
			using (SolidBrush attentionBrush = new SolidBrush(attention))
			using (SolidBrush selectionBrush = new SolidBrush(SystemColors.Highlight))
			{
				for (int i = 0; i < _lines.Count; i++)
				{
					Line line = _lines[i];
					int height = LineHeight(line.Text, width);
					Rectangle text = new Rectangle(8, y, width, height);
					_lineRects.Add(text);
					if (y + height >= 0 && y <= ClientSize.Height)
					{
						bool selected = IsSelected(i);
						if (selected)
						{
							e.Graphics.FillRectangle(selectionBrush, new Rectangle(4, y - 2, width + 8, height + 4));
							TextRenderer.DrawText(e.Graphics, line.Text, Font, text, SystemColors.HighlightText, Flags);
						}
						else if (line.Attention)
						{
							e.Graphics.FillRectangle(attentionBrush, new Rectangle(4, y - 2, width + 8, height + 4));
							TextRenderer.DrawText(e.Graphics, line.Text, Font, text, Color.Red, Flags);
						}
						else
						{
							TextRenderer.DrawText(e.Graphics, line.Text, Font, text, ForeColor, Flags);
						}
					}
					y += height + 6;
				}
			}
		}

		private int LineAt(int y)
		{
			if (_lineRects.Count == 0)
			{
				return -1;
			}
			for (int i = 0; i < _lineRects.Count; i++)
			{
				Rectangle rect = _lineRects[i];
				if (y < rect.Bottom + 6)
				{
					return i;
				}
			}
			return _lineRects.Count - 1;
		}

		private bool IsSelected(int line)
		{
			if (_selAnchor < 0 || _selFocus < 0 || line < 0)
			{
				return false;
			}
			int start = Math.Min(_selAnchor, _selFocus);
			int end = Math.Max(_selAnchor, _selFocus);
			return line >= start && line <= end;
		}

		private void SelectAll()
		{
			if (_lines.Count == 0)
			{
				return;
			}
			_selAnchor = 0;
			_selFocus = _lines.Count - 1;
			Invalidate();
		}

		private void CopySelection()
		{
			int start = 0;
			int end = _lines.Count - 1;
			if (_selAnchor >= 0 && _selFocus >= 0)
			{
				start = Math.Min(_selAnchor, _selFocus);
				end = Math.Max(_selAnchor, _selFocus);
			}
			if (end < start || _lines.Count == 0)
			{
				return;
			}
			List<string> chosen = new List<string>();
			for (int i = start; i <= end; i++)
			{
				chosen.Add(_lines[i].Text);
			}
			try
			{
				Clipboard.SetText(string.Join(Environment.NewLine, chosen.ToArray()));
			}
			catch (Exception)
			{
			}
		}

		private void TimerTick(object sender, EventArgs e)
		{
			foreach (Line line in _lines)
			{
				if (line.Attention)
				{
					Invalidate();
					return;
				}
			}
		}

		private void ScrollMoved(object sender, ScrollEventArgs e)
		{
			_stickToEnd = _scroll.Value >= MaxScroll() - 2;
			Invalidate();
		}

		private void Reflow(bool fromAppend)
		{
			if (_layoutBusy || !IsHandleCreated)
			{
				return;
			}
			_layoutBusy = true;
			try
			{
				int view = Math.Max(1, ClientSize.Height);
				int width = Math.Max(10, ClientSize.Width - _scroll.Width - 16);
				int content = ContentHeight(width);
				bool show = content > view;
				if (!show)
				{
					width = Math.Max(10, ClientSize.Width - 16);
					content = ContentHeight(width);
					show = content > view;
				}
				if (!show)
				{
					_scroll.Visible = false;
					if (_scroll.Value != 0)
					{
						_scroll.Value = 0;
					}
					_stickToEnd = true;
					return;
				}
				int large = Math.Max(1, view);
				int maximum = Math.Max(large, content);
				if (_scroll.Value > maximum)
				{
					_scroll.Value = 0;
				}
				if (_scroll.Maximum != maximum)
				{
					_scroll.Maximum = maximum;
				}
				int allowed = Math.Max(1, _scroll.Maximum - _scroll.Minimum + 1);
				if (large > allowed)
				{
					large = allowed;
				}
				_scroll.SmallChange = Math.Max(1, Math.Min(Font.Height, allowed));
				if (_scroll.LargeChange != large)
				{
					_scroll.LargeChange = large;
				}
				_scroll.Visible = true;
				int max = MaxScroll();
				if (fromAppend && _stickToEnd)
				{
					SetScroll(max);
				}
				else if (_scroll.Value > max)
				{
					SetScroll(max);
				}
			}
			finally
			{
				_layoutBusy = false;
			}
		}

		private int ContentHeight(int width)
		{
			int height = 16;
			foreach (Line line in _lines)
			{
				height += LineHeight(line.Text, width) + 6;
			}
			return height;
		}

		private int LineHeight(string text, int width)
		{
			Size size = TextRenderer.MeasureText(text, Font, new Size(Math.Max(10, width), int.MaxValue), Flags);
			return Math.Max(Font.Height, size.Height);
		}

		private int TextWidth()
		{
			int chrome = _scroll.Visible ? _scroll.Width : 0;
			int width = ClientSize.Width - chrome - 16;
			return width < 10 ? 10 : width;
		}

		private int ScrollValue()
		{
			return _scroll.Visible ? _scroll.Value : 0;
		}

		private int MaxScroll()
		{
			int view = Math.Max(1, _scroll.LargeChange);
			return Math.Max(0, _scroll.Maximum - view);
		}

		private void SetScroll(int value)
		{
			int max = MaxScroll();
			if (value < 0)
			{
				value = 0;
			}
			if (value > max)
			{
				value = max;
			}
			if (_scroll.Value != value)
			{
				_scroll.Value = value;
			}
			_stickToEnd = value >= max - 2;
		}

		private double Breath()
		{
			if (UseForcedBreath)
			{
				return ForcedBreath;
			}
			double seconds = (DateTime.UtcNow - _started).TotalSeconds;
			double wave = (Math.Sin(seconds * (Math.PI * 2.0 / 3.0)) + 1.0) / 2.0;
			return wave * wave * (3.0 - (2.0 * wave));
		}

		private static Color Blend(Color from, Color to, double t)
		{
			if (t < 0)
			{
				t = 0;
			}
			if (t > 1)
			{
				t = 1;
			}
			int r = from.R + (int)Math.Round((to.R - from.R) * t);
			int g = from.G + (int)Math.Round((to.G - from.G) * t);
			int b = from.B + (int)Math.Round((to.B - from.B) * t);
			return Color.FromArgb(r, g, b);
		}
	}
}
