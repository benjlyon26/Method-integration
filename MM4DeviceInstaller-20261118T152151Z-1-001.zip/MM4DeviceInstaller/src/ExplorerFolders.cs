using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;

namespace MM4DeviceInstaller
{
	internal static class ExplorerFolders
	{
		public const string UsualDevicesFolder = @"C:\Program Files (x86)\Dynamic Devices\MethodManager4\Libraries\Devices";

		public static void Collect(IList<PendingDll> pending, IList<string> destinations, IList<string> sources)
		{
			foreach (PendingDll item in pending)
			{
				string destination = item.IntendedFolder;
				if (string.IsNullOrWhiteSpace(destination))
				{
					destination = UsualDevicesFolder;
				}
				AddUnique(destinations, destination);
				AddUnique(sources, item.SourceFolder);
			}
		}

		public static string Open(string folder)
		{
			if (string.IsNullOrWhiteSpace(folder) || !Directory.Exists(folder))
			{
				return "The folder was not found.";
			}
			try
			{
				Type type = Type.GetTypeFromProgID("Shell.Application");
				object shell = Activator.CreateInstance(type);
				type.InvokeMember("Explore", BindingFlags.InvokeMethod, null, shell, new object[] { folder });
				return "";
			}
			catch (Exception shellError)
			{
				try
				{
					ProcessStartInfo start = new ProcessStartInfo();
					start.FileName = folder;
					start.UseShellExecute = true;
					Process.Start(start);
					return "";
				}
				catch (Exception ex)
				{
					return shellError.Message + " " + ex.Message;
				}
			}
		}

		private static void AddUnique(IList<string> list, string folder)
		{
			if (string.IsNullOrWhiteSpace(folder))
			{
				return;
			}
			foreach (string existing in list)
			{
				if (string.Equals(existing, folder, StringComparison.OrdinalIgnoreCase))
				{
					return;
				}
			}
			list.Add(folder);
		}
	}
}
