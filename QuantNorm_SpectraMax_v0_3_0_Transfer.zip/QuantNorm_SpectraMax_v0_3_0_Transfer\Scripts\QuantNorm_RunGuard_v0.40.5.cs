﻿using System;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections.Generic;
using System.Windows.Forms;
using MethodManager.Core;
using MMScriptObjects;

// QuantNorm_RunGuard v0.40.4 - native method handoff checks; no instrument motion is issued here.
// Requires the coordinated revised method and four revised workflow scripts.
// v0.40.2: decode CSV-quoted VO trailer fields; retain the v0.40.1 developer override unchanged.
// v0.40.3: reject an explicit failed/malformed response even for an empty channel plan.
// v0.40.4: customer-neutral presentation release; execution logic is unchanged.
public class MMScriptExecutor : IMMScriptExecutor
{
    // v0.40.5: SpectraMax variant. New liquid group QDIL (quant-plate diluent pre-fill: Diluent ->
    //          Quant plate) with PREPARE/CHECK/RECORD stages; PREPARE_BLANK (per-well pre-read) and
    //          PREPARE_READER set User.ReaderPhase_01 and compose the per-plate SoftMax export paths
    //          (User.SpectraMaxBlankFile_01 / Read1File_01 / Read2File_01), deleting any stale file at
    //          those paths first. PREPARE_READER requires this run's blank for the plate.
    private const string SCRIPT_VERSION = "v0.40.5";
    // Deliberate runtime opt-in. The Developer tab in an HTML report is NOT this switch.
    // Missing, blank or anything other than True means that failures still stop the method.
    private const string V_DEV_MODE = "User.RunGuardDevMode_01";
    private const string V_SKIP_RUN = "User.RunGuardDevSkipRun_01";
    private const string V_SKIP_COUNT = "User.RunGuardDevSkipCount_01";
    private const string V_SKIP_LAST = "User.RunGuardDevLastSkip_01";
    private const string V_SKIP_RECORD = "User.RunGuardDevSkipRecord_01";

    // Only a response-validation failure can be overridden. Invalid plans, preparation,
    // barcode/worklist integrity, file writes and unexpected code errors are not skippable.
    private sealed class ResponseCheckException : InvalidOperationException
    {
        public ResponseCheckException(string message, Exception inner) : base(message, inner) { }
    }

    public void Execute(IMMApp app)
    {
        string stage = Qn.Get(app, "User.GuardStage_01").Trim();
        bool priorAbort = IsTrue(Qn.Get(app, "User.AbortMethod_01"));
        try
        {
            Qn.Require(!priorAbort, "A previous operation failed. Do not continue this run.");
            if (stage == "VALIDATE_QUANT") ValidateQuant(app);
            else if (stage == "PREPARE_READER") PrepareReader(app, "SAMPLE");
            else if (stage == "PREPARE_BLANK") PrepareReader(app, "BLANK");
            else if (stage == "VALIDATE_NORM") ValidateNorm(app);
            else if (stage.StartsWith("PREPARE_")) PrepareOperation(app, stage.Substring(8));
            else if (stage.StartsWith("CHECK_")) CheckOperation(app, stage.Substring(6));
            else if (stage.StartsWith("RECORD_")) RecordOperation(app, stage.Substring(7));
            else if (stage.StartsWith("SCAN_")) RecordScan(app, stage.Substring(5));
            else throw new InvalidOperationException("Unknown guard stage: " + stage);
        }
        catch (Exception ex)
        {
            Exception failure = ex;
            try
            {
                if (!priorAbort && ex is ResponseCheckException && TryDeveloperSkip(app, stage, ex))
                    return; // The existing native abort branch sees the unchanged False abort flag.
            }
            catch (Exception skipError)
            {
                // Do not continue when the override decision or its mandatory record failed.
                failure = new InvalidOperationException(
                    "Developer skip could not be completed. Original failure: " + ex.Message
                    + " | Override failure: " + skipError.Message, skipError);
            }
            StopAfterFailure(app, stage, failure);
        }
    }

    private static bool IsTrue(string value)
    { return string.Equals((value ?? "").Trim(), "True", StringComparison.OrdinalIgnoreCase); }

    private static bool IsResponseStage(string stage)
    {
        return stage == "CHECK_QUANT_ASP" || stage == "CHECK_QUANT_DISP"
            || stage == "CHECK_DILUENT_ASP" || stage == "CHECK_DILUENT_DISP"
            || stage == "CHECK_SAMPLE_ASP" || stage == "CHECK_SAMPLE_DISP"
            || stage == "CHECK_QDIL_ASP" || stage == "CHECK_QDIL_DISP";
    }

    private bool TryDeveloperSkip(IMMApp app, string stage, Exception failure)
    {
        if (!IsTrue(Qn.Get(app, V_DEV_MODE)) || !IsResponseStage(stage)) return false;

        // Required data must still be coherent. This feature must never invent a missing plan
        // or let a report's Developer display mode authorize physical transfers.
        Qn.Require(!IsTrue(Qn.Get(app, "User.AbortMethod_01")),
            "Another operation has raised an abort. The response check cannot be skipped.");
        Qn.CheckWorklist(app);
        string run = Qn.Get(app, "User.RunID_01");
        Qn.Require(run.Trim().Length > 0, "A development override requires a current run ID.");
        int slot = Slot(app);
        bool hardware = app.IsExecuteMode; // If unreadable, fail closed rather than assume simulation.
        if (!ConfirmSkipFailedCheck(app, stage, failure.Message, hardware)) return false;

        // Re-check after the dialog; never clear an abort raised while the operator was deciding.
        Qn.Require(IsTrue(Qn.Get(app, V_DEV_MODE)), "Developer mode was disabled before confirmation.");
        Qn.Require(!IsTrue(Qn.Get(app, "User.AbortMethod_01")),
            "An abort was raised before the developer skip could be recorded.");
        Qn.Require(Qn.Get(app, "User.RunID_01") == run && Slot(app) == slot
            && Qn.Get(app, "User.GuardStage_01").Trim() == stage && app.IsExecuteMode == hardware,
            "The run, plate, stage or execution mode changed during the skip dialog.");
        Qn.CheckWorklist(app);

        int count = 0;
        if (Qn.Get(app, V_SKIP_RUN) == run)
            Qn.Require(int.TryParse(Qn.Get(app, V_SKIP_COUNT), out count)
                && count >= 0 && count < int.MaxValue, "The current run's developer-skip count is invalid.");
        count++;

        string when = DateTime.UtcNow.ToString("o");
        string summary = "DEV OVERRIDE - SKIPPED, NOT PASSED: " + stage
            + " | plate " + slot + " | " + failure.Message;
        var record = new StringBuilder();
        record.AppendLine("QuantNorm_RunGuard " + SCRIPT_VERSION);
        record.AppendLine("Disposition: SKIPPED_DEV - response check not passed");
        record.AppendLine("UTC: " + when);
        record.AppendLine("RunID: " + run);
        record.AppendLine("PlateSlot: " + slot);
        record.AppendLine("Stage: " + stage);
        record.AppendLine("SkipNumberThisRun: " + count);
        record.AppendLine("Mode: " + (hardware ? "HARDWARE EXECUTE" : "MM4 TEST / SIMULATION"));
        record.AppendLine("Decision: operator explicitly chose Yes for this single failed response check");
        record.AppendLine("DeveloperSwitch: " + V_DEV_MODE + " = True");
        record.AppendLine("Failure: " + failure.ToString());
        record.AppendLine("No VI/VO values, pass flags or physical interlocks were replaced.");
        AppendContext(app, record);

        // A durable record is mandatory. No silent fallback to a success value or temp folder.
        string folder = app.WorkspaceOutputPath;
        Qn.Require(!string.IsNullOrWhiteSpace(folder), "A workspace output folder is required to record the override.");
        Directory.CreateDirectory(folder);
        string path = Path.Combine(folder, "QuantNorm_guard_dev_skip_"
            + DateTime.UtcNow.ToString("yyyyMMdd_HHmmss_fff") + "_" + Guid.NewGuid().ToString("N") + ".txt");
        File.WriteAllText(path, record.ToString(), new UTF8Encoding(false));
        Qn.Write(app, V_SKIP_RUN, run);
        Qn.Write(app, V_SKIP_COUNT, count.ToString());
        Qn.Write(app, V_SKIP_LAST, when + " | " + summary);
        Qn.Write(app, V_SKIP_RECORD, path);
        Qn.Write(app, "User.ScriptMessage_01", summary + " | Record: " + path);
        // Do not write AbortMethod=False here. It was checked above and no other failure is cleared.
        app.OutputMsg(summary + " | Record: " + path, true);
        return true;
    }

    // Virtual solely to allow offline tests to provide a decision without opening a GUI.
    // Normal MM4 execution uses the dialog below; closing it or choosing No does not skip.
    public virtual bool ConfirmSkipFailedCheck(IMMApp app, string stage, string failure, bool hardware)
    {
        string mode = hardware
            ? "HARDWARE EXECUTE: continuing may cause additional REAL instrument movement and liquid transfers. "
                + "Use only a supervised, approved development/demo setup, not experimental samples."
            : "MM4 TEST / SIMULATION: the failed response will remain recorded as unverified.";
        string message = "RunGuard response check failed.\n\nStage: " + stage
            + "\nPlate slot: " + Qn.Get(app, "User.Loop_Counter_01")
            + "\nRun: " + Qn.Get(app, "User.RunID_01")
            + "\n\n" + failure + "\n\n" + mode
            + "\n\nYes = skip THIS response check and continue."
            + "\nNo = stop the method."
            + "\n\nThe skip is logged, not treated as a pass. The final report still checks the raw results.";
        return MessageBox.Show(message, "RunGuard - developer override",
            MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.Yes;
    }

    private static void AppendContext(IMMApp app, StringBuilder record)
    {
        foreach (string variable in new string[] {
            "User.Loop_Counter_01", "User.SourcePlate_List_01", "User.QuantPlate_List_01", "User.OutputPlate_List_01",
            "User.Quant_Aspirate_VI_01", "User.Quant_Dispense_VI_01", "User.QuantAsp_VO_01", "User.QuantDisp_VO_01",
            "User.Sample_Aspirate_VI_01", "User.Sample_Dispense_VI_01", "User.Sample_Aspirate_VO_01", "User.Sample_Dispense_VO_01",
            "User.Diluent_Aspirate_VI_01", "User.Diluent_Dispense_VI_01", "User.Diluent_Aspirate_VO_01", "User.Diluent_Dispense_VO_01" })
            record.AppendLine(variable + " = " + Qn.Get(app, variable));
    }

    private static void StopAfterFailure(IMMApp app, string stage, Exception failure)
    {
        Qn.Write(app, "User.AbortMethod_01", "True");
        Qn.Write(app, "User.ScriptMessage_01", "QuantNorm stopped at " + stage + ": " + failure.Message);
        try
        {
            string failurePath = Path.Combine(app.WorkspaceOutputPath, "QuantNorm_guard_failure_"
                + DateTime.UtcNow.ToString("yyyyMMdd_HHmmss_fff") + "_" + Guid.NewGuid().ToString("N") + ".txt");
            var record = new StringBuilder();
            record.AppendLine(DateTime.UtcNow.ToString("o") + " | Run: " + Qn.Get(app, "User.RunID_01"));
            record.AppendLine(Qn.Get(app, "User.ScriptMessage_01"));
            record.AppendLine(failure.ToString());
            AppendContext(app, record);
            File.WriteAllText(failurePath, record.ToString());
        }
        catch (Exception checkpointError)
        { try { app.OutputMsg("The failure checkpoint could not be written: " + checkpointError.Message, true); } catch (Exception) { } }
        app.OutputMsg(Qn.Get(app, "User.ScriptMessage_01"), true);
    }
    private static int Count(IMMApp app)
    {
        int count;
        Qn.Require(int.TryParse(Qn.Get(app, "User.ScanPlateCount_01"), out count) && count > 0 && count <= 4,
            "Invalid source plate count.");
        return count;
    }
    private static int Slot(IMMApp app)
    {
        int slot;
        Qn.Require(int.TryParse(Qn.Get(app, "User.Loop_Counter_01"), out slot) && slot > 0 && slot <= Count(app),
            "Invalid plate-loop counter.");
        return slot;
    }
    private static string Plate(IMMApp app, string variable)
    {
        var values = Qn.List(Qn.Get(app, variable), ',');
        Qn.Require(values.Count == Count(app), "Incomplete plate list: " + variable);
        return values[Slot(app) - 1];
    }
    private static void ValidateQuant(IMMApp app)
    {
        Qn.CheckWorklist(app);
        Qn.Require(Qn.Get(app, "User.BarcodeCheck_01") == "True", "Barcode reconciliation has not passed.");
        int count = Count(app);
        foreach (string variable in new string[] { "User.SourcePlate_List_01", "User.QuantPlate_List_01", "User.OutputPlate_List_01", "User.TipBox_List_01" })
        {
            var entries = Qn.List(Qn.Get(app, variable), ',');
            Qn.Require(entries.Count == count && entries.All(x => x.Length > 0) && entries.Distinct().Count() == count,
                "Invalid one-to-one execution mapping: " + variable);
        }
        foreach (string variable in new string[] { "User.Quant_Aspirate_VI_List_01", "User.Quant_Dispense_VI_List_01",
            "User.QuantDiluent_Aspirate_VI_List_01", "User.QuantDiluent_Dispense_VI_List_01", "User.QuantMix_VI_List_01" })
        {
            var entries = Qn.List(Qn.Get(app, variable), '-');
            Qn.Require(entries.Count == count, "Incomplete quantification VI list.");
            foreach (string entry in entries) QnEvidence.VI(entry);
        }
    }
    private void PrepareReader(IMMApp app, string phase)
    {
        Qn.CheckWorklist(app);
        int slot = Slot(app); string run = Qn.Get(app, "User.RunID_01");
        Qn.Require(run.Length > 0, "Missing run ID.");
        foreach (string name in new string[] { "ReadPlateResult", "User.ReadPlateResult", "User.ReadPlateResult_01",
            "ReadPlateResultPath", "User.ReadPlateResultPath", "User.ReadPlateResultPath_01" }) Qn.Write(app, name, "");
        Qn.Write(app, "User.CurrentPlateIndex_01", slot.ToString());
        Qn.Write(app, "User.ReaderPreparedRun_01", run);
        Qn.Write(app, "User.ReaderPreparedPlate_01", slot.ToString());
        Qn.Write(app, "User.ReaderPreparedUtc_01", DateTime.UtcNow.ToString("o"));
        string handle = Plate(app, "User.QuantPlate_List_01");
        var rowHandles = Qn.List(Qn.Get(app, "User.Row_QuantPlate_List_01"), ',');
        var barcodes = Qn.List(Qn.Get(app, "User.QuantBarcode_List_01"), ',');
        int row = rowHandles.IndexOf(handle);
        Qn.Require(row >= 0 && row < barcodes.Count, "No rows assigned to the current quantification plate.");
        string expected = barcodes[row].Length > 0 ? barcodes[row] : handle;
        Qn.Write(app, "User.ReaderExpectedPlateID_01", expected);
        // v0.40.5 — SpectraMax phase + per-plate export paths. The method's Export Section As steps
        // take their file names FROM these variables, so the script and the reader can never disagree
        // about which file belongs to which plate. A stale file at the path is deleted first so the
        // freshness check in ReaderNormVI cannot be satisfied by an earlier run's export.
        Qn.Write(app, "User.ReaderPhase_01", phase);
        string folder = app.WorkspaceOutputPath;
        Qn.Require(!string.IsNullOrWhiteSpace(folder), "A workspace output folder is required for the reader exports.");
        Directory.CreateDirectory(folder);
        string stem = Path.Combine(folder, "QuantNorm_SMX_" + run + "_P" + slot + "_");
        if (phase == "BLANK")
        {
            string blank = stem + "Blank.txt";
            if (File.Exists(blank)) File.Delete(blank);
            Qn.Write(app, "User.SpectraMaxBlankFile_01", blank);
        }
        else
        {
            Qn.Require(Qn.Get(app, "User.BlankPlate" + slot + "_01").StartsWith("RUN=" + run + ";", StringComparison.Ordinal),
                "No per-well blank is stored for plate " + slot + " of this run. The blank read (PREPARE_BLANK + ReaderNormVI BLANK phase) must run before the sample read.");
            string r1 = stem + "Read_1.txt", r2 = stem + "Read_2.txt";
            foreach (string p in new string[] { r1, r2 }) if (File.Exists(p)) File.Delete(p);
            Qn.Write(app, "User.SpectraMaxRead1File_01", r1);
            Qn.Write(app, "User.SpectraMaxRead2File_01", r2);
        }
        // Bind this value to Get Result's PlateID input. The reader-result Plate ID must agree.
        string profile = Qn.Get(app, "User.TestPayloadProfile_01").Trim();
        if (profile.Length > 0 && app.IsExecuteMode && Qn.Get(app, "User.SyntheticApprovedRun_01") != run)
        {
            Qn.Require(Qn.Get(app, "User.AllowSyntheticHardware_01") == "True",
                "Test reader fixtures are enabled during Hardware Execute mode. Clear TestPayloadProfile_01 for real samples, or explicitly authorize a synthetic-data hardware demo.");
            Qn.Require(ConfirmSyntheticHardware(), "Synthetic-data hardware demo was not confirmed.");
            Qn.Write(app, "User.SyntheticApprovedRun_01", run);
            app.OutputMsg("SYNTHETIC READER DATA explicitly authorized for this hardware demo run. Not measured assay results.", true);
        }
    }
    public virtual bool ConfirmSyntheticHardware()
    {
        return MessageBox.Show("This run may use invented reader results to calculate REAL robot transfers. Use only an approved demo setup, not experimental samples. Continue this run?",
            "SYNTHETIC-DATA HARDWARE DEMO", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes;
    }
    private static void ValidateNorm(IMMApp app)
    {
        Qn.CheckWorklist(app);
        int count = Count(app); string run = Qn.Get(app, "User.RunID_01");
        var statuses = Qn.List(Qn.Get(app, "User.NormalizationPlateStatus_List_01"), ',');
        var runs = Qn.List(Qn.Get(app, "User.NormalizationPlateRun_List_01"), ',');
        Qn.Require(statuses.Count == count && runs.Count == count && statuses.All(x => x == "READY") && runs.All(x => x == run),
            "Not every plate has a successful calculation from this run. No normalization transfers are allowed.");
        double tip;
        Qn.Require(Qn.TryNumber(Qn.Get(app, "User.TipWorkingCapacity_01"), out tip) && tip > 0, "Missing tip capacity.");
        foreach (string variable in new string[] { "User.Sample_Aspirate_VI_List_01", "User.Sample_Dispense_VI_List_01", "User.Diluent_Aspirate_VI_List_01", "User.Diluent_Dispense_VI_List_01" })
        {
            var entries = Qn.List(Qn.Get(app, variable), '-');
            Qn.Require(entries.Count == count, "Incomplete normalization VI list: " + variable);
            foreach (string entry in entries)
            {
                string[] fields = QnEvidence.VI(entry);
                for (int i = 1; i < fields.Length; i++)
                {
                    if (string.IsNullOrEmpty(fields[i])) continue;
                    double volume; Qn.TryNumber(fields[i].Split(';')[0], out volume);
                    Qn.Require(volume >= 2 && volume <= 1250, "VI volume is outside the retained 2-1250 uL channel range.");
                    if (variable.IndexOf("Aspirate", StringComparison.Ordinal) >= 0)
                    {
                        double total = 0;
                        foreach (string part in fields[i].Split(';')) { double value; Qn.TryNumber(part, out value); total += value; }
                        Qn.Require(total <= tip, "VI liquid plus air gaps exceeds configured tip capacity.");
                    }
                }
            }
        }
        ValidateRowPlans(app);
        Qn.Write(app, "User.AllNormalizationCheck_01", "True");
    }
    private static string Prefix(string liquid)
    {
        if (liquid == "QUANT") return "Quant";
        if (liquid == "DILUENT") return "Diluent";
        if (liquid == "SAMPLE") return "Sample";
        if (liquid == "QDIL") return "QuantDiluent";
        throw new InvalidOperationException("Unknown liquid group " + liquid);
    }
    private static string VIName(string liquid, bool aspirate)
    { return "User." + Prefix(liquid) + (aspirate ? "_Aspirate_VI_01" : "_Dispense_VI_01"); }
    private static string VOName(string liquid, bool aspirate)
    {
        if (liquid == "QUANT") return aspirate ? "User.QuantAsp_VO_01" : "User.QuantDisp_VO_01";
        return "User." + Prefix(liquid) + (aspirate ? "_Aspirate_VO_01" : "_Dispense_VO_01");
    }
    private static void PrepareOperation(IMMApp app, string liquid)
    {
        if (liquid != "QUANT" && liquid != "QDIL") Qn.Require(Qn.Get(app, "User.AllNormalizationCheck_01") == "True", "Run-level normalization validation has not passed.");
        var asp = QnEvidence.VI(Qn.Get(app, VIName(liquid, true)));
        var disp = QnEvidence.VI(Qn.Get(app, VIName(liquid, false)));
        Qn.Require(asp.Skip(1).Any(x => !string.IsNullOrEmpty(x)) == disp.Skip(1).Any(x => !string.IsNullOrEmpty(x)), "Aspiration/dispense masks disagree.");
        bool active = false;
        for (int i = 1; i < asp.Length; i++)
        {
            Qn.Require(string.IsNullOrEmpty(asp[i]) == string.IsNullOrEmpty(disp[i]), "A channel is enabled at only one end of a transfer.");
            if (!string.IsNullOrEmpty(asp[i])) active = true;
        }
        Qn.Write(app, VOName(liquid, true), ""); Qn.Write(app, VOName(liquid, false), "");
        Qn.Write(app, "User.GuardHasLiquid_01", active ? "True" : "False");
        if (liquid == "QUANT")
        {
            var cleanup = new string[97]; cleanup[0] = "VI;12;8";
            for (int i = 1; i < asp.Length; i++) if (!string.IsNullOrEmpty(asp[i])) cleanup[i] = "20";
            Qn.Write(app, "User.Quant_Return_VI_01", string.Join(",", cleanup));
        }
    }
    private static void CheckOperation(IMMApp app, string operation)
    {
        int split = operation.LastIndexOf('_'); Qn.Require(split > 0, "Malformed guard operation.");
        string liquid = operation.Substring(0, split), action = operation.Substring(split + 1);
        Qn.Require(action == "ASP" || action == "DISP", "Unknown response-check action: " + action);
        bool aspirate = action == "ASP";
        string vi = Qn.Get(app, VIName(liquid, aspirate));
        // Keep malformed instructions OUTSIDE the skippable response exception.
        QnEvidence.VI(vi);
        string plate = (liquid == "DILUENT" || liquid == "QDIL") && aspirate ? "Diluent" :
            aspirate ? Plate(app, "User.SourcePlate_List_01") :
            (liquid == "QUANT" || liquid == "QDIL") ? Plate(app, "User.QuantPlate_List_01") : Plate(app, "User.OutputPlate_List_01");
        Qn.SafeToken(plate, "Operation plate");
        try
        {
            QnEvidence.CheckAll(Qn.Get(app, VOName(liquid, aspirate)), vi, plate, aspirate ? "Aspirate" : "Dispense");
        }
        catch (InvalidOperationException ex)
        {
            // Only this exception class is eligible for the explicit developer prompt.
            throw new ResponseCheckException(ex.Message, ex);
        }
    }
    private static void RecordOperation(IMMApp app, string liquid)
    {
        int slot = Slot(app), count = Count(app);
        foreach (bool aspirate in new bool[] { true, false })
        {
            string scalar = VOName(liquid, aspirate);
            string list = scalar.Substring(0, scalar.Length - 3) + "_List_01";
            Qn.PlateValue(app, list, slot, count, Qn.Get(app, scalar), '&');
        }
        // Persist the bridge evidence while it still exists, even if a later plate aborts.
        string path = Path.Combine(app.WorkspaceOutputPath, "QuantNorm_response_" + Qn.Get(app, "User.RunID_01") + "_" + liquid + "_plate" + slot + ".txt");
        File.WriteAllText(path, "RecordedAt: " + DateTime.Now.ToString("o") + Environment.NewLine
            + "Aspirate: " + Qn.Get(app, VOName(liquid, true)) + Environment.NewLine
            + "Dispense: " + Qn.Get(app, VOName(liquid, false)) + Environment.NewLine);
    }
    private static void RecordScan(IMMApp app, string group)
    {
        string location = group == "SOURCE" ? "User.SourceLoc_01" : group == "QUANT" ? "User.QuantLoc_01" : "User.OutputLoc_01";
        string listName = group == "SOURCE" ? "User.Barcode_Scanned_List_01" : group == "QUANT" ? "User.QuantBarcode_Scanned_List_01" : "User.OutputBarcode_Scanned_List_01";
        var captures = Qn.List(Qn.Get(app, listName), ',');
        Qn.Require(captures.Count == Slot(app), "Barcode capture list does not match the scan loop.");
        if (captures[captures.Count - 1].Length > 0) Qn.SafeToken(captures[captures.Count - 1], "Captured barcode");
        string path = Qn.Get(app, "User.BarcodeAuditFile_01");
        Qn.Require(path.Length > 0, "Missing barcode audit path.");
        File.AppendAllText(path, DateTime.Now.ToString("o") + " | capture completed | " + group + " | "
            + Qn.Get(app, location) + " | " + captures[captures.Count - 1] + " | " + Qn.Get(app, "User.Barcode_Read_By_01") + Environment.NewLine);
    }

    // Instrument-response validation shared by the runtime guard and final report.
    // Status and command stroke are checked; this is not independent gravimetric delivery verification.
    private static class QnEvidence
    {
        public sealed class Record
        {
            public string Volume = "", Status = "", Timestamp = "";
        }
        public sealed class Response
        {
            public string Error = "", Plate = "", Command = "", Timestamp = "";
            public Dictionary<string, Record> Wells = new Dictionary<string, Record>();
        }
        public static Response Read(string raw, string expectedPlate, string expectedCommand)
        {
            var result = new Response();
            if (string.IsNullOrEmpty(raw)) { result.Error = "No instrument response"; return result; }
            // v0.40.2 / v0.30.4: VO outer fields are CSV. Decode their quoting
            // before comparing the trailer plate with the method's actual plate name.
            // Keep escaped quotes and embedded commas as field content; do not remove
            // every quote character or weaken the plate identity comparison.
            string[] fields;
            try { fields = Qn.Fields(raw, ','); }
            catch (InvalidOperationException ex)
            {
                result.Error = "Malformed quoted VO fields: " + ex.Message;
                return result;
            }
            int recordEnd = fields.Length;
            string[] header = fields[0].Split(';');
            if (header.Length < 4 || header[0] != "VO" || header[1] != "OK" || header[2] != "12" || header[3] != "8")
                result.Error = "Invalid or non-OK VO header: " + fields[0];
            if (fields.Length >= 10 && fields[fields.Length - 9].IndexOf(';') < 0)
            {
                // Trailer metadata are not well records, even when their quoted
                // content contains semicolons. Their positions follow CSV parsing.
                recordEnd = fields.Length - 9;
                result.Command = fields[fields.Length - 9].Trim();
                result.Plate = fields[fields.Length - 7].Trim();
                result.Timestamp = fields[fields.Length - 1].Trim();
                if (result.Plate.Length > 0 && expectedPlate.Length > 0 && result.Plate != expectedPlate)
                    result.Error = "VO trailer plate mismatch: " + result.Plate + " vs " + expectedPlate;
                if (result.Command.Length > 0 && result.Command.IndexOf(expectedCommand, StringComparison.OrdinalIgnoreCase) < 0)
                    result.Error = "VO trailer command mismatch: " + result.Command;
            }
            for (int i = 1; i < recordEnd; i++)
            {
                string[] record = fields[i].Split(';');
                if (record.Length < 4) continue;
                string well = Qn.Well(record[0]);
                if (well.Length == 0) { result.Error = "Invalid VO well label: " + record[0]; continue; }
                if (result.Wells.ContainsKey(well)) { result.Error = "Duplicate VO well: " + well; continue; }
                result.Wells[well] = new Record { Volume = record[1].Trim(), Status = record[3].Trim(), Timestamp = result.Timestamp };
            }
            return result;
        }
        public static string[] VI(string raw)
        {
            string[] fields = (raw ?? "").Split(',');
            Qn.Require(fields.Length == 97 && fields[0] == "VI;12;8", "Expected a 96-channel VI payload.");
            for (int i = 1; i < fields.Length; i++)
            {
                if (fields[i].Length == 0) continue;
                string[] parts = fields[i].Split(';'); double value;
                Qn.Require(parts.Length <= 3, "Invalid VI field at channel " + i);
                for (int k = 0; k < parts.Length; k++)
                    Qn.Require(Qn.TryNumber(parts[k], out value) && value >= 0, "Invalid or negative VI value at channel " + i);
            }
            return fields;
        }
        public static string Check(Response response, string well, string expectedField)
        {
            double expected = 0;
            bool active = expectedField != null && expectedField.Length > 0;
            if (active)
            {
                if (!Qn.TryNumber(expectedField.Split(';')[0], out expected) || expected < 0) return "Invalid expected volume";
                active = expected > 0;
            }
            Record actual;
            bool found = response.Wells.TryGetValue(Qn.Well(well), out actual);
            if (!active)
            {
                // No command was requested for this channel. Absence is valid; positive reported motion is not.
                double inactiveVolume;
                if (found && (!Qn.TryNumber(actual.Volume, out inactiveVolume) || Math.Abs(inactiveVolume) > 0.011))
                    return "Unrequested channel has a nonzero/invalid reported volume";
                return "";
            }
            if (response.Error.Length > 0) return response.Error;
            if (!found) return "Missing active-channel result";
            if (!actual.Status.Equals("OK", StringComparison.OrdinalIgnoreCase)) return "Channel status " + actual.Status;
            double volume;
            if (!Qn.TryNumber(actual.Volume, out volume) || volume < 0) return "Invalid reported volume";
            if (Math.Abs(volume - expected) > 0.011) return "Reported " + actual.Volume + ", expected " + Qn.Number(expected);
            return "";
        }
        public static void CheckAll(string raw, string vi, string plate, string command)
        {
            string[] expected = VI(vi);
            Response response = Read(raw, plate, command);
            bool active = false;
            for (int channel = 1; channel <= 96; channel++)
            {
                if (!string.IsNullOrEmpty(expected[channel])) active = true;
                string well = ((char)('A' + (channel - 1) / 12)).ToString() + ((channel - 1) % 12 + 1).ToString("00");
                string error = Check(response, well, expected[channel]);
                Qn.Require(error.Length == 0, command + " " + plate + " " + well + ": " + error);
            }
            // A missing response is valid for an intentionally empty command. An explicit
            // malformed or failed response is not a successful no-op.
            if (active || !string.IsNullOrWhiteSpace(raw))
                Qn.Require(response.Error.Length == 0, response.Error);
        }
        public static string Volume(Response response, string well)
        {
            Record record;
            return response.Wells.TryGetValue(Qn.Well(well), out record) ? record.Volume : "";
        }
    }

    // Shared, self-contained helpers. Kept in each script: no extra runtime DLL is required.
    private static class Qn
    {
        public static string Get(IMMApp app, string name)
        { try { return app.GetVariableValue(name) ?? ""; } catch (Exception) { return ""; } }
        public static void Write(IMMApp app, string name, string value)
        {
            app.SetVariable(name, value ?? "");
            if (!string.Equals(app.GetVariableValue(name) ?? "", value ?? "", StringComparison.Ordinal))
                throw new InvalidOperationException("MM4 variable did not retain its assigned value: " + name);
        }
        public static void Require(bool condition, string message)
        { if (!condition) throw new InvalidOperationException(message); }
        public static bool Finite(double value)
        { return !double.IsNaN(value) && !double.IsInfinity(value); }
        public static bool TryNumber(string text, out double value)
        {
            return double.TryParse((text ?? "").Trim(), System.Globalization.NumberStyles.Float,
                System.Globalization.CultureInfo.InvariantCulture, out value) && Finite(value);
        }
        public static string Number(double value)
        { return value.ToString("0.################", System.Globalization.CultureInfo.InvariantCulture); }
        public static string Well(string text)
        {
            string s = (text ?? "").Trim().ToUpperInvariant();
            int c;
            if (s.Length < 2 || s.Length > 3 || s[0] < 'A' || s[0] > 'H') return "";
            for (int i = 1; i < s.Length; i++) if (s[i] < '0' || s[i] > '9') return "";
            if (!int.TryParse(s.Substring(1), out c) || c < 1 || c > 12) return "";
            return s.Substring(0, 1) + c.ToString("00");
        }
        public static int Channel(string well)
        {
            string w = Well(well);
            return w.Length == 0 ? -1 : (w[0] - 'A') * 12 + int.Parse(w.Substring(1));
        }
        public static List<string> List(string raw, char separator)
        {
            var result = new List<string>();
            if (string.IsNullOrEmpty(raw)) return result;
            string[] parts = raw.Split(separator);
            int start = parts[0].Length == 0 ? 1 : 0;
            for (int i = start; i < parts.Length; i++) result.Add(parts[i]);
            return result;
        }
        public static string At(List<string> values, int index)
        { return index >= 0 && index < values.Count ? values[index] : ""; }
        public static void PlateValue(IMMApp app, string variable, int index, int count, string value, char separator)
        {
            Require(index >= 1 && index <= count && count <= 4, "Invalid plate index for " + variable);
            var prior = List(Get(app, variable), separator);
            Require(prior.Count <= count, "Too many plate entries in " + variable + ". Start from ingestion.");
            while (prior.Count < count) prior.Add("");
            prior[index - 1] = value ?? "";
            Write(app, variable, separator.ToString() + string.Join(separator.ToString(), prior.ToArray()));
        }
        public static void SafeToken(string value, string description)
        {
            Require(!string.IsNullOrEmpty(value) && value.IndexOfAny(new char[] { ',', '|', '&', '\r', '\n', '\t' }) < 0,
                description + " is empty or contains a reserved MM4 list delimiter.");
        }
        public static string HashBytes(byte[] data)
        {
            using (var sha = System.Security.Cryptography.SHA256.Create())
                return BitConverter.ToString(sha.ComputeHash(data)).Replace("-", "").ToLowerInvariant();
        }
        public static string HashFile(string path) { return HashBytes(File.ReadAllBytes(path)); }
        public static void CheckWorklist(IMMApp app)
        {
            string p = Get(app, "User.WorklistFile_01"), h = Get(app, "User.SourceWorklistHash_01");
            Require(h.Length > 0 && File.Exists(p) && HashFile(p) == h,
                "The worklist is missing or changed after ingestion. Start a new run; current results must not be paired with changed input.");
        }
        public static List<string> ReadRecords(string path) { return Records(File.ReadAllText(path)); }
        public static List<string> Records(string text)
        {
            var result = new List<string>();
            var b = new StringBuilder();
            bool quoted = false;
            string s = (text ?? "").TrimStart('\uFEFF');
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (c == '"')
                {
                    b.Append(c);
                    if (quoted && i + 1 < s.Length && s[i + 1] == '"') { b.Append(s[++i]); continue; }
                    // Comments and header preambles are plain text, not CSV records.
                    if (!b.ToString().TrimStart().StartsWith("#")) quoted = !quoted;
                }
                else if ((c == '\r' || c == '\n') && !quoted)
                {
                    result.Add(b.ToString()); b.Length = 0;
                    if (c == '\r' && i + 1 < s.Length && s[i + 1] == '\n') i++;
                }
                else b.Append(c);
            }
            Require(!quoted, "Unterminated quoted field in the input file.");
            if (b.Length > 0) result.Add(b.ToString());
            return result;
        }
        public static string[] Fields(string record, char separator)
        {
            var result = new List<string>(); var cell = new StringBuilder();
            bool quoted = false, closed = false;
            string s = record ?? "";
            // Preambles/comments are not CSV: callers retain them verbatim.
            if (s.TrimStart().StartsWith("#") || (s.IndexOf(separator) < 0 && s.IndexOf(':') > 0)) return new string[] { s };
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (quoted)
                {
                    if (c == '"')
                    {
                        if (i + 1 < s.Length && s[i + 1] == '"') { cell.Append('"'); i++; }
                        else { quoted = false; closed = true; }
                    }
                    else cell.Append(c);
                }
                else if (c == separator) { result.Add(cell.ToString()); cell.Length = 0; closed = false; }
                else if (c == '"')
                {
                    Require(!closed && cell.ToString().Trim().Length == 0, "Unexpected quote in a delimited field.");
                    cell.Length = 0; quoted = true;
                }
                else if (closed) Require(char.IsWhiteSpace(c), "Unexpected text following a quoted field.");
                else cell.Append(c);
            }
            Require(!quoted, "Unterminated quoted field."); result.Add(cell.ToString());
            return result.ToArray();
        }
    }


    private static void ValidateRowPlans(IMMApp app)
    {
        var qp = Qn.List(Qn.Get(app, "User.QuantPlate_List_01"), ',');
        var sp = Qn.List(Qn.Get(app, "User.SourcePlate_List_01"), ',');
        var op = Qn.List(Qn.Get(app, "User.OutputPlate_List_01"), ',');
        var rowQ = Qn.List(Qn.Get(app, "User.Row_QuantPlate_List_01"), ',');
        var rowS = Qn.List(Qn.Get(app, "User.Row_SourcePlate_List_01"), ',');
        var rowO = Qn.List(Qn.Get(app, "User.Row_OutputPlate_List_01"), ',');
        var wells = Qn.List(Qn.Get(app, "User.SourceWell_List_01"), ',');
        var xfer = Qn.List(Qn.Get(app, "User.TransferVolume_List_01"), ',');
        var dil = Qn.List(Qn.Get(app, "User.DiluentVolume_List_01"), ',');
        var disposition = Qn.List(Qn.Get(app, "User.RowDisposition_List_01"), ',');
        int n;
        Qn.Require(int.TryParse(Qn.Get(app, "User.TransferCount_01"), out n) && n > 0, "Invalid row count.");
        foreach (var list in new List<string>[] { rowQ, rowS, rowO, wells, xfer, dil, disposition })
            Qn.Require(list.Count == n, "Incomplete per-row normalization plan.");
        double total;
        Qn.Require(Qn.TryNumber(Qn.Get(app, "User.RequestedOutputVolume_01"), out total) && total > 0, "Invalid requested output volume.");
        for (int slot = 0; slot < Count(app); slot++)
        {
            var sample = QnEvidence.VI(Qn.At(Qn.List(Qn.Get(app, "User.Sample_Aspirate_VI_List_01"), '-'), slot));
            var water = QnEvidence.VI(Qn.At(Qn.List(Qn.Get(app, "User.Diluent_Aspirate_VI_List_01"), '-'), slot));
            var claimed = new HashSet<int>();
            for (int i = 0; i < n; i++)
            {
                if (rowQ[i] != qp[slot]) continue;
                int ch = Qn.Channel(wells[i]);
                Qn.Require(ch > 0 && claimed.Add(ch) && rowS[i] == sp[slot] && rowO[i] == op[slot], "Ambiguous row-to-plate plan.");
                if (disposition[i] == "SKIPPED")
                    Qn.Require(xfer[i].Length == 0 && dil[i].Length == 0 && string.IsNullOrEmpty(sample[ch]) && string.IsNullOrEmpty(water[ch]), "A skipped well has a transfer instruction.");
                else
                {
                    double x, d, vx, vd = 0;
                    Qn.Require(disposition[i] == "CALCULATED" || disposition[i] == "CALCULATED_BELOW_TARGET", "A row has no completed calculation.");
                    Qn.Require(Qn.TryNumber(xfer[i], out x) && x > 0, "Invalid sample amount.");
                    Qn.Require(Qn.TryNumber(dil[i], out d) && d >= 0, "Invalid diluent amount.");
                    Qn.Require(Qn.TryNumber((sample[ch] ?? "").Split(';')[0], out vx), "Missing sample VI channel.");
                    if (!string.IsNullOrEmpty(water[ch])) Qn.Require(Qn.TryNumber(water[ch].Split(';')[0], out vd), "Invalid diluent VI channel.");
                    Qn.Require(Math.Abs(x - vx) <= 0.011 && Math.Abs(d - vd) <= 0.011 && Math.Abs(x + d - total) <= 0.011, "VI plan differs from the recorded normalization calculation.");
                }
            }
            for (int ch = 1; ch <= 96; ch++)
                if (!claimed.Contains(ch)) Qn.Require(string.IsNullOrEmpty(sample[ch]) && string.IsNullOrEmpty(water[ch]), "An unlisted well has a normalization instruction.");
        }
    }

}
